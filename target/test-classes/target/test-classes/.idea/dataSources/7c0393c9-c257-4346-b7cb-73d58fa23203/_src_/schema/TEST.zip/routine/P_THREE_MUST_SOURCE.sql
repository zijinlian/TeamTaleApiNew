CREATE PROCEDURE P_THREE_MUST_SOURCE
/**************************************************************/
  /*Function:“必知”、“必理”、“必管”测评结果                                    */
  /*InputParam:                                       */
  /*OutputParam:                                                */
  /*Create-Date:Aug. 17th,2016                                   */
  /*Author:Pansky-cx                                            */
  /**************************************************************/
IS
  --变量声明
     v_examId varchar2(200);

BEGIN
 v_examId:='402877815ce830d2015ce8543645001e';
--插入被考核机构
EXECUTE IMMEDIATE 'truncate table TB_PER_THREEMUST_EVALUATE';
   insert into TB_PER_THREEMUST_EVALUATE(FD_EVALUATEDUSERID,FD_EVALUATEDUSERNME)
        select t.fd_exam_target as FD_EVALUATEDUSERID, t.fd_empnme as FD_EVALUATEDUSERNME from
           (select DISTINCT(t1.fd_empnme),t2.fd_exam_target from TB_PEPMGM_EMPINFO t1, 
		                                                         tb_oa_answers t2 
			where (t1.FD_EMPID=t2.FD_EXAM_TARGET) and t2.FD_EXAM_ID='402877815ce830d2015ce8543645001e')t
group by t.fd_exam_target,t.fd_empnme;
commit;

  --分行员工评价A票得分统计  
  update TB_PER_THREEMUST_EVALUATE e
     set e.fd_staff_score_a = (select FD_SCORE / people as SOURCE
                                 from (select t.fd_exam_target as FD_empid,
                                              sum(t.fd_answer_score) as FD_SCORE,
                                              count(t.fd_exam_target) as people
                                         from tb_oa_answers t
                                        where t.fd_exam_id = v_examId
                                          and t.fd_examnum like '1%'
                                          and length(t.fd_examnum) = 9
                                        group by t.fd_exam_target)
                                where e.FD_EVALUATEDUSERID = FD_empid)
   where FD_EVALUATEDUSERID =
         (select FD_empid
            from (select t.fd_exam_target as FD_empid,
                         sum(t.fd_answer_score) as FD_SCORE,
                         count(t.fd_exam_target) as people
                    from tb_oa_answers t
                   where t.fd_exam_id = v_examId
                     and t.fd_examnum like '1%'
                     and length(t.fd_examnum) = 9
                   group by t.fd_exam_target)
           where e.FD_EVALUATEDUSERID = FD_empid);
                          
commit;

--分行员工评价B票得分统计
 update TB_PER_THREEMUST_EVALUATE e
    set e.fd_staff_score_b = (select FD_SCORE / people as SOURCE
                                from (select t.fd_exam_target as FD_empid,
                                             sum(t.fd_answer_score) as FD_SCORE,
                                             count(t.fd_exam_target) as people
                                        from tb_oa_answers t
                                       where t.fd_exam_id =v_examId
                                         and t.fd_examnum like '2%'
                                         and length(t.fd_examnum) = 9
                                       group by t.fd_exam_target)
                               where e.FD_EVALUATEDUSERID = FD_empid)
  where FD_EVALUATEDUSERID =
        (select FD_empid
           from (select t.fd_exam_target as FD_empid,
                        sum(t.fd_answer_score) as FD_SCORE,
                        count(t.fd_exam_target) as people
                   from tb_oa_answers t
                  where t.fd_exam_id = v_examId
                    and t.fd_examnum like '2%'
                    and length(t.fd_examnum) = 9
                  group by t.fd_exam_target)
          where e.FD_EVALUATEDUSERID = FD_empid);
commit;

  --分行员工评价C票得分统计
 update TB_PER_THREEMUST_EVALUATE e
    set e.fd_staff_score_c = (select FD_SCORE / people as SOURCE
                                from (select t.fd_exam_target as FD_empid,
                                             sum(t.fd_answer_score) as FD_SCORE,
                                             count(t.fd_exam_target) as people
                                        from tb_oa_answers t
                                       where t.fd_exam_id =v_examId
                                         and t.fd_examnum like '3%'
                                         and length(t.fd_examnum) = 9
                                       group by t.fd_exam_target)
                               where e.FD_EVALUATEDUSERID = FD_empid)
  where FD_EVALUATEDUSERID =
        (select FD_empid
           from (select t.fd_exam_target as FD_empid,
                        sum(t.fd_answer_score) as FD_SCORE,
                        count(t.fd_exam_target) as people
                   from tb_oa_answers t
                  where t.fd_exam_id = v_examId
                    and t.fd_examnum like '3%'
                    and length(t.fd_examnum) = 9
                  group by t.fd_exam_target)
          where e.FD_EVALUATEDUSERID = FD_empid);
commit;

  --分行员工评价D票得分统计
 update TB_PER_THREEMUST_EVALUATE e
    set e.fd_staff_score_d = (select FD_SCORE / people as SOURCE
                                from (select t.fd_exam_target as FD_empid,
                                             sum(t.fd_answer_score) as FD_SCORE,
                                             count(t.fd_exam_target) as people
                                        from tb_oa_answers t
                                       where t.fd_exam_id =v_examId
                                         and t.fd_examnum like '4%'
                                         and length(t.fd_examnum) = 9
                                       group by t.fd_exam_target)
                               where e.FD_EVALUATEDUSERID = FD_empid)
  where FD_EVALUATEDUSERID =
        (select FD_empid
           from (select t.fd_exam_target as FD_empid,
                        sum(t.fd_answer_score) as FD_SCORE,
                        count(t.fd_exam_target) as people
                   from tb_oa_answers t
                  where t.fd_exam_id = v_examId
                    and t.fd_examnum like '4%'
                    and length(t.fd_examnum) = 9
                  group by t.fd_exam_target)
          where e.FD_EVALUATEDUSERID = FD_empid);
commit;

--abcd票得分统计
update TB_PER_THREEMUST_EVALUATE e
set e.FD_STAFF_TOTAL_SCORE =nvl(e.fd_staff_score_b,0)*0.3+nvl(e.fd_staff_score_c,0)*0.3+nvl(e.fd_staff_score_d,0)*0.4;
commit;

--总分统计
update  TB_PER_THREEMUST_EVALUATE t set t.FD_TOTALSCORE=nvl(t.FD_STAFF_TOTAL_SCORE,0)*1;
commit;

--优秀率
--update  TB_PER_THREEMUST_EVALUATE t set t.FD_A_RATE=decode(t.FD_TOTALSCORE,0,0,nvl(t.fd_staff_score_a,0)/t.FD_TOTALSCORE);
 update TB_PER_THREEMUST_EVALUATE t
   set t.FD_A_RATE = (select fd_score_rate from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='优秀' and fd_exam_target=t.FD_EVALUATEDUSERID)
                        where t.FD_EVALUATEDUSERID=(select fd_exam_target from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='优秀' and fd_exam_target=t.FD_EVALUATEDUSERID);
commit;


--良好率
 update TB_PER_THREEMUST_EVALUATE t
   set t.FD_B_RATE = (select fd_score_rate from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='良好' and fd_exam_target=t.FD_EVALUATEDUSERID)
                        where t.FD_EVALUATEDUSERID=(select fd_exam_target from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='良好' and fd_exam_target=t.FD_EVALUATEDUSERID);
commit;


--称职率
 update TB_PER_THREEMUST_EVALUATE t
   set t.FD_C_RATE = (select fd_score_rate from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='称职' and fd_exam_target=t.FD_EVALUATEDUSERID)
                        where t.FD_EVALUATEDUSERID=(select fd_exam_target from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='称职' and fd_exam_target=t.FD_EVALUATEDUSERID);
commit;

--不称职率
 update TB_PER_THREEMUST_EVALUATE t
   set t.FD_D_RATE = (select fd_score_rate from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='不称职' and fd_exam_target=t.FD_EVALUATEDUSERID)
                        where t.FD_EVALUATEDUSERID=(select fd_exam_target from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='不称职' and fd_exam_target=t.FD_EVALUATEDUSERID);
commit;

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    ROLLBACK;
end P_THREE_MUST_SOURCE;
/
