CREATE PACKAGE BODY        "PKG_R001_RCG_ATTEND" IS
PROCEDURE SP_R00101_CHK_EMP_LUT(IS_DATE    IN VARCHAR2, --输入变量，传入跑批日期
                                  OI_RETCODE OUT INTEGER --输出变量，用来标识存储过程执行过程中是否出现异常
                                  ) IS
    /*-- AUTHOR  : 李蛟
    -- CREATED : 2016/11/03 15:03:28
    -- PURPOSE : 考勤-员工考勤对照表  */
    /*-----------------------------------------------------------------
       -- 程序名
       --      SP_R00101_CHK_EMP_LUT
       -- 用途
       --
       --修改记录：
    
    -----------------------------------------------------------------*/
  BEGIN
    PKG_R001_RCG_ATTEND.VS_STATR_TM := SYSTIMESTAMP;
    SELECT T.USERNAME
      INTO PKG_R001_RCG_ATTEND.VS_OWNER
      FROM SYS.USER_USERS T;
    PKG_R001_RCG_ATTEND.VS_PROCEDURE_NAME := 'SP_R00101_CHK_EMP_LUT';
  
    -------------------------------------------------------------------------
    -------清除目标表数据---------
    DELETE FROM TB_OA_ATTEND_DUTY T --每日考勤规则
     WHERE T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
    COMMIT;
    INSERT INTO TB_OA_ATTEND_DUTY
      (FD_DATE, --考勤日期
       EMPID, --员工编号
       EMPNAME, --员工姓名
       AM_WORKONTIME, --上午上班时间
       AM_WORKOFFTIME, --上午下班时间	   
       NEEDCLOCK, --是否打卡
       PM_WORKONTIME, --下午上班时间
       PM_WORKOFFTIME --下午下班时间
       )
    
      SELECT TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD'),
             T.FD_EMPID, --员工工号
             T.FD_EMPNME, --姓名
             nvl(t.AM_WORKONTIME,'08:30'), --上午上班时间
			nvl(t.AM_WORKOFFTIME,'11:30') , --上午下班时间             
             NULL, --是否打卡
		nvl(t.PM_WORKONTIME,'13:00')	 , --下午上班时间
			nvl(t.PM_WORKOFFTIME,'17:30') PM_WORKOFFTIME  --下午下班时间
        FROM (select t1.*,t2.AM_WORKONTIME,t2.AM_WORKOFFTIME,t2.PM_WORKONTIME,t2.PM_WORKOFFTIME from TB_PEPMGM_EMPINFO t1 left join TB_SYS_ORGATTENDTIME t2 on t1.fd_dept_org = t2.fd_orgcde) T
       WHERE LENGTH(FD_EMPID) = 7;
    --分段式提交-------------
    COMMIT;
  
    -----------------更新节假日的数据---------------------
    UPDATE TB_OA_ATTEND_DUTY T
       SET (AM_WORKONTIME, AM_WORKOFFTIME, NEEDCLOCK, PM_WORKONTIME, PM_WORKOFFTIME) =
           (SELECT NULL, NULL, '0', NULL, NULL
              FROM TB_OA_HOLIDAYS T1
             WHERE T.FD_DATE = T1.FD_DATE
               AND T1.ISHOLIDAY = 'Y')
     WHERE EXISTS
     (SELECT 1
              FROM (SELECT T2.FD_DATE
                      FROM TB_OA_HOLIDAYS T2
                     WHERE T2.ISHOLIDAY = 'Y') T2
             WHERE T.FD_DATE = T2.FD_DATE)
       AND T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
    --分段式提交-------------
    COMMIT;
    -----------------更新工作日要来上班的数据---------------------
    UPDATE TB_OA_ATTEND_DUTY T
       SET (NEEDCLOCK) =
           (SELECT   decode(T1.ISWORKDAY, 'Y', '1', 'N', '0')				   
              FROM TB_OA_HOLIDAYS T1
             WHERE T.FD_DATE = T1.FD_DATE)
     WHERE EXISTS
     (SELECT 1
              FROM (SELECT T2.FD_DATE FROM TB_OA_HOLIDAYS T2) T2
             WHERE T.FD_DATE = T2.FD_DATE)
       AND T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
    --分段式提交-------------
    COMMIT;
    -----------------更新白名单的数据---------------------
    UPDATE TB_OA_ATTEND_DUTY T
       SET (AM_WORKONTIME, AM_WORKOFFTIME, NEEDCLOCK, PM_WORKONTIME, PM_WORKOFFTIME) =
           (SELECT NULL, NULL, '0', NULL, NULL
              FROM TB_OA_ATTEND_WHITELIST T1
             WHERE T.EMPID = T1.EMPID)
     WHERE EXISTS
     (SELECT 1
              FROM (SELECT T2.EMPID FROM TB_OA_ATTEND_WHITELIST T2) T2
             WHERE T.EMPID = T2.EMPID)
       AND T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
    --分段式提交-------------
    COMMIT;
    -----------------更新特殊考勤表的数据---------------------
    UPDATE TB_OA_ATTEND_DUTY T
       SET (AM_WORKONTIME, AM_WORKOFFTIME, NEEDCLOCK, PM_WORKONTIME, PM_WORKOFFTIME) =
           (SELECT AM_WORKONTIME, AM_WORKOFFTIME, NEEDCLOCK, PM_WORKONTIME, PM_WORKOFFTIME
              FROM TB_OA_ATTEND_SPECIAL T1
             WHERE T.EMPID = T1.EMPID
               AND T1.ATTENDDATE =
                   TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD'))
     WHERE EXISTS
     (SELECT 1
              FROM (SELECT T2.EMPID
                      FROM TB_OA_ATTEND_SPECIAL T2
                     WHERE T2.ATTENDDATE =
                           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                   'YYYY-MM-DD')) T2
             WHERE T.EMPID = T2.EMPID)
       AND T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
    --分段式提交-------------
    COMMIT;
  
    -------------------------------------------------------------------------
    --日志记录
    OI_RETCODE := 1; --设置正常状态为1 成功状态
    COMMIT; --非特殊处理只能在最后一次提交
    PKG_R001_RCG_ATTEND.VS_END_TM := SYSTIMESTAMP;
    PROC_ETL_LOG(IS_DATE,
                 PKG_R001_RCG_ATTEND.VS_OWNER,
                 PKG_R001_RCG_ATTEND.VS_PROCEDURE_NAME,
                 PKG_R001_RCG_ATTEND.VS_STATR_TM,
                 PKG_R001_RCG_ATTEND.VS_END_TM,
                 PKG_R001_RCG_ATTEND.VI_ERRORCODE,
                 PKG_R001_RCG_ATTEND.VS_ERRORTEXT);
    --异常处理
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK; --数据回滚
      DBMS_OUTPUT.PUT_LINE('sqlcode：' || SQLCODE);
      DBMS_OUTPUT.PUT_LINE('sqlerrm：' || SQLERRM);
      PKG_R001_RCG_ATTEND.VI_ERRORCODE := SQLCODE; --设置异常代码
      PKG_R001_RCG_ATTEND.VS_ERRORTEXT := SUBSTR(SQLERRM, 1, 200); --设置异常描述
      OI_RETCODE                      := -1; --设置异常状态为-1
      --插入日志表，记录错误
      PROC_ETL_LOG(IS_DATE,
                   PKG_R001_RCG_ATTEND.VS_OWNER,
                   PKG_R001_RCG_ATTEND.VS_PROCEDURE_NAME,
                   PKG_R001_RCG_ATTEND.VS_STATR_TM,
                   SYSTIMESTAMP,
                   PKG_R001_RCG_ATTEND.VI_ERRORCODE,
                   PKG_R001_RCG_ATTEND.VS_ERRORTEXT);
      PKG_R001_RCG_ATTEND.VI_ERRORCODE := NULL;
      PKG_R001_RCG_ATTEND.VS_ERRORTEXT := NULL;
  END SP_R00101_CHK_EMP_LUT;

  PROCEDURE SP_R00101_CHK_EMP_DLUT(IS_DATE    IN VARCHAR2, --输入变量，传入跑批日期
                                   OI_RETCODE OUT INTEGER --输出变量，用来标识存储过程执行过程中是否出现异常
                                   ) IS
    /*-- AUTHOR  : 李蛟
    -- CREATED : 2016/11/03 15:03:28
    -- PURPOSE : 考勤-员工考勤对照表  */
    /*-----------------------------------------------------------------
       -- 程序名
       --      SP_R00101_CHK_EMP_DLUT
       -- 用途
       --
       --修改记录：
    
    -----------------------------------------------------------------*/
  BEGIN
    PKG_R001_RCG_ATTEND.VS_STATR_TM := SYSTIMESTAMP;
    SELECT T.USERNAME
      INTO PKG_R001_RCG_ATTEND.VS_OWNER
      FROM SYS.USER_USERS T;
    PKG_R001_RCG_ATTEND.VS_PROCEDURE_NAME := 'SP_R00101_CHK_EMP_DLUT';
  
    -------------------------------------------------------------------------
    -------清除目标表数据---------
    DELETE FROM TB_PEPMGM_ATTDINFO_COUNT T
     WHERE T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
    COMMIT;
    INSERT INTO TB_PEPMGM_ATTDINFO_COUNT
      (FD_ID, --编号
       FD_DATE, --考勤时间
       FD_EMPID, --员工号
       FD_EMPNME, --员工姓名
       FD_MIN_ATTDTIME, --最早打卡时间
       FD_MAX_ATTDTIME, --最晚打卡时间
       FD_COUNT_ATTDTIME, --当天打卡次数录数
       FD_ADDR, --考勤地点
       FD_POS_X, --打卡经度
       FD_POS_Y, --打卡纬度
       FD_FLAG, --1 表示的是考勤成功 0表示考勤失败
       FD_CHANNEL, --0 表示的是手机 1 表示的是PC
       FD_SERIALNO, --手机机器码
       FD_ISWORKDAY --是否工作日
       )
      SELECT SYS_GUID() as SYS_GUID, --编号
             TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD') as FD_DATE, -- 考勤时间
             A.FD_EMPID, --员工号
             A.FD_EMPNME, --员工姓名
             T.FD_ATTDTIME AS FD_ATTDTIME1, --最早打卡时间
             T1.FD_ATTDTIME AS FD_ATTDTIME2, --最晚打卡时间
             NULL, --当天打卡次数录数
             NULL, --考勤地点
             NULL, --打卡经度
             NULL, --打卡纬度
             NULL, --1 表示的是考勤成功 0表示考勤失败
             NULL, --0 表示的是手机 1 表示的是PC
             NULL, --手机机器码
             D.NEEDCLOCK
        FROM TB_PEPMGM_EMPINFO A
        LEFT JOIN (SELECT T.FD_EMPID, --员工号
                          T.FD_EMPNME, --员工姓名
                          T.FD_ATTDTIME --最早打卡时间
                     FROM (SELECT T.FD_EMPID,
                                  T.FD_EMPNME,
                                  FD_ATTDTIME,
                                  ROW_NUMBER() OVER(PARTITION BY T.FD_EMPID, T.FD_EMPNME ORDER BY FD_ATTDTIME ASC) AS N
                             FROM TB_PEPMGM_ATTDINFO T
                            WHERE T.FD_FLAG = '1'
                              AND T.FD_DATE =
                                  TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                          'YYYY-MM-DD')) T --每天考勤最小日期
                    WHERE N = 1) T
          ON A.FD_EMPID = T.FD_EMPID
        LEFT JOIN (SELECT *
                     FROM (SELECT T.FD_EMPID,
                                  T.FD_EMPNME,
                                  FD_ATTDTIME,
                                  ROW_NUMBER() OVER(PARTITION BY T.FD_EMPID, T.FD_EMPNME ORDER BY FD_ATTDTIME DESC) AS N
                             FROM TB_PEPMGM_ATTDINFO T
                            WHERE T.FD_FLAG = '1'
                              AND T.FD_DATE =
                                  TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                          'YYYY-MM-DD')) T --每天考勤最大日期
                    WHERE N = 1) T1
          ON A.FD_EMPID = T1.FD_EMPID
        left join TB_OA_ATTEND_DUTY D on D.empid= A.fd_empid
                              AND D.FD_DATE =
                                  TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                          'YYYY-MM-DD')
       WHERE LENGTH(A.FD_EMPID) = 7;
  
    -------------------------------------------------------------------------
    --日志记录
    OI_RETCODE := 1; --设置正常状态为1 成功状态
    COMMIT; --非特殊处理只能在最后一次提交
    PKG_R001_RCG_ATTEND.VS_END_TM := SYSTIMESTAMP;
    PROC_ETL_LOG(IS_DATE,
                 PKG_R001_RCG_ATTEND.VS_OWNER,
                 PKG_R001_RCG_ATTEND.VS_PROCEDURE_NAME,
                 PKG_R001_RCG_ATTEND.VS_STATR_TM,
                 PKG_R001_RCG_ATTEND.VS_END_TM,
                 PKG_R001_RCG_ATTEND.VI_ERRORCODE,
                 PKG_R001_RCG_ATTEND.VS_ERRORTEXT);
    --异常处理
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK; --数据回滚
      DBMS_OUTPUT.PUT_LINE('sqlcode：' || SQLCODE);
      DBMS_OUTPUT.PUT_LINE('sqlerrm：' || SQLERRM);
      PKG_R001_RCG_ATTEND.VI_ERRORCODE := SQLCODE; --设置异常代码
      PKG_R001_RCG_ATTEND.VS_ERRORTEXT := SUBSTR(SQLERRM, 1, 200); --设置异常描述
      OI_RETCODE                      := -1; --设置异常状态为-1
      --插入日志表，记录错误
      PROC_ETL_LOG(IS_DATE,
                   PKG_R001_RCG_ATTEND.VS_OWNER,
                   PKG_R001_RCG_ATTEND.VS_PROCEDURE_NAME,
                   PKG_R001_RCG_ATTEND.VS_STATR_TM,
                   SYSTIMESTAMP,
                   PKG_R001_RCG_ATTEND.VI_ERRORCODE,
                   PKG_R001_RCG_ATTEND.VS_ERRORTEXT);
      PKG_R001_RCG_ATTEND.VI_ERRORCODE := NULL;
      PKG_R001_RCG_ATTEND.VS_ERRORTEXT := NULL;
  END SP_R00101_CHK_EMP_DLUT;

  PROCEDURE SP_R00101_EMP_CHK_FLAG(IS_DATE    IN VARCHAR2, --输入变量，传入跑批日期
                                   OI_RETCODE OUT INTEGER --输出变量，用来标识存储过程执行过程中是否出现异常
                                   ) IS
    /*-- AUTHOR  : 李蛟
    -- CREATED : 2016/11/18 15:03:28
    -- PURPOSE : 考勤-员工每日考勤表比对结果  */
    /*-----------------------------------------------------------------
       -- 程序名
       --      SP_R00101_EMP_CHK_FLAG
       -- 用途
       --
       --修改记录：
    
    -----------------------------------------------------------------*/
  BEGIN
    PKG_R001_RCG_ATTEND.VS_STATR_TM := SYSTIMESTAMP;
    SELECT T.USERNAME
      INTO PKG_R001_RCG_ATTEND.VS_OWNER
      FROM SYS.USER_USERS T;
    PKG_R001_RCG_ATTEND.VS_PROCEDURE_NAME := 'SP_R00101_EMP_CHK_FLAG';
  
    -------------------------------------------------------------------------
    -----------------更新员工考勤---------------------
    ----更新考勤状态-----------------------------
    UPDATE TB_PEPMGM_ATTDINFO_COUNT T
       SET (FD_FLAG) =
           (SELECT A
              FROM （SELECT T.FD_DATE, --考勤日期
                   T.EMPID, --员工工号
                   EMPNAME, --员工名称
                   CASE
                     WHEN T.NEEDCLOCK = '0' THEN
                      '1'
                     WHEN (TO_DATE(T.FD_DATE || NVL(T.AM_WORKONTIME, '00:00:') || '00',
                                   'yyyy-mm-ddhh24:mi:ss') >=
                          TO_DATE(T1.FD_MIN_ATTDTIME, 'yyyy-mm-ddhh24:mi:ss')) AND
                          (TO_DATE(T1.FD_MAX_ATTDTIME, 'yyyy-mm-ddhh24:mi:ss') >=
                          TO_DATE(T.FD_DATE || NVL(T.PM_WORKOFFTIME, '00:00:') || '00',
                                   'yyyy-mm-ddhh24:mi:ss')) THEN
                      '1'
                     ELSE
                      '-1'
                   END AS A --打卡是否正常  1 正常 -1 不正常
            
              FROM TB_OA_ATTEND_DUTY T
              LEFT JOIN TB_PEPMGM_ATTDINFO_COUNT T1
                ON T.EMPID = T1.FD_EMPID
               AND T.FD_DATE = T1.FD_DATE
             WHERE T.FD_DATE =
                   TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD')
            /*and T.NEEDCLOCK = '1'*/
            ) T1
     WHERE T.FD_EMPID = T1.EMPID)
     WHERE EXISTS
     (SELECT 1
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           EMPNAME, --员工名称
                           CASE
                             WHEN T.NEEDCLOCK = '0' THEN
                              '1'
                             WHEN (TO_DATE(T.FD_DATE ||
                                           NVL(T.AM_WORKONTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss')) AND
                                  (TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T.FD_DATE ||
                                           NVL(T.PM_WORKOFFTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss')) THEN
                              '1'
                             ELSE
                              '-1'
                           END AS A --打卡是否正常  1 正常 -1 不正常
                      FROM TB_OA_ATTEND_DUTY T
                      LEFT JOIN TB_PEPMGM_ATTDINFO_COUNT T1
                        ON T.EMPID = T1.FD_EMPID
                       AND T.FD_DATE = T1.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /*and T.NEEDCLOCK = '1'*/
                    ) T2
             WHERE T.FD_DATE = T2.FD_DATE)
       AND T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
    --------------------分段提交-------------------
    commit;
    DBMS_OUTPUT.PUT_LINE('更新员工考勤状态执行完毕，准备执行(判断)是否迟到');
    -----------更新(判断)是否迟到-------------------------
    UPDATE TB_PEPMGM_ATTDINFO_COUNT T
       SET (FD_LATECOUNT) = --是否迟到(判断第一次打卡时间是否小于等于上午上班时间+30分且大于上午上班时间)
           (SELECT A
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           T.EMPNAME, --员工名称
                           CASE
                             WHEN T.NEEDCLOCK = '0' THEN --白名单
                               0
                             WHEN (TO_DATE(T1.FD_MIN_ATTDTIME,
                                              'yyyy-mm-ddhh24:mi:ss') <=
                                     (TO_DATE(T.FD_DATE ||
                                               NVL(T.AM_WORKONTIME, '00:00') ||
                                               ':00',
                                               'yyyy-mm-ddhh24:mi:ss') +
                                     30 / (24 * 60))) 
									 AND
								  (TO_DATE(T1.FD_MIN_ATTDTIME,
                                              'yyyy-mm-ddhh24:mi:ss') >
                                     (TO_DATE(T.FD_DATE ||
                                               NVL(T.AM_WORKONTIME, '00:00') ||
                                               ':00',
                                               'yyyy-mm-ddhh24:mi:ss')
                                     )) THEN
                              1
							 ELSE
							  0 --1表示1次,0表示0次
                           END AS A
                      FROM TB_OA_ATTEND_DUTY T
                      LEFT JOIN TB_PEPMGM_ATTDINFO_COUNT T1
                        ON T.EMPID = T1.FD_EMPID
                       AND T.FD_DATE = T1.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T1
             WHERE T.FD_EMPID = T1.EMPID)
     WHERE EXISTS
     (SELECT 1
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           T.EMPNAME, --员工名称
                           CASE
                             WHEN T.NEEDCLOCK = '0' THEN
                              '1'
                             WHEN (TO_DATE(T.FD_DATE ||
                                           NVL(T.AM_WORKONTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss')) AND
                                  (TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T.FD_DATE ||
                                           NVL(T.PM_WORKOFFTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss')) THEN
                              '1'
                             ELSE
                              '-1'
                           END AS A --打卡是否正常  1 正常 -1 不正常
                      FROM TB_OA_ATTEND_DUTY T
                      LEFT JOIN TB_PEPMGM_ATTDINFO_COUNT T1
                        ON T.EMPID = T1.FD_EMPID
                       AND T.FD_DATE = T1.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T2
             WHERE T.FD_DATE = T2.FD_DATE)
       AND T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
	------------分段提交------------------------------
    commit;
     DBMS_OUTPUT.PUT_LINE('(判断)是否迟到执行完毕，准备执行(判断)是否早退');
	-----------更新(判断)是否早退-------------------------
    UPDATE TB_PEPMGM_ATTDINFO_COUNT T
       SET (FD_EARLYCOUNT) = --早退次数(判断最迟打卡时间是否小于下午下班时间且大于等于下午下班时间-30分钟)
           (SELECT A
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           T.EMPNAME, --员工名称
                           CASE
                             WHEN T.NEEDCLOCK = '0' THEN --白名单
                               0
                             WHEN (TO_DATE(T1.FD_MAX_ATTDTIME,
                                              'yyyy-mm-ddhh24:mi:ss') >=
                                     (TO_DATE(T.FD_DATE ||
                                               NVL(T.PM_WORKOFFTIME, '00:00') ||
                                               ':00',
                                               'yyyy-mm-ddhh24:mi:ss') -
                                     30 / (24 * 60))) 
									 AND
								  (TO_DATE(T1.FD_MAX_ATTDTIME,
                                              'yyyy-mm-ddhh24:mi:ss') <
                                     (TO_DATE(T.FD_DATE ||
                                               NVL(T.PM_WORKOFFTIME, '00:00') ||
                                               ':00',
                                               'yyyy-mm-ddhh24:mi:ss')
                                     )) THEN
                              1
							 ELSE
							  0 --1表示1次,0表示0次
                           END AS A
                      FROM TB_OA_ATTEND_DUTY T
                      LEFT JOIN TB_PEPMGM_ATTDINFO_COUNT T1
                        ON T.EMPID = T1.FD_EMPID
                       AND T.FD_DATE = T1.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T1
             WHERE T.FD_EMPID = T1.EMPID)
     WHERE EXISTS
     (SELECT 1
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           T.EMPNAME, --员工名称
                           CASE
                             WHEN T.NEEDCLOCK = '0' THEN
                              '1'
                             WHEN (TO_DATE(T.FD_DATE ||
                                           NVL(T.AM_WORKONTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss')) AND
                                  (TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T.FD_DATE ||
                                           NVL(T.PM_WORKOFFTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss')) THEN
                              '1'
                             ELSE
                              '-1'
                           END AS A --打卡是否正常  1 正常 -1 不正常
                      FROM TB_OA_ATTEND_DUTY T
                      LEFT JOIN TB_PEPMGM_ATTDINFO_COUNT T1
                        ON T.EMPID = T1.FD_EMPID
                       AND T.FD_DATE = T1.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T2
             WHERE T.FD_DATE = T2.FD_DATE)
       AND T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
	------------分段提交------------------------------
    commit;
     DBMS_OUTPUT.PUT_LINE('(判断)是否早退执行完毕，准备执行判断是否)旷工');
	-----------更新(判断是否)旷工-------------------------
    UPDATE TB_PEPMGM_ATTDINFO_COUNT T
       SET (FD_ABSENTDAY) = --旷工天数
           (SELECT A
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           T.EMPNAME, --员工名称
                           CASE
                             WHEN T.NEEDCLOCK = '0' THEN --白名单
                               0
                             WHEN  --2次打卡记录，第一次打卡时间在（上午上班时间后30分-------下午上班之前），第二次打卡正常或者第二次打卡属于早退；
							      (TO_DATE(T1.FD_MIN_ATTDTIME, 
                                          'yyyy-mm-ddhh24:mi:ss') >
                                  TO_DATE(T.FD_DATE ||
                                           NVL(T.AM_WORKONTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss' )+
										   30 / (24 * 60) AND
                                  (TO_DATE(T1.FD_MIN_ATTDTIME,
                                            'yyyy-mm-ddhh24:mi:ss') <
                                   TO_DATE(T.FD_DATE ||
                                            NVL(T.PM_WORKONTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss'))) AND
                                   (TO_DATE(T.FD_DATE ||
                                            NVL(T.PM_WORKOFFTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss') - 30 / (24 * 60) <=
                                   TO_DATE(T1.FD_MAX_ATTDTIME,
                                            'yyyy-mm-ddhh24:mi:ss')) THEN
                              0.5 --属于上午旷工，下午正常，旷工0.5天
                             WHEN  --2次打卡记录，第一次打卡正常，第二次打卡时间（打卡时间早于下午下班时间30分以上）
							      (TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') <=
								   TO_DATE(T.FD_DATE ||
                                           NVL(T.AM_WORKONTIME, '00:00') ||
                                           ':00',
                                           'yyyy-mm-ddhh24:mi:ss')+ 30 / (24 * 60)) AND
                                  (TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') <
									TO_DATE(T.FD_DATE ||
                                            NVL(T.PM_WORKOFFTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss' )- 30 / (24 * 60) AND
											TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >=
									TO_DATE(T.FD_DATE ||
                                            NVL(T.AM_WORKOFFTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss'))
                                 THEN
                              0.5 --属于上午正常下午旷工，旷工0.5天
                             WHEN --无打卡记录,旷工1天
								  (TO_DATE(T1.FD_MAX_ATTDTIME,
                                            'yyyy-mm-ddhh24:mi:ss') IS NULL) AND
                                  (TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') IS NULL)
							      THEN
                              1 --无打卡记录,旷工1天
							 WHEN --只有1条打卡记录,旷工1天
								    TO_DATE(T1.FD_MAX_ATTDTIME,
                                            'yyyy-mm-ddhh24:mi:ss') = 
									TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss')                                  
							      THEN
                              1 --只有1条打卡记录,旷工1天
							  WHEN --2次打卡记录，第一次不论是否正常，第二次打卡时间早于上午下班时间。
								    TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') <
									TO_DATE(T.FD_DATE ||
                                            NVL(T.AM_WORKOFFTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss')                                  
							      THEN
                              1 ----2次打卡记录，第一次不论是否正常，第二次打卡时间早于上午下班时间,旷工1天
							  WHEN --2次打卡记录，第二次打卡时间早于下午下班时间30分但是大于等于上午下班时间，在判断第一次打卡时间，迟到30分钟以上。
								    (TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') <
									TO_DATE(T.FD_DATE ||
                                            NVL(T.PM_WORKOFFTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss' )- 30 / (24 * 60) AND  
                                    TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >=
									TO_DATE(T.FD_DATE ||
                                            NVL(T.AM_WORKOFFTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss')) AND	
                                    TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >
									TO_DATE(T.FD_DATE ||
                                            NVL(T.AM_WORKONTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss' )+ 30 / (24 * 60)											
							      THEN
                              1 ----2次打卡记录，第二次打卡时间早于下午下班时间30分但是大于上午下班时间，在判断第一次打卡时间，迟到30分钟以上,旷工1天
							  WHEN --2次打卡记录，第二次不管怎样，第一次打卡时间大于下午上班时间。								    	
                                    TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >
									TO_DATE(T.FD_DATE ||
                                            NVL(T.PM_WORKONTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss')											
							      THEN
                              1 ----2次打卡记录，第二次不管怎样，第一次打卡时间大于下午上班时间，旷工1天
							  ELSE
							  0
                           END AS A
                      FROM TB_OA_ATTEND_DUTY T
                      LEFT JOIN TB_PEPMGM_ATTDINFO_COUNT T1
                        ON T.EMPID = T1.FD_EMPID
                       AND T.FD_DATE = T1.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T1
             WHERE T.FD_EMPID = T1.EMPID)
     WHERE EXISTS
     (SELECT 1
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           EMPNAME, --员工名称
                           CASE
                             WHEN T.NEEDCLOCK = '0' THEN
                              '1'
                             WHEN (TO_DATE(T.FD_DATE ||
                                           NVL(T.AM_WORKONTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss')) AND
                                  (TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T.FD_DATE ||
                                           NVL(T.PM_WORKOFFTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss')) THEN
                              '1'
                             ELSE
                              '-1'
                           END AS A --打卡是否正常  1 正常 -1 不正常
                      FROM TB_OA_ATTEND_DUTY T
                      LEFT JOIN TB_PEPMGM_ATTDINFO_COUNT T1
                        ON T.EMPID = T1.FD_EMPID
                       AND T.FD_DATE = T1.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T2
             WHERE T.FD_DATE = T2.FD_DATE)
       AND T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
	------------分段提交------------------------------
    commit;
     DBMS_OUTPUT.PUT_LINE('判断是否)旷工执行完毕，准备执行(判断是否)正常');	   
   -----------更新(判断是否)正常-------------------------
    UPDATE TB_PEPMGM_ATTDINFO_COUNT T
       SET (FD_NORMALDAY) = --旷工天数
           (SELECT A
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           T.EMPNAME, --员工名称
                           CASE
                             WHEN T.NEEDCLOCK = '0' THEN --白名单
                               1
                             WHEN  --2次打卡记录，第一次打卡时间在（上午上班时间后30分-------下午上班之前），第二次打卡正常或者第二次打卡属于早退；
							      (TO_DATE(T1.FD_MIN_ATTDTIME, 
                                          'yyyy-mm-ddhh24:mi:ss') >
                                  TO_DATE(T.FD_DATE ||
                                           NVL(T.AM_WORKONTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss' ) AND
                                  (TO_DATE(T1.FD_MIN_ATTDTIME,
                                            'yyyy-mm-ddhh24:mi:ss') <
                                   TO_DATE(T.FD_DATE ||
                                            NVL(T.PM_WORKONTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss'))) AND
                                   (TO_DATE(T.FD_DATE ||
                                            NVL(T.PM_WORKOFFTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss')<
                                   TO_DATE(T1.FD_MAX_ATTDTIME,
                                            'yyyy-mm-ddhh24:mi:ss')) THEN
                              0.5 --属于上午旷工，下午正常，旷工0.5天
                             WHEN  --2次打卡记录，第一次打卡正常，第二次打卡时间（打卡时间早于下午下班时间30分以上）
							      (TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') <=
								   TO_DATE(T.FD_DATE ||
                                           NVL(T.AM_WORKONTIME, '00:00') ||
                                           ':00',
                                           'yyyy-mm-ddhh24:mi:ss')) AND
                                  (TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') <
									TO_DATE(T.FD_DATE ||
                                            NVL(T.PM_WORKOFFTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss' ) AND
											TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >
									TO_DATE(T.FD_DATE ||
                                            NVL(T.AM_WORKOFFTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss'))
                                 THEN
                              0.5 --属于上午正常下午旷工，旷工0.5天
                             WHEN --无打卡记录,旷工1天
								  (TO_DATE(T1.FD_MAX_ATTDTIME,
                                            'yyyy-mm-ddhh24:mi:ss') IS NULL) AND
                                  (TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') IS NULL)
							      THEN
                              0 --无打卡记录,旷工1天
							 WHEN --只有1条打卡记录,旷工1天
								    TO_DATE(T1.FD_MAX_ATTDTIME,
                                            'yyyy-mm-ddhh24:mi:ss') = 
									TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss')                                  
							      THEN
                              0 --只有1条打卡记录,旷工1天
							  WHEN --2次打卡记录，第一次不论是否正常，第二次打卡时间早于上午下班时间。
								    TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') <
									TO_DATE(T.FD_DATE ||
                                            NVL(T.AM_WORKOFFTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss')                                  
							      THEN
                              0 ----2次打卡记录，第一次不论是否正常，第二次打卡时间早于上午下班时间,旷工1天
							  WHEN --2次打卡记录，第二次打卡时间早于下午下班时间30分但是大于等于上午下班时间，在判断第一次打卡时间，迟到30分钟以上。
								    (TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') <
									TO_DATE(T.FD_DATE ||
                                            NVL(T.PM_WORKOFFTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss' )- 30 / (24 * 60) AND  
                                    TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >=
									TO_DATE(T.FD_DATE ||
                                            NVL(T.AM_WORKOFFTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss')) AND	
                                    TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >
									TO_DATE(T.FD_DATE ||
                                            NVL(T.AM_WORKONTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss' )+ 30 / (24 * 60)											
							      THEN
                              0 ----2次打卡记录，第二次打卡时间早于下午下班时间30分但是大于上午下班时间，在判断第一次打卡时间，迟到30分钟以上,旷工1天
							  WHEN --2次打卡记录，第二次不管怎样，第一次打卡时间大于下午上班时间。								    	
                                    TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >
									TO_DATE(T.FD_DATE ||
                                            NVL(T.PM_WORKONTIME, '00:00') ||
                                            ':00',
                                            'yyyy-mm-ddhh24:mi:ss')											
							      THEN
                              0 ----2次打卡记录，第二次不管怎样，第一次打卡时间大于下午上班时间，旷工1天
							  ELSE
							  1
                           END AS A
                      FROM TB_OA_ATTEND_DUTY T
                      LEFT JOIN TB_PEPMGM_ATTDINFO_COUNT T1
                        ON T.EMPID = T1.FD_EMPID
                       AND T.FD_DATE = T1.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T1
             WHERE T.FD_EMPID = T1.EMPID)
     WHERE EXISTS
     (SELECT 1
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           EMPNAME, --员工名称
                           CASE
                             WHEN T.NEEDCLOCK = '0' THEN
                              '1'
                             WHEN (TO_DATE(T.FD_DATE ||
                                           NVL(T.AM_WORKONTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss')) AND
                                  (TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T.FD_DATE ||
                                           NVL(T.PM_WORKOFFTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss')) THEN
                              '1'
                             ELSE
                              '-1'
                           END AS A --打卡是否正常  1 正常 -1 不正常
                      FROM TB_OA_ATTEND_DUTY T
                      LEFT JOIN TB_PEPMGM_ATTDINFO_COUNT T1
                        ON T.EMPID = T1.FD_EMPID
                       AND T.FD_DATE = T1.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T2
             WHERE T.FD_DATE = T2.FD_DATE)
       AND T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
    -----------更新请假状态(1表示请假审批中，2表示通过)-------------------------
    UPDATE TB_PEPMGM_ATTDINFO_COUNT T
       SET (FD_LEAVESTS) = --更新请假状态
           (SELECT A
              FROM (select distinct * from(
              (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           T.EMPNAME, --员工名称
                           B.FD_CUR_STATUS as A --请假状态
                             
                           FROM TB_OA_ATTEND_DUTY T 
                           left join (select fd_empid,max(FD_CUR_STATUS) as FD_CUR_STATUS from TB_OA_LEAVEINFO where FD_SERIALNUM not in (select FD_SERIALNUM from TB_OA_LEAVEINFO_CLEAR where FD_CUR_STATUS = '2') and FD_CUR_STATUS<>'3' and (IS_DATE BETWEEN substr(FD_BGNTIME,0,10) and substr(FD_ENDTIME,0,10)) group by fd_empid) B 
                           ON T.EMPID = B.FD_EMPID 
                           left join TB_PEPMGM_ATTDINFO_COUNT C ON T.EMPID = C.FD_EMPID AND T.FD_DATE = C.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')))
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T1
             WHERE T.FD_EMPID = T1.EMPID)
     WHERE EXISTS
     (SELECT 1
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           EMPNAME, --员工名称
                           CASE
                             WHEN T.NEEDCLOCK = '0' THEN
                              '1'
                             WHEN (TO_DATE(T.FD_DATE ||
                                           NVL(T.AM_WORKONTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss')) AND
                                  (TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T.FD_DATE ||
                                           NVL(T.PM_WORKOFFTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss')) THEN
                              '1'
                             ELSE
                              '-1'
                           END AS A --打卡是否正常  1 正常 -1 不正常
                      FROM TB_OA_ATTEND_DUTY T
                      LEFT JOIN TB_PEPMGM_ATTDINFO_COUNT T1
                        ON T.EMPID = T1.FD_EMPID
                       AND T.FD_DATE = T1.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T2
             WHERE T.FD_DATE = T2.FD_DATE)
       AND T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
	------------分段提交------------------------------
    commit;	
     DBMS_OUTPUT.PUT_LINE('更新请假状态执行完毕，准备执行更新每天的请假小时数');
    -----------更新每天的请假小时数(3.5或者4表示请假半天，7.5表示请假1天)-------------------------
    UPDATE TB_PEPMGM_ATTDINFO_COUNT T
       SET (FD_LEAVEHOURS) = --更新请假状态
           (SELECT A
              FROM (select distinct * from(
              (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           T.EMPNAME, --员工名称
                           B.FD_HOURS as A --请假状态
                             
                           FROM TB_OA_ATTEND_DUTY T 
                           left join (select fd_empid,sum(FD_HOURS) as FD_HOURS from TB_OA_LEAVEINFO_SPLIT where FD_SERIALNUM not in (select FD_SERIALNUM from TB_OA_LEAVEINFO_CLEAR where FD_CUR_STATUS = '2')and (IS_DATE BETWEEN substr(FD_BGNTIME,0,10) and substr(FD_ENDTIME,0,10)) 
 group by fd_empid) B 
                           ON T.EMPID = B.FD_EMPID
                           left join TB_PEPMGM_ATTDINFO_COUNT C ON T.EMPID = C.FD_EMPID AND T.FD_DATE = C.FD_DATE
                     WHERE  T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')))
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T1
             WHERE T.FD_EMPID = T1.EMPID)
     WHERE EXISTS
     (SELECT 1
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           EMPNAME, --员工名称
                           CASE
                             WHEN T.NEEDCLOCK = '0' THEN
                              '1'
                             WHEN (TO_DATE(T.FD_DATE ||
                                           NVL(T.AM_WORKONTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss')) AND
                                  (TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T.FD_DATE ||
                                           NVL(T.PM_WORKOFFTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss')) THEN
                              '1'
                             ELSE
                              '-1'
                           END AS A --打卡是否正常  1 正常 -1 不正常
                      FROM TB_OA_ATTEND_DUTY T
                      LEFT JOIN TB_PEPMGM_ATTDINFO_COUNT T1
                        ON T.EMPID = T1.FD_EMPID
                       AND T.FD_DATE = T1.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T2
             WHERE T.FD_DATE = T2.FD_DATE)
       AND T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
	------------分段提交------------------------------
    commit;
    DBMS_OUTPUT.PUT_LINE('更新每天的请假小时数执行完毕，准备更新调整状态');
    -----------更新调整状态(120出勤；130缺勤；140迟到(失效)；150早退(失效)；160补休)-------------------------
    UPDATE TB_PEPMGM_ATTDINFO_COUNT T
       SET (FD_ADJUSTSTS) = --更新调整状态
           (SELECT A
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           T.EMPNAME, --员工名称
                           C.FD_TYPE as A --调整状态
                             
                           FROM TB_OA_ATTEND_DUTY T 
                           left join 
						   (SELECT A1.FD_TYPE,A2.FD_EMPID,A2.FD_DATE FROM TB_PEPMGM_ATTDINFO_OFFICER_TJ A1,TB_PEPMGM_ATTDINFO_COUNT A2 WHERE A1.FD_ID=A2.FD_ID)C
                           on T.EMPID = C.FD_EMPID AND T.FD_DATE = C.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T1
             WHERE T.FD_EMPID = T1.EMPID)
     WHERE EXISTS
     (SELECT 1
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           EMPNAME, --员工名称
                           CASE
                             WHEN T.NEEDCLOCK = '0' THEN
                              '1'
                             WHEN (TO_DATE(T.FD_DATE ||
                                           NVL(T.AM_WORKONTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss')) AND
                                  (TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T.FD_DATE ||
                                           NVL(T.PM_WORKOFFTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss')) THEN
                              '1'
                             ELSE
                              '-1'
                           END AS A --打卡是否正常  1 正常 -1 不正常
                      FROM TB_OA_ATTEND_DUTY T
                      LEFT JOIN TB_PEPMGM_ATTDINFO_COUNT T1
                        ON T.EMPID = T1.FD_EMPID
                       AND T.FD_DATE = T1.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T2
             WHERE T.FD_DATE = T2.FD_DATE)
       AND T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
	------------分段提交------------------------------
    commit;
      DBMS_OUTPUT.PUT_LINE('更新调整状态执行完毕，准备更新申诉状态');	
	-----------更新申诉状态(1表示申诉审批中，2表示通过，3表示不通过)-------------------------
    UPDATE TB_PEPMGM_ATTDINFO_COUNT T
       SET (FD_APPEALSTS) = --更新申诉状态
           (SELECT A
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           T.EMPNAME, --员工名称
                           C.FD_CUR_STATUS as A --调整状态
                             
                           FROM TB_OA_ATTEND_DUTY T 
                           left join 
						   (SELECT A1.FD_CUR_STATUS,A2.FD_EMPID,A2.FD_DATE FROM TB_OA_ATTEND_UNUSUAL A1,TB_PEPMGM_ATTDINFO_COUNT A2 WHERE A1.FD_SERIALNUM=A2.FD_ID AND A1.FD_CUR_STATUS<>3)C
                           on T.EMPID = C.FD_EMPID AND T.FD_DATE = C.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T1
             WHERE T.FD_EMPID = T1.EMPID)
     WHERE EXISTS
     (SELECT 1
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           EMPNAME, --员工名称
                           CASE
                             WHEN T.NEEDCLOCK = '0' THEN
                              '1'
                             WHEN (TO_DATE(T.FD_DATE ||
                                           NVL(T.AM_WORKONTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss')) AND
                                  (TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T.FD_DATE ||
                                           NVL(T.PM_WORKOFFTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss')) THEN
                              '1'
                             ELSE
                              '-1'
                           END AS A --打卡是否正常  1 正常 -1 不正常
                      FROM TB_OA_ATTEND_DUTY T
                      LEFT JOIN TB_PEPMGM_ATTDINFO_COUNT T1
                        ON T.EMPID = T1.FD_EMPID
                       AND T.FD_DATE = T1.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T2
             WHERE T.FD_DATE = T2.FD_DATE)
       AND T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
	------------分段提交------------------------------
    commit;
      DBMS_OUTPUT.PUT_LINE('更新申诉状态执行完毕，准备更新加班数据');
	-----------更新加班数据-------------------------
    UPDATE TB_PEPMGM_ATTDINFO_COUNT T
       SET (FD_OVERTIMEHOURS) = --更新加班小时数
           (SELECT A
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           T.EMPNAME, --员工名称
                           B.FD_WORKHOURS as A --加班小时
                             
                           FROM TB_OA_ATTEND_DUTY T 
                           left join TB_OA_OVERTIMEINFO B on T.EMPID = B.FD_EMPID AND T.FD_DATE = SUBSTR(B.FD_BGNTIME,0,10) AND B.FD_CUR_STATUS='2'
                           left join TB_PEPMGM_ATTDINFO_COUNT C on T.EMPID = C.FD_EMPID AND T.FD_DATE = C.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T1
             WHERE T.FD_EMPID = T1.EMPID)
     WHERE EXISTS
     (SELECT 1
              FROM (SELECT T.FD_DATE, --考勤日期
                           T.EMPID, --员工工号
                           EMPNAME, --员工名称
                           CASE
                             WHEN T.NEEDCLOCK = '0' THEN
                              '1'
                             WHEN (TO_DATE(T.FD_DATE ||
                                           NVL(T.AM_WORKONTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T1.FD_MIN_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss')) AND
                                  (TO_DATE(T1.FD_MAX_ATTDTIME,
                                           'yyyy-mm-ddhh24:mi:ss') >=
                                  TO_DATE(T.FD_DATE ||
                                           NVL(T.PM_WORKOFFTIME, '00:00:') || '00',
                                           'yyyy-mm-ddhh24:mi:ss')) THEN
                              '1'
                             ELSE
                              '-1'
                           END AS A --打卡是否正常  1 正常 -1 不正常
                      FROM TB_OA_ATTEND_DUTY T
                      LEFT JOIN TB_PEPMGM_ATTDINFO_COUNT T1
                        ON T.EMPID = T1.FD_EMPID
                       AND T.FD_DATE = T1.FD_DATE
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T2
             WHERE T.FD_DATE = T2.FD_DATE)
       AND T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
	------------分段提交------------------------------
    commit;
      DBMS_OUTPUT.PUT_LINE('更新加班数据执行完毕，准备汇总最终状态');
	-----------汇总最终状态-------------------------
    UPDATE TB_PEPMGM_ATTDINFO_COUNT T
       SET (FD_FINALSTS) = --最终状态字段
           (SELECT A
              FROM (SELECT T.FD_EMPID AS EMPID,
              CASE                     WHEN T.FD_ISWORKDAY = '0' THEN '1'
			               WHEN T.FD_FLAG = '1' AND T.FD_ADJUSTSTS IS NULL AND T.FD_LEAVESTS IS NULL THEN '1' --正常
                           WHEN T.FD_FLAG = '1' AND T.FD_ADJUSTSTS = '130'  THEN '3' --正常调整为异常
                           WHEN T.FD_FLAG = '-1' AND T.FD_ADJUSTSTS = '130'  THEN '3' --异常调整为异常
						   WHEN T.FD_FLAG = '-1' AND T.FD_APPEALSTS IS NULL AND FD_ADJUSTSTS IS NULL AND T.FD_LEAVESTS IS NULL THEN '2' --异常
						   WHEN T.FD_FLAG = '-1' AND T.FD_LEAVESTS = '2' THEN '4' --异常请假
						   WHEN T.FD_FLAG = '-1' AND (T.FD_LEAVESTS = '1' or T.FD_LEAVESTS = '3') THEN '2' --异常
						   WHEN T.FD_FLAG = '1' AND T.FD_LEAVESTS = '2' THEN '4' --异常请假
						   WHEN T.FD_FLAG = '1' AND (T.FD_LEAVESTS = '1' or T.FD_LEAVESTS = '3') THEN '1' --异常请假
						   WHEN T.FD_FLAG = '-1' AND T.FD_ADJUSTSTS = '120' THEN '5' --异常调整为正常
						   WHEN T.FD_FLAG = '1' AND T.FD_ADJUSTSTS = '120' THEN '5' --正常调整为正常
						   WHEN T.FD_FLAG = '-1' AND T.FD_APPEALSTS = '1' THEN '6' --异常
						   WHEN T.FD_FLAG = '-1' AND T.FD_APPEALSTS = '2' THEN '7' --正常申诉通过
						   WHEN T.FD_FLAG = '-1' AND T.FD_APPEALSTS = '3' THEN '8' --异常常申诉不通过
						   WHEN T.FD_ADJUSTSTS = '160' THEN '9' --调休
						   
						   END AS A
                           FROM TB_PEPMGM_ATTDINFO_COUNT T                            
                     WHERE T.FD_DATE = TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'),
                                               'YYYY-MM-DD')
                    /* AND T.NEEDCLOCK = '1'*/
                    ) T1
             WHERE T.FD_EMPID = T1.EMPID)
     WHERE T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
	------------分段提交------------------------------
    commit;
    
  -----------当考勤状态为旷工1整天时，迟到次数更新为0-------------------------
   UPDATE TB_PEPMGM_ATTDINFO_COUNT T
       SET (FD_EARLYCOUNT) = '0'
        where (T.FD_ABSENTDAY='1'or T.FD_FINALSTS='7' or t.FD_FINALSTS='5') and T.FD_ADJUSTSTS<>'150'                       
           and  T.FD_DATE =
                TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD') ;
	------------分段提交------------------------------
    commit;
    
    
     -----------当考勤状态为旷工1整天时，迟早退次数更新为0-------------------------
   UPDATE TB_PEPMGM_ATTDINFO_COUNT T
       SET (FD_LATECOUNT) = '0'
               where (T.FD_ABSENTDAY='1'or T.FD_FINALSTS='7' or t.FD_FINALSTS='5') and T.FD_ADJUSTSTS<>'140' --当考勤状态为旷工1整天时，迟早退次数更新为0                        
     and  T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
	------------分段提交------------------------------
    commit;
              
    
     -----------修正旷工天数，当请假半天原旷工天数为1时修改为0.5-------------------------
   UPDATE TB_PEPMGM_ATTDINFO_COUNT T
       SET (FD_ABSENTDAY) = '0.5'--旷工天数
     WHERE T.FD_ABSENTDAY='1'and T.FD_FINALSTS='4' and (t.FD_LEAVEHOURS='3' or t.FD_LEAVEHOURS='4.5') AND T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
	------------分段提交------------------------------
    commit;
    
         -----------修正正常天数，一天正常，后来请假半天-------------------------
   UPDATE TB_PEPMGM_ATTDINFO_COUNT T
       SET (T.FD_NORMALDAY) = '0.5'--正常天数
     WHERE T.FD_NORMALDAY='1'and T.FD_FINALSTS='4' and (t.FD_LEAVEHOURS='3' or t.FD_LEAVEHOURS='4.5') AND T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
	------------分段提交------------------------------
    commit;
  
    -------------------------------------------------------------------------
    --日志记录
    OI_RETCODE := 1; --设置正常状态为1 成功状态
    COMMIT; --非特殊处理只能在最后一次提交
    PKG_R001_RCG_ATTEND.VS_END_TM := SYSTIMESTAMP;
    PROC_ETL_LOG(IS_DATE,
                 PKG_R001_RCG_ATTEND.VS_OWNER,
                 PKG_R001_RCG_ATTEND.VS_PROCEDURE_NAME,
                 PKG_R001_RCG_ATTEND.VS_STATR_TM,
                 PKG_R001_RCG_ATTEND.VS_END_TM,
                 PKG_R001_RCG_ATTEND.VI_ERRORCODE,
                 PKG_R001_RCG_ATTEND.VS_ERRORTEXT);
    --异常处理
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK; --数据回滚
      DBMS_OUTPUT.PUT_LINE('sqlcode：' || SQLCODE);
      DBMS_OUTPUT.PUT_LINE('sqlerrm：' || SQLERRM);
      PKG_R001_RCG_ATTEND.VI_ERRORCODE := SQLCODE; --设置异常代码
      PKG_R001_RCG_ATTEND.VS_ERRORTEXT := SUBSTR(SQLERRM, 1, 200); --设置异常描述
      OI_RETCODE                      := -1; --设置异常状态为-1
      --插入日志表，记录错误
      PROC_ETL_LOG(IS_DATE,
                   PKG_R001_RCG_ATTEND.VS_OWNER,
                   PKG_R001_RCG_ATTEND.VS_PROCEDURE_NAME,
                   PKG_R001_RCG_ATTEND.VS_STATR_TM,
                   SYSTIMESTAMP,
                   PKG_R001_RCG_ATTEND.VI_ERRORCODE,
                   PKG_R001_RCG_ATTEND.VS_ERRORTEXT);
      PKG_R001_RCG_ATTEND.VI_ERRORCODE := NULL;
      PKG_R001_RCG_ATTEND.VS_ERRORTEXT := NULL;
  END SP_R00101_EMP_CHK_FLAG;
  PROCEDURE SP_R00101_ATTEND_DAY(IS_DATE    IN VARCHAR2, --输入变量，传入跑批日期
                                 OI_RETCODE OUT INTEGER --输出变量，用来标识存储过程执行过程中是否出现异常
                                 ) IS
    /*-- AUTHOR  : 李蛟
    -- CREATED : 2016/11/18 15:03:28
    -- PURPOSE : 考勤-员工每日考勤表  */
    /*-----------------------------------------------------------------
       -- 程序名
       --      SP_R00101_ATTEND_DAY
       -- 用途
       --
       --修改记录：
    
    -----------------------------------------------------------------*/
  BEGIN
    PKG_R001_RCG_ATTEND.VS_STATR_TM := SYSTIMESTAMP;
    SELECT T.USERNAME
      INTO PKG_R001_RCG_ATTEND.VS_OWNER
      FROM SYS.USER_USERS T;
    PKG_R001_RCG_ATTEND.VS_PROCEDURE_NAME := 'SP_R00101_ATTEND_DAY';
  
    -------------------------------------------------------------------------
    -------清除目标表数据---------
    DELETE FROM TB_OA_ATTEND_DAY T
     WHERE T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
    COMMIT;
    DELETE FROM TB_OA_ATTEND_HOURS T
     WHERE T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
    COMMIT;
    INSERT INTO TB_OA_ATTEND_DAY
      (FD_DATE --考勤日期
      ,
       FD_EMPID --员工工号
      ,
       FD_EMPNME --姓名
      ,
       FD_DAY21 --上月21号 1正常-1异常
      ,
       FD_DAY22 --上月22号 1正常-1异常
      ,
       FD_DAY23 --上月23号 1正常-1异常
      ,
       FD_DAY24 --上月24号 1正常-1异常
      ,
       FD_DAY25 --上月25号 1正常-1异常
      ,
       FD_DAY26 --上月26号 1正常-1异常
      ,
       FD_DAY27 --上月27号 1正常-1异常
      ,
       FD_DAY28 --上月28号 1正常-1异常
      ,
       FD_DAY29 --上月29号 1正常-1异常
      ,
       FD_DAY30 --上月30号 1正常-1异常
      ,
       FD_DAY31 --上月31号 1正常-1异常
      ,
       FD_DAY1 --本月1号 1正常-1异常
      ,
       FD_DAY2 --本月2号 1正常-1异常
      ,
       FD_DAY3 --本月3号 1正常-1异常
      ,
       FD_DAY4 --本月4号 1正常-1异常
      ,
       FD_DAY5 --本月5号 1正常-1异常
      ,
       FD_DAY6 --本月6号 1正常-1异常
      ,
       FD_DAY7 --本月7号 1正常-1异常
      ,
       FD_DAY8 --本月8号 1正常-1异常
      ,
       FD_DAY9 --本月9号 1正常-1异常
      ,
       FD_DAY10 --本月10号 1正常-1异常
      ,
       FD_DAY11 --本月11号 1正常-1异常
      ,
       FD_DAY12 --本月12号 1正常-1异常
      ,
       FD_DAY13 --本月13号 1正常-1异常
      ,
       FD_DAY14 --本月14号 1正常-1异常
      ,
       FD_DAY15 --本月15号 1正常-1异常
      ,
       FD_DAY16 --本月16号 1正常-1异常
      ,
       FD_DAY17 --本月17号 1正常-1异常
      ,
       FD_DAY18 --本月18号 1正常-1异常
      ,
       FD_DAY19 --本月19号 1正常-1异常
      ,
       FD_DAY20 --本月20号 1正常-1异常
       
       )
    
      SELECT TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD'), --每月月底考勤日期
             T.FD_EMPID, --员工工号
             T.FD_EMPNME,
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '21',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '22',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '23',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '24',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '25',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '26',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '27',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '28',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '29',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '30',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '31',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '01',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '02',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '03',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '04',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '05',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '06',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '07',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '08',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '09',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '10',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '11',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '12',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '13',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '14',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '15',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '16',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '17',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '18',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '19',
                        T.FD_FINALSTS,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '20',
                        T.FD_FINALSTS,
                        NULL))
      
       FROM TB_PEPMGM_ATTDINFO_COUNT T
       WHERE T.FD_DATE >=
             TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '21'
         AND T.FD_DATE <=
             TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '20'
       GROUP BY T.FD_EMPID, T.FD_EMPNME;

    --分段式提交-------------
    COMMIT;
    INSERT INTO TB_OA_ATTEND_HOURS
      (FD_DATE --考勤日期
      ,
       FD_EMPID --员工工号
      ,
       FD_EMPNME --姓名
      ,
       FD_DAY1 --公出
      ,
       FD_DAY2 --年假
      ,
       FD_DAY3 --事假
      ,
       FD_DAY4 --病假
      ,
       FD_DAY5 --婚假
      ,
       FD_DAY6 --产假
      ,
       FD_DAY7 --计划生育假
      ,
       FD_DAY8 --丧假
      ,
       FD_DAY9 --探亲假
      ,
       FD_DAY10 --公益假
      ,
       FD_DAY11 --工伤假
      ,
       FD_DAY12 --加班
       )
               
      SELECT TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD'), --每月月底考勤日期
             T.FD_EMPID, --员工编号
             T.FD_EMPNME, --员工编号
             SUM(DECODE(T.FD_LEAVETYP, '010', T.A, NULL)), --公出
             SUM(DECODE(T.FD_LEAVETYP, '020', T.A, NULL)), --年假
             SUM(DECODE(T.FD_LEAVETYP, '030', T.A, NULL)), --事假
             SUM(DECODE(T.FD_LEAVETYP, '040', T.A, NULL)), --病假
             SUM(DECODE(T.FD_LEAVETYP, '050', T.A, NULL)), --婚假
             SUM(DECODE(T.FD_LEAVETYP, '060', T.A, NULL)), --产假
             SUM(DECODE(T.FD_LEAVETYP, '070', T.A, NULL)), --计划生育假
             SUM(DECODE(T.FD_LEAVETYP, '080', T.A, NULL)), --丧假
             SUM(DECODE(T.FD_LEAVETYP, '090', T.A, NULL)), --探亲假
             SUM(DECODE(T.FD_LEAVETYP, '100', T.A, NULL)), --公益假
             SUM(DECODE(T.FD_LEAVETYP, '110', T.A, NULL)), --工伤假
             SUM(DECODE(T.FD_LEAVETYP, '999', T.A, NULL)) --加班
      
        FROM （SELECT T.FD_EMPID, --员工编号
             T1.FD_EMPNME, --员工编号
             T.FD_LEAVETYP, -- 请假类型
             T.A -- 请假时间
        FROM ((SELECT T.FD_SERIALNUM, --请假编号
                      T.FD_EMPID, --员工编号
                      T.FD_LEAVETYP, -- 请假类型
                      nvl(SUM(T.FD_DAYS), 0) AS A --请假时间
                 FROM (select * from TB_OA_LEAVEINFO where FD_SERIALNUM not in(select a.FD_SERIALNUM from TB_OA_LEAVEINFO a,TB_OA_LEAVEINFO_CLEAR b where a.FD_SERIALNUM=b.FD_SERIALNUM and b.FD_CUR_STATUS='2')) T

                WHERE T.FD_CUR_STATUS = '2'
                  AND TO_CHAR(TO_DATE(T.FD_BGNTIME, 'YYYY-MM-DD HH24:MI:SS'),
                              'YYYY-MM-DD') >=
                      TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '21'
                  AND TO_CHAR(TO_DATE(T.FD_ENDTIME, 'YYYY-MM-DD HH24:MI:SS'),
                              'YYYY-MM-DD') <=
                      TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '20'
                GROUP BY T.FD_EMPID, T.FD_SERIALNUM, T.FD_LEAVETYP) T left join
              TB_PEPMGM_EMPINFO T1 on T.FD_EMPID = T1.FD_EMPID)
      UNION ALL (SELECT FD_EMPID, --员工id              ---此部分是请假时间
                        FD_EMPNME, --员工名称
                        '999' AS FD_LEAVETYP, --请假类型
                        SUM(FD_WORKHOURS)
                   FROM tb_oa_overtimeinfo_SPLIT T
                  where TO_CHAR(TO_DATE(T.FD_BGNTIME,
                                        'YYYY-MM-DD HH24:MI:SS'),
                                'YYYY-MM-DD') >=
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '21'  
                    AND TO_CHAR(TO_DATE(T.FD_ENDTIME,
                                        'YYYY-MM-DD HH24:MI:SS'),
                                'YYYY-MM-DD') <=
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyy-MM-dd'), 'yyyy-MM-') || '20' 
                    and T.FD_CUR_STATUS = '2' --审批通过
                  GROUP BY FD_EMPID, FD_EMPNME)) T
       GROUP BY T.FD_EMPID, T.FD_EMPNME;
  
    -------------------------------------------------------------------------
    --日志记录
    OI_RETCODE := 1; --设置正常状态为1 成功状态
    COMMIT; --非特殊处理只能在最后一次提交
    PKG_R001_RCG_ATTEND.VS_END_TM := SYSTIMESTAMP;
    PROC_ETL_LOG(IS_DATE,
                 PKG_R001_RCG_ATTEND.VS_OWNER,
                 PKG_R001_RCG_ATTEND.VS_PROCEDURE_NAME,
                 PKG_R001_RCG_ATTEND.VS_STATR_TM,
                 PKG_R001_RCG_ATTEND.VS_END_TM,
                 PKG_R001_RCG_ATTEND.VI_ERRORCODE,
                 PKG_R001_RCG_ATTEND.VS_ERRORTEXT);
    --异常处理
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK; --数据回滚
      DBMS_OUTPUT.PUT_LINE('sqlcode：' || SQLCODE);
      DBMS_OUTPUT.PUT_LINE('sqlerrm：' || SQLERRM);
      PKG_R001_RCG_ATTEND.VI_ERRORCODE := SQLCODE; --设置异常代码
      PKG_R001_RCG_ATTEND.VS_ERRORTEXT := SUBSTR(SQLERRM, 1, 200); --设置异常描述
      OI_RETCODE                      := -1; --设置异常状态为-1
      --插入日志表，记录错误
      PROC_ETL_LOG(IS_DATE,
                   PKG_R001_RCG_ATTEND.VS_OWNER,
                   PKG_R001_RCG_ATTEND.VS_PROCEDURE_NAME,
                   PKG_R001_RCG_ATTEND.VS_STATR_TM,
                   SYSTIMESTAMP,
                   PKG_R001_RCG_ATTEND.VI_ERRORCODE,
                   PKG_R001_RCG_ATTEND.VS_ERRORTEXT);
      PKG_R001_RCG_ATTEND.VI_ERRORCODE := NULL;
      PKG_R001_RCG_ATTEND.VS_ERRORTEXT := NULL;
  END SP_R00101_ATTEND_DAY;


END PKG_R001_RCG_ATTEND;

/
