CREATE FUNCTION "F_QMONTH"
/***********************************************************************************/
/*函数功能：内部资格证书，到期日之后2年内继续显示，超过2年的不予显示。       */
/*输入参数：年月                                                                 */
/*输出参数：所查月的天数                                                             */
/*创建日期：2016                                                                  */
/*作    者：                                                                       */
/***********************************************************************************/

(V_JIDU varchar2)
return varchar2 as

  V_MONTHS   string(100);

begin


IF  V_JIDU='01'   THEN

select    (to_char(sysdate ,'yyyy-')||'01'||to_char(sysdate ,'yyyy-')||'02'||to_char(sysdate ,'yyyy-')||'03')

into V_MONTHS from dual;

 elsif  V_JIDU='02'  then
select    (to_char(sysdate ,'yyyy-')||'04'||to_char(sysdate ,'yyyy-')||'05'||to_char(sysdate ,'yyyy-')||'06')

into V_MONTHS from dual;


  elsif  V_JIDU='03'  then
select   (to_char(sysdate ,'yyyy-')||'07'||to_char(sysdate ,'yyyy-')||'08'||to_char(sysdate ,'yyyy-')||'09')

into V_MONTHS from dual;


 else
select   (to_char(sysdate ,'yyyy-')||'10'||to_char(sysdate ,'yyyy-')||'11'||to_char(sysdate ,'yyyy-')||'12')

into V_MONTHS from dual;




    END IF;




return (V_MONTHS);



 end ;
/
