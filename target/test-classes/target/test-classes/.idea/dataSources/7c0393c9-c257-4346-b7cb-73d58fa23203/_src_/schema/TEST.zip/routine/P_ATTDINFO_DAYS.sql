CREATE PROCEDURE        "P_ATTDINFO_DAYS"(FD_LAST_DATE in varchar2)
/**************************************************************/
  /*Function:考勤日报表生成                                  */
  /*InputParam:                                       */
  /*OutputParam:                                                */
  /*Create-Date:Aug. 2th,2017                                   */
  /*Author:Pansky-cx                                            */
  /**************************************************************/
is
  --变量声明
    CURSOR C_LEAVE(FD_DATE in varchar2) is    
   
select t.fd_date,t.fd_empid,t.fd_empnme,t.Fd_Normalday,s.fd_leavetyp,s.fd_hours
    from (select * from tb_pepmgm_attdinfo_count where fd_date= FD_LAST_DATE AND fd_isworkday='1') t
    inner join (select * from tb_oa_leaveinfo_split where FD_SERIALNUM not in (
    select FD_SERIALNUM from tb_oa_leaveinfo_clear where fd_cur_status='2')
    and fd_bgntime like '%'||FD_LAST_DATE||'%')s 
    on t.fd_empid=s.fd_empid 
     and t.FD_FINALSTS = '4';
     C_ROW C_LEAVE%ROWTYPE;
BEGIN
  --删除执行考勤日期的考勤数据
  delete from TB_ATTDINFO_DAY_TJ t where t.fd_date=FD_LAST_DATE;
  commit;

    /**
  插入正常考勤(天)数据
  **/
  insert into TB_ATTDINFO_DAY_TJ
  (FD_DATE, FD_EMPID, FD_EMPNME, FD_NORMAL_DAYS, FD_ABSENT_DAYS,FD_EARLY_TIMES,FD_LATE_TIMES,FD_OVERTIME_DAYS)
  select t.fd_date,t.fd_empid,t.fd_empnme,case   when (t.FD_FINALSTS = '1'or t.FD_FINALSTS = '5' or t.FD_FINALSTS = '7') then '1'--最终状态为正常、申诉通过、调整正常时，正常天数为1
                                                  when t.FD_FINALSTS = '4' and (t.FD_NORMALDAY='1' or t.FD_NORMALDAY='0.5') and t.fd_leavehours='4.5'  then '0.5'--最终状态请假，请假4.5小时，存在正常天数则为0.5天
                                                   when t.FD_FINALSTS = '4' and (t.FD_NORMALDAY='1' or t.FD_NORMALDAY='0.5') and t.fd_leavehours='3'  then '0.5'--最终状态请假，请假3.0小时，存在正常天数则为0.5天
                                                    when t.FD_FINALSTS = '4' and t.fd_appealsts='2' and t.fd_leavehours='3'  then '0.5'--请假半天，半天申诉通过。则为0.5天
                                                   when t.FD_FINALSTS = '2' and t.FD_ABSENTDAY = '1' then '0'--最终状态为异常、旷工1天则为0
                                                   when t.FD_FINALSTS = '3' then '0'--最终状态为调整为异常时，正常天数0
                                                   when t.FD_FINALSTS = '4' and t.fd_leavehours='7.5' then '0' --请假、请假一整天  
                                                   when t.FD_FINALSTS = '4' and (t.fd_leavehours='4.5' or t.fd_leavehours='3') and t.FD_ABSENTDAY = '0.5' and t.FD_NORMALDAY='0.5' then '0.5' --半天请假、半天旷工、半天正常      
                                                   when t.FD_FINALSTS = '4' and (t.fd_leavehours='4.5' or t.fd_leavehours='3') and t.FD_ABSENTDAY = '0.5' then '0' --请假半天天 ，旷工半天                                                             
                                                   when t.FD_FINALSTS <> '2' and t.FD_ABSENTDAY = '1' then '0' --旷工1天                                                  
                                                   when t.FD_FINALSTS = '2' and t.FD_ABSENTDAY = '0.5' and (t.FD_EARLYCOUNT<>'1' and t.FD_LATECOUNT<>'1') then '0.5'--旷工半天，不存在迟到早退
                                                   when t.FD_FINALSTS = '2' and t.FD_ABSENTDAY = '0.5' and (t.FD_EARLYCOUNT='1' or t.FD_LATECOUNT='1') then '0'--旷工半天、存在早退或者迟到
                                                   when t.FD_FINALSTS = '2' and (t.FD_EARLYCOUNT='1' and t.FD_LATECOUNT='1') then '0'--同时存在早退、迟到
                                                   when t.FD_FINALSTS = '2' and (t.FD_EARLYCOUNT='1' or t.FD_LATECOUNT='1') then '0.5' --迟到或者早退
                                                   when (t.FD_FINALSTS = '6' or t.FD_FINALSTS = '8') and t.FD_EARLYCOUNT='1' and t.FD_LATECOUNT='1' then '0'--最终状态申诉中或者申诉不通过，同时存在早退迟到
                                                   when (t.FD_FINALSTS = '6' or t.FD_FINALSTS = '8') and t.FD_EARLYCOUNT='1' and t.FD_LATECOUNT<>'1' and t.FD_ABSENTDAY = '0.5' then '0' --迟到+旷工0.5
                                                   when (t.FD_FINALSTS = '6' or t.FD_FINALSTS = '8') and t.FD_EARLYCOUNT<>'1' and t.FD_LATECOUNT='1' and t.FD_ABSENTDAY = '0.5' then '0'--早退+旷工0.5
                                                   when (t.FD_FINALSTS = '6' or t.FD_FINALSTS = '8') and (t.FD_EARLYCOUNT='1' OR t.FD_LATECOUNT='1') and t.FD_NORMALDAY = '0.5' then '0.5' --早退/迟到+正常0.5
                                                   when (t.FD_FINALSTS = '6' or t.FD_FINALSTS = '8') and t.FD_ABSENTDAY = '0.5' and t.FD_NORMALDAY is null  then '0.5' --旷工0.5，正常为空
                                                   when (t.FD_FINALSTS = '6' or t.FD_FINALSTS = '8') and t.FD_ABSENTDAY = '0.5' and t.FD_NORMALDAY='0.5'  then '0.5'    --旷工0.5，正常0.5                                           
                                            end as tt,
                                            case when (t.FD_FINALSTS = '1'or t.FD_FINALSTS = '5' or t.FD_FINALSTS = '7') then '0'   
                                                  when t.FD_FINALSTS = '2' and t.FD_ABSENTDAY = '0.5' then '0.5'                                            
                                                  when t.FD_FINALSTS = '2' and t.FD_ABSENTDAY = '1' then '1'                                                  
                                                  when (t.FD_FINALSTS = '6' or t.FD_FINALSTS = '8') and (t.FD_EARLYCOUNT='1' OR t.FD_LATECOUNT='1') and t.FD_NORMALDAY = '0.5' then '0'
                                                  when (t.FD_FINALSTS = '6' or t.FD_FINALSTS = '8') and t.FD_EARLYCOUNT='1' and t.FD_LATECOUNT<>'1' then '0.5'
                                                  when (t.FD_FINALSTS = '6' or t.FD_FINALSTS = '8') and t.FD_EARLYCOUNT='1' and t.FD_LATECOUNT='1' then '0'
                                                   when t.FD_FINALSTS = '4' and t.fd_appealsts='2' and (t.fd_leavehours='4.5' or t.fd_leavehours='3')  then '0'--请假半天，半天申诉通过。则为0天
                                                  when t.FD_FINALSTS = '4' AND (t.fd_leavehours='4.5' or t.fd_leavehours='3') AND t.FD_ABSENTDAY='1' then '0.5'
                                                  when t.FD_FINALSTS = '4' and (t.fd_leavehours='4.5' or t.fd_leavehours='3') and t.FD_ABSENTDAY = '0.5' and t.FD_NORMALDAY='0.5' then '0' --半天请假、半天旷工、半天正常 
                                                  when t.FD_FINALSTS = '4' and (t.fd_leavehours='4.5' or t.fd_leavehours='3') and t.FD_ABSENTDAY = '0.5' then '0.5' --请假半天天 ，旷工半天                                                
                                                  when t.FD_FINALSTS = '4' AND t.fd_leavehours='7.5' then '0'
                                                  when t.FD_FINALSTS = '4' and (t.FD_NORMALDAY='1' or t.FD_NORMALDAY='0.5') and t.fd_leavehours='4.5'  then '0'
                                                   when t.FD_FINALSTS = '4' and (t.FD_NORMALDAY='1' or t.FD_NORMALDAY='0.5') and t.fd_leavehours='3'  then '0'
                                                  when t.FD_FINALSTS = '3' then '1'
                                                  when t.FD_FINALSTS <> '2' and t.FD_ABSENTDAY = '1' then '1' 
                                                  when (t.FD_FINALSTS = '6' or t.FD_FINALSTS = '8') and t.FD_ABSENTDAY = '0.5' and t.FD_NORMALDAY is null  then '0.5'
                                                  when (t.FD_FINALSTS = '6' or t.FD_FINALSTS = '8') and t.FD_ABSENTDAY = '0.5' and t.FD_NORMALDAY='0.5'  then '0.5'                                       
                                            end as fd_absentday,
                                            t.FD_EARLYCOUNT,t.fd_latecount,t.fd_overtimehours
    from tb_pepmgm_attdinfo_count t
   where 
     t.fd_date = FD_LAST_DATE AND t.fd_isworkday='1';    
   commit;
   

   
     
     --插入请假记录数据
   FOR C_ROW IN C_LEAVE(FD_LAST_DATE) LOOP
    DBMS_OUTPUT.PUT_LINE(C_ROW.fd_leavetyp);
      
        if C_ROW.fd_leavetyp='010' then
                update TB_ATTDINFO_DAY_TJ set 
                        (fd_bussine_leave) = 
                                (select case  when C_ROW.fd_hours='3.0' then '0.5'
                                               when C_ROW.fd_hours='4.5' then '0.5'
                                               when C_ROW.fd_hours='7.5' then '1'
                                        end as tt 
                                from tb_pepmgm_attdinfo_count t
                                where t.fd_empid = C_ROW.fd_empid
                                and t.fd_date = FD_LAST_DATE)
                where fd_date = C_ROW.fd_date
                and fd_empid = C_ROW.fd_empid;
                
        elsif C_ROW.fd_leavetyp='020' then          
                update TB_ATTDINFO_DAY_TJ set 
                        (FD_ANNUAL_LEAVE) =
                                (select case when C_ROW.fd_hours='3.0' then '0.5'
                                                when C_ROW.fd_hours='4.5' then '0.5'
                                                when C_ROW.fd_hours='7.5' then '1'
                                        end as tt 
                                from tb_pepmgm_attdinfo_count t
                                where t.fd_empid = C_ROW.fd_empid
                                and t.fd_date = FD_LAST_DATE)
                where fd_date = C_ROW.fd_date
                and fd_empid = C_ROW.fd_empid;  
                      
        elsif C_ROW.fd_leavetyp='030' then
                update TB_ATTDINFO_DAY_TJ set
                        (FD_AFFAIR_LEAVE) =
                                (select case when C_ROW.fd_hours='3.0' then '0.5'
                                                when C_ROW.fd_hours='4.5' then '0.5'
                                                when C_ROW.fd_hours='7.5' then '1'
                                end as tt 
                                from tb_pepmgm_attdinfo_count t
                                 where t.fd_empid = C_ROW.fd_empid
                                and t.fd_date = FD_LAST_DATE)
                where fd_date = C_ROW.fd_date
                and fd_empid = C_ROW.fd_empid;
                
        elsif C_ROW.fd_leavetyp='040' then
                update TB_ATTDINFO_DAY_TJ set
                        (FD_SICK_LEAVE) =
                                (select case when C_ROW.fd_hours='3.0' then '0.5'
                                                when C_ROW.fd_hours='4.5' then '0.5'
                                                when C_ROW.fd_hours='7.5' then '1'
                                        end as tt 
                                from tb_pepmgm_attdinfo_count t
                                where t.fd_empid = C_ROW.fd_empid
                                and t.fd_date = FD_LAST_DATE)
                where fd_date = C_ROW.fd_date
                and fd_empid = C_ROW.fd_empid;
  
        elsif C_ROW.fd_leavetyp='050' then
                update TB_ATTDINFO_DAY_TJ set
                        (FD_MARRIED_LEAVE) =
                                (select case when C_ROW.fd_hours='3.0' then '0.5'
                                                when C_ROW.fd_hours='4.5' then '0.5'
                                                when C_ROW.fd_hours='7.5' then '1'
                                        end as tt 
                                 from tb_pepmgm_attdinfo_count t
                                 where t.fd_empid = C_ROW.fd_empid
                                and t.fd_date = FD_LAST_DATE)
                where fd_date = C_ROW.fd_date
                and fd_empid = C_ROW.fd_empid; 
                        
        elsif C_ROW.fd_leavetyp='060' then
                update TB_ATTDINFO_DAY_TJ set
                        (FD_MATER_LEAVE) =
                                (select case when C_ROW.fd_hours='3.0' then '0.5'
                                                 when C_ROW.fd_hours='4.5' then '0.5'   
                                                when C_ROW.fd_hours='7.5' then '1'
                                        end as tt 
                                from tb_pepmgm_attdinfo_count t
                                where t.fd_empid = C_ROW.fd_empid
                                and t.fd_date = FD_LAST_DATE)
                where fd_date = C_ROW.fd_date
                and fd_empid = C_ROW.fd_empid;   
    
        elsif C_ROW.fd_leavetyp='070' then
                update TB_ATTDINFO_DAY_TJ set
                        (FD_PLAN_LEAVE) =
                                (select case when C_ROW.fd_hours='3.0' then '0.5'
                                                when C_ROW.fd_hours='4.5' then '0.5'
                                                when C_ROW.fd_hours='7.5' then '1'
                                        end as tt 
                                from tb_pepmgm_attdinfo_count t
                                where t.fd_empid = C_ROW.fd_empid
                                and t.fd_date = FD_LAST_DATE)
                where fd_date = C_ROW.fd_date
                and fd_empid = C_ROW.fd_empid;  
  
        elsif C_ROW.fd_leavetyp='080' then
                update TB_ATTDINFO_DAY_TJ set
                        (FD_FUNERNAL_LEAVE) =
                                (select case when C_ROW.fd_hours='3.0' then '0.5'
                                                when C_ROW.fd_hours='4.5' then '0.5'
                                                when C_ROW.fd_hours='7.5' then '1'
                                        end as tt 
                                from tb_pepmgm_attdinfo_count t
                                where t.fd_empid = C_ROW.fd_empid
                                and t.fd_date = FD_LAST_DATE)
                where fd_date = C_ROW.fd_date
                and fd_empid = C_ROW.fd_empid;  
    
        elsif C_ROW.fd_leavetyp='090' then
                update TB_ATTDINFO_DAY_TJ set
                        (FD_HOME_LEAVE) =
                                (select case when C_ROW.fd_hours='3.0' then '0.5'
                                                when C_ROW.fd_hours='4.5' then '0.5'
                                                when C_ROW.fd_hours='7.5' then '1'
                                        end as tt 
                                from tb_pepmgm_attdinfo_count t
                                where t.fd_empid = C_ROW.fd_empid
                                and t.fd_date = FD_LAST_DATE)
                where fd_date = C_ROW.fd_date
                and fd_empid = C_ROW.fd_empid; 
                
        elsif C_ROW.fd_leavetyp='100' then
                update TB_ATTDINFO_DAY_TJ set
                        (FD_WELFARE_LEAVE) =
                                (select case when C_ROW.fd_hours='3.0' then '0.5'
                                                when C_ROW.fd_hours='4.5' then '0.5'
                                                when C_ROW.fd_hours='7.5' then '1'
                                        end as tt 
                                from tb_pepmgm_attdinfo_count t
                                where t.fd_empid = C_ROW.fd_empid
                                and t.fd_date = FD_LAST_DATE)
                where fd_date = C_ROW.fd_date
                and fd_empid = C_ROW.fd_empid;  
                 
        elsif C_ROW.fd_leavetyp='110' then
                update TB_ATTDINFO_DAY_TJ set
                        (FD_INJURY_LEAVE) =
                                (select case when C_ROW.fd_hours='3.0' then '0.5'
                                                when C_ROW.fd_hours='4.5' then '0.5'
                                                when C_ROW.fd_hours='7.5' then '1'
                                        end as tt 
                                from tb_pepmgm_attdinfo_count t
                                where t.fd_empid = C_ROW.fd_empid
                                and t.fd_date = FD_LAST_DATE)
                where fd_date = C_ROW.fd_date
                and fd_empid = C_ROW.fd_empid;
                

    end if;
  commit;
  --全天请假，则当天早退、迟到更新为0
  update tb_attdinfo_day_tj t set t.fd_late_times='0' where t.fd_empid=C_ROW.fd_empid and t.fd_date=FD_LAST_DATE and C_ROW.fd_hours='7.5';
  update tb_attdinfo_day_tj t set t.fd_early_times='0' where t.fd_empid=C_ROW.fd_empid and t.fd_date=FD_LAST_DATE and C_ROW.fd_hours='7.5';
  --请假3.0小时，表示上午请假，则将迟到更新为0
  update tb_attdinfo_day_tj t set t.fd_late_times='0' where t.fd_empid=C_ROW.fd_empid and t.fd_date=FD_LAST_DATE and C_ROW.fd_hours='3.0';
    --请假4.5小时，表示下午请假，则将早退更新为0
  update tb_attdinfo_day_tj t set t.fd_early_times='0' where t.fd_empid=C_ROW.fd_empid and t.fd_date=FD_LAST_DATE and C_ROW.fd_hours='4.5';
  commit;
  END LOOP;
    --确定了请假天数没问题、早退、迟到没问题，若请假加早退加迟到为一整天，更新正常天数为0，更新旷工天数为0
update TB_ATTDINFO_DAY_TJ t set  t.fd_normal_days = '0'
           where t.fd_date = FD_LAST_DATE and nvl(t.FD_BUSSINE_LEAVE,'0')+ nvl(t.fd_annual_leave,'0')+nvl(t.fd_affair_leave,'0')
  +nvl(t.fd_sick_leave,'0')+nvl(t.fd_married_leave,'0')+nvl(t.fd_mater_leave,'0')+nvl(t.FD_PLAN_LEAVE,'0')+nvl(t.FD_funernal_LEAVE,'0')
  +nvl(t.FD_home_LEAVE,'0')+nvl(t.FD_welfare_LEAVE,'0')+nvl(t.FD_injury_LEAVE,'0')+t.fd_late_times/2+t.fd_early_times/2 ='1';
update TB_ATTDINFO_DAY_TJ t set 
          t.fd_absent_days = '0'
           where t.fd_date = FD_LAST_DATE and nvl(t.FD_BUSSINE_LEAVE,'0')+ nvl(t.fd_annual_leave,'0')+nvl(t.fd_affair_leave,'0')
  +nvl(t.fd_sick_leave,'0')+nvl(t.fd_married_leave,'0')+nvl(t.fd_mater_leave,'0')+nvl(t.FD_PLAN_LEAVE,'0')+nvl(t.FD_funernal_LEAVE,'0')
  +nvl(t.FD_home_LEAVE,'0')+nvl(t.FD_welfare_LEAVE,'0')+nvl(t.FD_injury_LEAVE,'0')+t.fd_late_times/2+t.fd_early_times/2 ='1';
  commit;
 
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    ROLLBACK;
end P_ATTDINFO_DAYS;
/
