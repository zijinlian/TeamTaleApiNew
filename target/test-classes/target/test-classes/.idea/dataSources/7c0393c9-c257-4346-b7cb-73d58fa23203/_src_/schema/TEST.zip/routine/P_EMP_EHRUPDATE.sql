CREATE PROCEDURE P_EMP_EHRUPDATE
/**************************************************************/
  /*Function:机构人员信息加工                                     */
  /*InputParam:                                       */
  /*OutputParam:                                                */
  /*Create-Date:Aug. 17th,2016                                   */
  /*Author:Pansky-cx                                            */
  /**************************************************************/
 AS



BEGIN






  ---( 每个月的月初1号 更新 )

  --IF  substr( to_char( sysdate,'YYYY-MM-DD'),9 ,10)='01' THEN


-------- 更新人员机构信息
merge into TB_PEPMGM_EMPINFO  a1 using    TMP_PEPMGM_EMPINFO_UPDATE a2
on(a1.fd_empid=a2.fd_empid)
when matched then
  update set  a1.fd_empnme=a2.fd_empnme,
  a1.fd_gender=a2.fd_gender,
  a1.fd_orgnme=a2.fd_orgnme,
  a1.fd_unitnme=a2.fd_unitnme,
  a1.fd_jobnme=a2.fd_jobnme,
  a1.fd_standard_jobnme=a2.fd_standard_jobnme,
  a1.fd_job_startdate=a2.fd_job_startdate,
  a1.fd_jobid=a2.fd_jobid,
  a1.fd_unitcde=a2.fd_unitcde,
  a1.fd_orgcde=a2.fd_orgcde,
  a1.fd_standjob_sysnum=a2.fd_standjob_sysnum,
  a1.fd_empstat=a2.fd_empstat,
  a1.fd_emptyp=a2.fd_emptyp,
  a1.fd_jobline=a2.fd_jobline,
 -- a1.fd_org_identify=a2.fd_org_identify,
  a1.fd_orgflag=a2.fd_orgflag,
 a1.fd_orglevel=a2.fd_orglevel,
  a1.fd_hiredate=a2.fd_hiredate,
  a1.fd_jointrade_date=a2.fd_jointrade_date,
  a1.fd_start_workdate=a2.fd_start_workdate,
  a1.fd_nation=a2.fd_nation,
  a1.fd_entry_mode=a2.fd_entry_mode,
  a1.fd_political_status=a2.fd_political_status,
  a1.fd_high_edu=a2.fd_high_edu,
  a1.fd_high_degree=a2.fd_high_degree,
  a1.fd_parentunit_systemno=a2.fd_parentunit_systemno,
  a1.fd_parent_org=a2.fd_parent_org,
  a1.fd_fact_unit=a2.fd_fact_unit,
  a1.fd_jobcode=a2.fd_jobcode,
 a1.fd_native_place=a2.fd_native_place,
  a1.fd_birth_place=a2.fd_birth_place,
  a1.fd_domicile_place=a2.fd_domicile_place,
 -- a1.fd_leaderid=a2.fd_leaderid,
  -- a1.fd_leadernme=a2.fd_leadernme,
 -- a1.fd_dept_org=a2.fd_dept_org,
  a1.fd_cred_num=a2.fd_cred_num
  when not matched then
    insert(a1.fd_empid,a1.fd_empnme,a1.fd_gender,a1.fd_orgnme,a1.fd_unitnme,a1.fd_jobnme,
    a1.fd_standard_jobnme,
    a1.fd_job_startdate,a1.fd_jobid,a1.fd_unitcde,a1.fd_orgcde,
   a1.fd_standjob_sysnum,
    a1.fd_empstat,a1.fd_emptyp,
    a1.fd_jobline,
  -- a1.fd_org_identify,
    a1.fd_orgflag,
   a1.fd_orglevel,
    a1.fd_hiredate,
    a1.fd_jointrade_date,
    a1.fd_start_workdate,
    a1.fd_nation,a1.fd_entry_mode,a1.fd_political_status,a1.fd_high_edu,a1.fd_high_degree,
    a1.fd_parentunit_systemno,
    a1.fd_parent_org,
    a1.fd_fact_unit,
    a1.fd_jobcode,
    a1.fd_native_place,
    a1.fd_birth_place,
    a1.fd_domicile_place,
   -- a1.fd_leaderid,
   --- a1.fd_leadernme,
   -- a1.fd_dept_org,
    a1.fd_cred_num)
    values(a2.fd_empid,a2.fd_empnme,a2.fd_gender,a2.fd_orgnme,a2.fd_unitnme,a2.fd_jobnme,
    a2.fd_standard_jobnme,
    a2.fd_job_startdate,a2.fd_jobid,a2.fd_unitcde,a2.fd_orgcde,
    a2.fd_standjob_sysnum,
    a2.fd_empstat,a2.fd_emptyp,
    a2.fd_jobline,
    --a2.fd_org_identify,
    a2.fd_orgflag,
    a2.fd_orglevel,
    a2.fd_hiredate,
    a2.fd_jointrade_date,
    a2.fd_start_workdate,
    a2.fd_nation,a2.fd_entry_mode,a2.fd_political_status,a2.fd_high_edu,a2.fd_high_degree,
    a2.fd_parentunit_systemno,
    a2.fd_parent_org,
    a2.fd_fact_unit,
    a2.fd_jobcode,
    a2.fd_native_place,
    a2.fd_birth_place,
    a2.fd_domicile_place,
    --a2.fd_leaderid,
    --a2.fd_leadernme,
    --a2.fd_dept_org,
    a2.fd_cred_num);


  COMMIT;
     --设置回滚点
   SAVEPOINT STAT;


------ 更新用户信息
merge into TB_SYS_USERINFO t1 using TB_PEPMGM_EMPINFO t2
on(t1.fd_username =t2.fd_empid)
when not matched then
  insert (t1.fd_username,t1.fd_password, t1.fd_name )
  values(t2.fd_empid,substr(t2.fd_cred_num,13,18),t2.fd_empnme)
;

-----加密

update TB_SYS_USERINFO  tt set tt.fd_password=lower(md5(tt.fd_password))  where  length(tt.fd_password)=6;


/**
merge into TB_SYS_USERINFO y1 using
(select lower(md5(substr(y2.fd_password,13,18))) as fd_password ,   y2.fd_username as fd_username  from  TB_SYS_USERINFO   y2  ) y3
on ( y1.fd_username=y3.fd_username)
when matched   then
  update set y1.fd_password=y3.fd_password
**/


--  END IF;

 --insert into ETL_LOG (DATA_DATE, OWNER, PROC_NAME, PROC_CNAME, START_DTTM, END_DTTM, MINUS_TM, LOG_FLG, ERRORCODE, ERRORTEXT)
--values ('2', 'FACTOR', 'P_EMP_EHRUPDATE', null, TO_DATE(TO_CHAR(SYSDATE,'DD-MM-YYYY :HH24:MI:SS'), 'dd-mm-yyyy hh24:mi:ss'), to_date('12-12-2016 09:44:40', 'dd-mm-yyyy hh24:mi:ss'), '0', '-1', -1840, 'ORA-01840: 输入值对于日期格式不够长');




  COMMIT;



EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    ---回滚到 节点
    ROLLBACK TO STAT;
END;
/
