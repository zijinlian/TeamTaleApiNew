CREATE VIEW V_LOGININFO AS select A.fd_date as fddate,
       p.fd_orgcde,

       p.fd_empid fdempid,
       p.fd_empnme fdempnm,
       p.fd_unitnme fdunitnm,
       p.fd_unitcde fdunitcde,
       decode(A.plevel, '0', '手机登陆', '1', 'PC登陆') logintyp
  from (select t.fd_date, t.fd_empid, '1' plevel
          from tb_sys_oper_log t
         where
           t.fd_url like 'http://21.36.2.225:8090%'
        union
        select t.fd_date, t.fd_empid, '0' plevel
          from tb_sys_oper_log t
        where
           t.fd_url like 'http://219.141.226.184%') A
 inner join tb_pepmgm_empinfo p on A.FD_EMPID = p.fd_empid
/
