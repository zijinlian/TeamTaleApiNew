CREATE PROCEDURE "P_ATTDINFO_YEAR"(FD_LAST_YEAR in varchar2)
/**************************************************************/
  /*Function:考勤日报表生成                                  */
  /*InputParam:                                       */
  /*OutputParam:                                                */
  /*Create-Date:Aug. 2th,2017                                   */
  /*Author:Pansky-cx                                            */
  /**************************************************************/
is
  --变量声明
BEGIN
  --删除执行考勤月的考勤数据
  delete from TB_ATTDINFO_YEAR_TJ t where t.fd_YEAR = FD_LAST_YEAR;
  commit;

    /**
  插入正常考勤(天)数据
  **/
  insert into TB_ATTDINFO_YEAR_TJ
    (FD_YEAR, FD_EMPID, FD_EMPNME,FD_NORMAL_DAYS,FD_BUSSINE_LEAVE,FD_ANNUAL_LEAVE
    ,FD_AFFAIR_LEAVE,FD_SICK_LEAVE,FD_MARRIED_LEAVE,FD_MATER_LEAVE
    ,FD_PLAN_LEAVE,FD_FUNERNAL_LEAVE,FD_HOME_LEAVE,FD_WELFARE_LEAVE
    ,FD_INJURY_LEAVE,fd_absent_days,FD_LATE_TIMES,FD_EARLY_TIMES,FD_OVERTIME_DAYS)
    select FD_LAST_YEAR as FD_YEAR,
           t.fd_empid,
           t.fd_empnme,
           sum(t.FD_NORMAL_DAYS) as FD_NORMAL_DAYS,
           sum(t.FD_BUSSINE_LEAVE) as FD_BUSSINE_LEAVE,
           sum(t.FD_ANNUAL_LEAVE) as FD_ANNUAL_LEAVE,
           sum(t.FD_AFFAIR_LEAVE) as FD_AFFAIR_LEAVE,
           sum(t.FD_SICK_LEAVE) as FD_SICK_LEAVE,
           sum(t.FD_MARRIED_LEAVE) as FD_MARRIED_LEAVE,
           sum(t.FD_MATER_LEAVE) as FD_MATER_LEAVE,
           sum(t.FD_PLAN_LEAVE) as FD_PLAN_LEAVE,
           sum(t.FD_FUNERNAL_LEAVE) as FD_FUNERNAL_LEAVE,
           sum(t.FD_HOME_LEAVE) as FD_HOME_LEAVE,
           sum(t.FD_WELFARE_LEAVE) as FD_WELFARE_LEAVE,
           sum(t.FD_INJURY_LEAVE) as FD_INJURY_LEAVE,
           sum(t.fd_absent_days) as fd_absent_days,
           sum(t.FD_LATE_TIMES) as FD_LATE_TIMES,
           sum(t.FD_EARLY_TIMES) as FD_EARLY_TIMES,
           sum(t.FD_OVERTIME_DAYS) as FD_OVERTIME_DAYS
      from tb_attdinfo_MONTH_tj t
     where t.fd_MONTH like  '%'||FD_LAST_YEAR||'%'
     group by t.fd_empid, t.fd_empnme;
  commit;



EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    ROLLBACK;
end P_ATTDINFO_YEAR;
/
