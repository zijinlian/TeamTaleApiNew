CREATE VIEW V_USERINFO AS SELECT
    p.fd_empid                                USERID,
    p.fd_empid                                EMPID,
    p.fd_HIREDATE                             BIRTHDAY,
    p.fd_empnme                               FULLNAME,
    p.fd_jobnme                               EMPGRADE,
    p.fd_empstat                              ISQUIT,
    p.fd_gender                               GENDER,
    p.fd_unitcde                              DEPID
FROM TB_PEPMGM_EMPINFO p
/
