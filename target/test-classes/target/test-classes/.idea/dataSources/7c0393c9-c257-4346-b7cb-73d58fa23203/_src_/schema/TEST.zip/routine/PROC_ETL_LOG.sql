CREATE PROCEDURE PROC_ETL_LOG(P_IN_DATA_DATE  IN VARCHAR2,
                                         P_IN_OWNER      IN VARCHAR2,
                                         P_IN_PROC_NAME  IN VARCHAR2,
                                         P_IN_START_DTTM IN TIMESTAMP,
                                         P_IN_END_DTTM   IN TIMESTAMP,
                                         P_IN_ERRORCODE  IN NUMBER,
                                         P_IN_ERRORTEXT  IN VARCHAR2
                                         ) AS

  /*======================================================================================
     -- 程序名:
     --      PROC_ETL_LOG 记录日志程序
     -- 功能描述:
     --      记录存储过程运行日志;
     --      判断有无异常发生，如果有则将异常信息记录到ETL_LOG表中；
     --      如果没有异常，则ETL_LOG表中只记录存储过程运行状态
     -- 源表:
     -- 目标表:
             ETL_LOG(日志)
     -- 参数:
     -- P_IN_DATA_DATE:数据日期
     -- P_IN_OWNER:存储过程的用户名
     -- P_IN_PROC_NAME:存储过程名
     -- P_IN_START_DTTM:开始时间
     -- P_IN_END_DTTM:结束时间
     -- P_IN_ERRORCODE:ORACLE异常代码
     -- P_IN_ERRORTEXT:ORACLE异常说明
     --
     -- 作者:李蛟
     -- 版本:V1.0
     -- 创建时间:2016-11-3 15:45:55
     -- 版权:新宇联安
     -- 加载策略:暂定为每月
  ----------------------------------------------------------------------------------------
     -- 修改历史
     -- 版本:
     -- 修改日期:
     -- 修改人:
     -- 修改原因:
     -- 修改内容:
  ======================================================================================*/

  V_MINUS_TM VARCHAR2(20) DEFAULT NULL;
  --V_RUN_DATA_DATE DATE DEFAULT NULL; -- 执行的变更SQL的日期

BEGIN
  /* --时分秒格式--
   EXTRACT(HOUR FROM P_IN_END_DTTM - P_IN_START_DTTM) || ':' ||
  EXTRACT(MINUTE FROM P_IN_END_DTTM - P_IN_START_DTTM) || ':' ||
  EXTRACT(SECOND FROM P_IN_END_DTTM - P_IN_START_DTTM)*/
  --分钟格式
   SELECT ROUND(TO_NUMBER(TO_DATE(TO_CHAR(P_IN_END_DTTM, 'YYYY-MM-DD HH24:MI:SS'),
                           'YYYY-MM-DD HH24:MI:SS') -
                   TO_DATE(TO_CHAR(P_IN_START_DTTM, 'YYYY-MM-DD HH24:MI:SS'),
                           'YYYY-MM-DD HH24:MI:SS')) * 1440,
         2)
    INTO V_MINUS_TM
    FROM DUAL;

    /* 给执行变更SQL的日期赋值 20151026  */
    /*
    IF (P_IN_RUN_DATA_SQL IS NULL) THEN
      V_RUN_DATA_DATE := NULL;
    ELSE
      V_RUN_DATA_DATE := SYSDATE;
    END IF;
    */

  --如果没有异常发生，将日志信息写入到日志表
  IF (P_IN_ERRORCODE = 1 OR P_IN_ERRORTEXT IS NULL) THEN
    -- 没有错误号， 直接设为 NULL
    INSERT INTO ETL_LOG
      (DATA_DATE, --数据日期
       OWNER, --存储过程调用用户
       PROC_NAME, --存储过程名称
       START_DTTM, --开始时间
       END_DTTM, --结束时间
       MINUS_TM, --用时
       LOG_FLG, --成功标志
       ERRORCODE, --异常代码
       ERRORTEXT --异常说明
       )
    VALUES
      (P_IN_DATA_DATE, --获取数据日期
       UPPER(P_IN_OWNER), --将存储过程调用用户名转化为大写字母
       UPPER(P_IN_PROC_NAME), --将存储过程名称转化为大写字母
       P_IN_START_DTTM, --开始时间
       P_IN_END_DTTM, --结束时间
       V_MINUS_TM, --用时
       '1', --成功
       NULL, --插入NULL
       NULL --插入NULL
       );
  ELSE
    --如果有异常发生
    INSERT INTO ETL_LOG
      (DATA_DATE, --数据日期
       OWNER, --存储过程调用用户
       PROC_NAME, --存储过程名称
       START_DTTM, --开始时间
       END_DTTM, --结束时间
       MINUS_TM, --用时
       LOG_FLG, --成功标志
       ERRORCODE, --异常代码
       ERRORTEXT --异常说明
       )
    VALUES
      (P_IN_DATA_DATE, --获取数据日期
       UPPER(P_IN_OWNER), --将存储过程调用用户名转化为大写字母
       UPPER(P_IN_PROC_NAME), --将存储过程名称转化为大写字母
       P_IN_START_DTTM, --开始时间
       P_IN_END_DTTM, --结束时间
       V_MINUS_TM, --用时
       '-1', --失败
       P_IN_ERRORCODE, --异常代码
       P_IN_ERRORTEXT --异常描述
       );
  END IF;
  -- 这里COMMIT会影响原有的存储过程
  COMMIT; --提交数据

EXCEPTION
  WHEN OTHERS THEN
    --如果发生异常
    ROLLBACK; --数据回滚
END;
/
