CREATE VIEW V_DEPINFO AS SELECT
    c.fd_orgcde        DEPID,
    c.fd_parent_orgcde PARENTDEPID,
    c.fd_orgnme        DEPNAME,
    p.fd_empid         SUPERUSERID
FROM
    TB_SYS_ORGINFO_EHR c
LEFT JOIN
    (
        SELECT
            a.*,
            b.FD_EMPID
        FROM
            TB_SYS_ORGINFO_EHR a,
            TB_PEPMGM_EMPINFO b
        WHERE
            a.FD_ORGcde=b.FD_UNITcde
        AND b.FD_JOBNME='主管') p
ON
    c.FD_ORGcde = p.FD_ORGcde
/
