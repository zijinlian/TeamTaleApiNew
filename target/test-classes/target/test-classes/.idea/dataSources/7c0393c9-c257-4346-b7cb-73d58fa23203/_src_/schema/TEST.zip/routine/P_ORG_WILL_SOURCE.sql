CREATE PROCEDURE P_ORG_WILL_SOURCE
/**************************************************************/
  /*Function:领导班子民意测评结果                                    */
  /*InputParam:                                       */
  /*OutputParam:                                                */
  /*Create-Date:Aug. 17th,2016                                   */
  /*Author:Pansky-cx                                            */
  /**************************************************************/
IS
  --变量声明

BEGIN
--插入被考核机构
EXECUTE IMMEDIATE 'truncate table tb_rp_org_will_score';
insert into tb_rp_org_will_score(FD_ORGCDE,FD_DT,FD_ORGNME)
select fd_exam_target as FD_ORGCDE,to_char(sysdate,'yyyyMMdd'),g.tb_orgnme
 from tb_oa_answers t
 inner join tb_oa_exam_org g on t.fd_exam_target=g.tb_orgcde
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
 group by t.fd_exam_target,g.tb_orgnme
/*select fd_exam_target as FD_ORGCDE,to_char(sysdate,'yyyyMMdd')
 from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
 group by t.fd_exam_target*/;
commit;

  --分行各级员工评价A票得分统计
 update tb_rp_org_will_score t
   set t.FD_SCORE_A = (select FD_SCORE/people as SOURCE from(
select t.fd_exam_target,sum(t.fd_answer_score) as FD_SCORE,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and t.fd_examnum like '1%'
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target) where fd_exam_target=t.FD_ORGCDE)
                        where t.FD_ORGCDE=(select fd_exam_target from(
select t.fd_exam_target,sum(t.fd_answer_score) as FD_SCORE,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and t.fd_examnum like '1%'
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target) where fd_exam_target=t.FD_ORGCDE);
commit;

 --分行各级员工评价B票得分统计
 update tb_rp_org_will_score t
   set t.FD_SCORE_B = (select FD_SCORE/people as SOURCE from(
select t.fd_exam_target,sum(t.fd_answer_score) as FD_SCORE,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and t.fd_examnum like '2%'
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target) where fd_exam_target=t.FD_ORGCDE)
                        where t.FD_ORGCDE=(select fd_exam_target from(
select t.fd_exam_target,sum(t.fd_answer_score) as FD_SCORE,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and t.fd_examnum like '2%'
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target) where fd_exam_target=t.FD_ORGCDE);
commit;
--分行各级员工评价C得分统计
 update tb_rp_org_will_score t
   set t.FD_SCORE_C = (select FD_SCORE/people as SOURCE from(
select t.fd_exam_target,sum(t.fd_answer_score) as FD_SCORE,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and t.fd_examnum like '3%'
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target) where fd_exam_target=t.FD_ORGCDE)
                        where t.FD_ORGCDE=(select fd_exam_target from(
select t.fd_exam_target,sum(t.fd_answer_score) as FD_SCORE,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and t.fd_examnum like '3%'
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target) where fd_exam_target=t.FD_ORGCDE);
commit;

--分行各级员工评价D得分统计
 update tb_rp_org_will_score t
   set t.FD_SCORE_D = (select FD_SCORE/people as SOURCE from(
select t.fd_exam_target,sum(t.fd_answer_score) as FD_SCORE,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and t.fd_examnum like '4%'
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target) where fd_exam_target=t.FD_ORGCDE)
                        where t.FD_ORGCDE=(select fd_exam_target from(
select t.fd_exam_target,sum(t.fd_answer_score) as FD_SCORE,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and t.fd_examnum like '4%'
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target) where fd_exam_target=t.FD_ORGCDE);
commit;

--分行各级员工评价ABCD票汇总得分
update  tb_rp_org_will_score t set t.FD_STAFF_TOTAL_SCORE=nvl(t.fd_score_a,0)*0.3+nvl(t.fd_score_b,0)*0.2+nvl(t.fd_score_c,0)*0.2+nvl(t.fd_score_d,0)*0.3;
commit;

--分行各级员工评价优秀率
 update tb_rp_org_will_score t
   set t.fd_score_a_rate = (select fd_score_rate from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='优秀' and fd_exam_target=t.FD_ORGCDE)
                        where t.FD_ORGCDE=(select fd_exam_target from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='优秀' and fd_exam_target=t.FD_ORGCDE);
commit;


--分行各级员工评价良好率
 update tb_rp_org_will_score t
   set t.fd_score_b_rate = (select fd_score_rate from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='良好' and fd_exam_target=t.FD_ORGCDE)
                        where t.FD_ORGCDE=(select fd_exam_target from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='良好' and fd_exam_target=t.FD_ORGCDE);
   commit;


--分行各级员工评价称职率
 update tb_rp_org_will_score t
   set t.fd_score_c_rate = (select fd_score_rate from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='称职' and fd_exam_target=t.FD_ORGCDE)
                        where t.FD_ORGCDE=(select fd_exam_target from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='称职' and fd_exam_target=t.FD_ORGCDE);
commit;

--分行各级员工评价不称职率
 update tb_rp_org_will_score t
   set t.fd_score_d_rate = (select fd_score_rate from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='不称职' and fd_exam_target=t.FD_ORGCDE)
                        where t.FD_ORGCDE=(select fd_exam_target from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='不称职' and fd_exam_target=t.FD_ORGCDE);
commit;

--省行领导评分
 update tb_rp_org_will_score t
   set t.FD_LEADER_TOTAL_SCORE = (select FD_SCORE/people as SOURCE from(
select t.fd_exam_target,sum(t.fd_answer_score) as FD_SCORE,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target) where fd_exam_target=t.FD_ORGCDE)
                        where t.FD_ORGCDE=(select fd_exam_target from(
select t.fd_exam_target,sum(t.fd_answer_score) as FD_SCORE,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target) where fd_exam_target=t.FD_ORGCDE);
commit;

--行领导评价优秀率
 update tb_rp_org_will_score t
   set t.FD_LEADER_SCORE_A = (select fd_score_rate from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='优秀' and fd_exam_target=t.FD_ORGCDE)
                        where t.FD_ORGCDE=(select fd_exam_target from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='优秀' and fd_exam_target=t.FD_ORGCDE);
commit;

--行领导评价良好率
 update tb_rp_org_will_score t
   set t.FD_LEADER_SCORE_B = (select fd_score_rate from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='良好' and fd_exam_target=t.FD_ORGCDE)
                        where t.FD_ORGCDE=(select fd_exam_target from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='良好' and fd_exam_target=t.FD_ORGCDE);
   commit;


--行领导评价称职率
 update tb_rp_org_will_score t
   set t.FD_LEADER_SCORE_C = (select fd_score_rate from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='称职' and fd_exam_target=t.FD_ORGCDE)
                        where t.FD_ORGCDE=(select fd_exam_target from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='称职' and fd_exam_target=t.FD_ORGCDE);
commit;

--行领导评价不称职率
 update tb_rp_org_will_score t
   set t.FD_LEADER_SCORE_D = (select fd_score_rate from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='不称职' and fd_exam_target=t.FD_ORGCDE)
                        where t.FD_ORGCDE=(select fd_exam_target from(  
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = '402877815ce21084015ce21e97a60001'
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='不称职' and fd_exam_target=t.FD_ORGCDE);
commit;

--总得分
update tb_rp_org_will_score t set t.FD_SCORE=nvl(t.FD_LEADER_TOTAL_SCORE,0)*0.4+nvl(t.FD_STAFF_TOTAL_SCORE,0)*0.6;
commit;



EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    ROLLBACK;
end P_ORG_WILL_SOURCE;
/
