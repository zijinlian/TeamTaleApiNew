CREATE PROCEDURE P_middle_to_middle(FD_FLAG in varchar2)
/**************************************************************/
  /*Function:“业绩认可度”和“三带”测评                                   */
  /*InputParam:                                       */
  /*OutputParam:                                                */
  /*Create-Date:Aug. 17th,2016                                   */
  /*Author:Pansky-cx                                            */
  /**************************************************************/
IS
  --变量声明
   v_examId varchar2(200);

BEGIN
  --分行管理层人员三带和党建工作调查
if FD_FLAG='2' then
   v_examId:='402877815f473ca6015f473ca6b10000';
   /**
   没有考试ID不能继续执行
   **/
  if v_examId is null then
     return;
  end if;
   delete from TB_PER_AND_THREEDAI_EVALUATE t where t.fd_flag='2';
   commit;
  --年度测评_分行管理层人员测评业绩认可度
elsif FD_FLAG='1' then
    v_examId:='F6EE8340309046E4A252817FFBF9C96B';
   /**
   没有考试ID不能继续执行
   **/
  if v_examId is null then
     return;
  end if;
   delete from TB_PER_AND_THREEDAI_EVALUATE t where t.fd_flag='1';
   commit;
  --管理层人员三带和党建工作调查
elsif FD_FLAG='3' then
    v_examId:='402877815f4cdd5b015f4cfc12ac0006';
   /**
   没有考试ID不能继续执行
   **/
  if v_examId is null then
     return;
  end if;
   delete from TB_PER_AND_THREEDAI_EVALUATE t where t.fd_flag='3';
   commit;
end if;

   --插入被考核人
   insert into TB_PER_AND_THREEDAI_EVALUATE
     (FD_EVALUATEDUSERID, FD_EVALUATEDUSERNME, FD_DT, FD_FLAG)
     select fd_exam_target as FD_EVALUATEDUSERID,
            p.fd_empnme as FD_EVALUATEDUSERNME,
            to_char(sysdate, 'yyyyMMdd'),
            FD_FLAG
       from tb_oa_answers t
      inner join TB_PEPMGM_EMPINFO_evaluation p on t.fd_exam_target = p.fd_empid
      where t.fd_exam_id = v_examId
      group by t.fd_exam_target, p.fd_empnme;
      commit;
  --分行员工评价A票得分统计
 update TB_PER_AND_THREEDAI_EVALUATE e
    set e.fd_staff_score_a = (select FD_SCORE / people as SOURCE
                                from (select t.fd_exam_target as FD_empid,
                                             sum(t.fd_answer_score) as FD_SCORE,
                                             count(t.fd_exam_target) as people
                                        from tb_oa_answers t
                                       where t.fd_exam_id =v_examId
                                         and t.fd_examnum like '1%'
                                         and length(t.fd_examnum) = 9
                                       group by t.fd_exam_target)
                               where e.FD_EVALUATEDUSERID = FD_empid)
  where FD_EVALUATEDUSERID =
        (select FD_empid
           from (select t.fd_exam_target as FD_empid,
                        sum(t.fd_answer_score) as FD_SCORE,
                        count(t.fd_exam_target) as people
                   from tb_oa_answers t
                  where t.fd_exam_id = v_examId
                    and t.fd_examnum like '1%'
                    and length(t.fd_examnum) = 9
                  group by t.fd_exam_target)
          where e.FD_EVALUATEDUSERID = FD_empid) and e.fd_flag=FD_FLAG;
commit;

  --分行员工评价B票得分统计
 update TB_PER_AND_THREEDAI_EVALUATE e
    set e.fd_staff_score_b = (select FD_SCORE / people as SOURCE
                                from (select t.fd_exam_target as FD_empid,
                                             sum(t.fd_answer_score) as FD_SCORE,
                                             count(t.fd_exam_target) as people
                                        from tb_oa_answers t
                                       where t.fd_exam_id =v_examId
                                         and t.fd_examnum like '2%'
                                         and length(t.fd_examnum) = 9
                                       group by t.fd_exam_target)
                               where e.FD_EVALUATEDUSERID = FD_empid)
  where FD_EVALUATEDUSERID =
        (select FD_empid
           from (select t.fd_exam_target as FD_empid,
                        sum(t.fd_answer_score) as FD_SCORE,
                        count(t.fd_exam_target) as people
                   from tb_oa_answers t
                  where t.fd_exam_id = v_examId
                    and t.fd_examnum like '2%'
                    and length(t.fd_examnum) = 9
                  group by t.fd_exam_target)
          where e.FD_EVALUATEDUSERID = FD_empid) and e.fd_flag=FD_FLAG;
commit;

  --分行员工评价C票得分统计
 update TB_PER_AND_THREEDAI_EVALUATE e
    set e.fd_staff_score_c = (select FD_SCORE / people as SOURCE
                                from (select t.fd_exam_target as FD_empid,
                                             sum(t.fd_answer_score) as FD_SCORE,
                                             count(t.fd_exam_target) as people
                                        from tb_oa_answers t
                                       where t.fd_exam_id =v_examId
                                         and t.fd_examnum like '3%'
                                         and length(t.fd_examnum) = 9
                                       group by t.fd_exam_target)
                               where e.FD_EVALUATEDUSERID = FD_empid)
  where FD_EVALUATEDUSERID =
        (select FD_empid
           from (select t.fd_exam_target as FD_empid,
                        sum(t.fd_answer_score) as FD_SCORE,
                        count(t.fd_exam_target) as people
                   from tb_oa_answers t
                  where t.fd_exam_id = v_examId
                    and t.fd_examnum like '3%'
                    and length(t.fd_examnum) = 9
                  group by t.fd_exam_target)
          where e.FD_EVALUATEDUSERID = FD_empid) and e.fd_flag=FD_FLAG;
commit;

  --分行员工评价D票得分统计
 update TB_PER_AND_THREEDAI_EVALUATE e
    set e.fd_staff_score_d = (select FD_SCORE / people as SOURCE
                                from (select t.fd_exam_target as FD_empid,
                                             sum(t.fd_answer_score) as FD_SCORE,
                                             count(t.fd_exam_target) as people
                                        from tb_oa_answers t
                                       where t.fd_exam_id =v_examId
                                         and t.fd_examnum like '4%'
                                         and length(t.fd_examnum) = 9
                                       group by t.fd_exam_target)
                               where e.FD_EVALUATEDUSERID = FD_empid)
  where FD_EVALUATEDUSERID =
        (select FD_empid
           from (select t.fd_exam_target as FD_empid,
                        sum(t.fd_answer_score) as FD_SCORE,
                        count(t.fd_exam_target) as people
                   from tb_oa_answers t
                  where t.fd_exam_id = v_examId
                    and t.fd_examnum like '4%'
                    and length(t.fd_examnum) = 9
                  group by t.fd_exam_target)
          where e.FD_EVALUATEDUSERID = FD_empid) and e.fd_flag=FD_FLAG;
commit;

if FD_FLAG='3' then
  --分行各级员工评价ABCD票总得分
  update TB_PER_AND_THREEDAI_EVALUATE e
  set e.FD_STAFF_TOTAL_SCORE =nvl(e.fd_staff_score_a,0)*0.4+nvl(e.fd_staff_score_b,0)*0.3+nvl(e.fd_staff_score_c,0)*0.3;
  commit;
else
  --分行各级员工评价ABCD票总得分
  update TB_PER_AND_THREEDAI_EVALUATE e
  set e.FD_STAFF_TOTAL_SCORE =nvl(e.fd_staff_score_a,0)*0.3+nvl(e.fd_staff_score_b,0)*0.2+nvl(e.fd_staff_score_c,0)*0.2+nvl(e.fd_staff_score_d,0)*0.3;
  commit;
end if;




--分行员工评价优秀率
--update TB_PER_AND_THREEDAI_EVALUATE t set t.FD_STAFF_A_RATE=decode(t.FD_STAFF_TOTAL_SCORE,0,0,nvl(t.fd_staff_score_a,0)/t.FD_STAFF_TOTAL_SCORE);
 update TB_PER_AND_THREEDAI_EVALUATE t
   set t.FD_STAFF_A_RATE = (select fd_score_rate from(
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='优秀' and fd_exam_target=t.FD_EVALUATEDUSERID)
                        where t.FD_EVALUATEDUSERID=(select fd_exam_target from(
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='优秀' and fd_exam_target=t.FD_EVALUATEDUSERID) and t.fd_flag=FD_FLAG;
commit;

--分行员工评价良好率
 update TB_PER_AND_THREEDAI_EVALUATE t
   set t.FD_STAFF_B_RATE = (select fd_score_rate from(
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='良好' and fd_exam_target=t.FD_EVALUATEDUSERID)
                        where t.FD_EVALUATEDUSERID=(select fd_exam_target from(
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='良好' and fd_exam_target=t.FD_EVALUATEDUSERID) and t.fd_flag=FD_FLAG;
commit;

--分行员工评价称职率
 update TB_PER_AND_THREEDAI_EVALUATE t
   set t.FD_STAFF_C_RATE = (select fd_score_rate from(
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='称职' and fd_exam_target=t.FD_EVALUATEDUSERID)
                        where t.FD_EVALUATEDUSERID=(select fd_exam_target from(
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='称职' and fd_exam_target=t.FD_EVALUATEDUSERID) and t.fd_flag=FD_FLAG;
commit;

--分行员工评价不称职率
 update TB_PER_AND_THREEDAI_EVALUATE t
   set t.FD_STAFF_D_RATE = (select fd_score_rate from(
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='不称职' and fd_exam_target=t.FD_EVALUATEDUSERID)
                        where t.FD_EVALUATEDUSERID=(select fd_exam_target from(
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 9
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='不称职' and fd_exam_target=t.FD_EVALUATEDUSERID) and t.fd_flag=FD_FLAG;
commit;

--省行领导评分
 update TB_PER_AND_THREEDAI_EVALUATE t
   set t.FD_LEADER_TOTAL_SCORE = (select FD_SCORE/people as SOURCE from(
select t.fd_exam_target,sum(t.fd_answer_score) as FD_SCORE,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target) where fd_exam_target=t.FD_EVALUATEDUSERID)
                        where t.FD_EVALUATEDUSERID=(select fd_exam_target from(
select t.fd_exam_target,sum(t.fd_answer_score) as FD_SCORE,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target) where fd_exam_target=t.FD_EVALUATEDUSERID) and t.fd_flag=FD_FLAG;

commit;

--行领导评价优秀率
--update TB_PER_AND_THREEDAI_EVALUATE t set t.FD_LEADER_A_RATE=decode(t.FD_LEADER_TOTAL_SCORE,0,0,nvl(t.FD_LEADER_SCORE_A,0)/t.FD_LEADER_TOTAL_SCORE);

 update TB_PER_AND_THREEDAI_EVALUATE t
   set t.FD_LEADER_A_RATE = (select fd_score_rate from(
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='优秀' and fd_exam_target=t.FD_EVALUATEDUSERID)
                        where t.FD_EVALUATEDUSERID=(select fd_exam_target from(
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='优秀' and fd_exam_target=t.FD_EVALUATEDUSERID) and t.fd_flag=FD_FLAG;

commit;

--行领导评价良好率
 update TB_PER_AND_THREEDAI_EVALUATE t
   set t.FD_LEADER_B_RATE = (select fd_score_rate from(
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='良好' and fd_exam_target=t.FD_EVALUATEDUSERID)
                        where t.FD_EVALUATEDUSERID=(select fd_exam_target from(
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='良好' and fd_exam_target=t.FD_EVALUATEDUSERID) and t.fd_flag=FD_FLAG;

commit;

--行领导评价称职率
 update TB_PER_AND_THREEDAI_EVALUATE t
   set t.FD_LEADER_B_RATE = (select fd_score_rate from(
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='称职' and fd_exam_target=t.FD_EVALUATEDUSERID)
                        where t.FD_EVALUATEDUSERID=(select fd_exam_target from(
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='称职' and fd_exam_target=t.FD_EVALUATEDUSERID) and t.fd_flag=FD_FLAG;
commit;

--行领导评价不称职率
 update TB_PER_AND_THREEDAI_EVALUATE t
   set t.FD_LEADER_B_RATE = (select fd_score_rate from(
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='不称职' and fd_exam_target=t.FD_EVALUATEDUSERID)
                        where t.FD_EVALUATEDUSERID=(select fd_exam_target from(
   select A.*,round(people/sum(A.people) over(partition by A.fd_exam_target),2) as fd_score_a_rate from(
  select t.fd_exam_target,t.fd_answer,count(t.fd_exam_target) as people
  from tb_oa_answers t
 where t.fd_exam_id = v_examId
   and length(t.fd_examnum) = 7
   group by t.fd_exam_target,t.fd_answer) A)
   where  fd_answer='不称职' and fd_exam_target=t.FD_EVALUATEDUSERID) and t.fd_flag=FD_FLAG;
commit;

--被考核人总得分
update TB_PER_AND_THREEDAI_EVALUATE e
set e.FD_TOTALSCORE =nvl(e.FD_STAFF_TOTAL_SCORE,0)*0.6+nvl(e.FD_LEADER_TOTAL_SCORE,0)*0.4;
commit;


EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    ROLLBACK;
end P_PER_AND_EVALUATE;
/
