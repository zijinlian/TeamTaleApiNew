CREATE procedure initialization_group_data is
begin
insert into TB_DJ_GROUP_HONOR_EMP (EMP_ID, GROUP_ID) select  fd_empid, 'A00007' from TB_PEPMGM_EMPINFO t where t.fd_empid not in (select t1.emp_id from TB_DJ_GROUP_HONOR_EMP t1 ) ;
insert into TB_DJ_GROUP_ORG (FD_ORGCDE, FD_GROUPID) select  FD_ORGCDE, 'A00007' from TB_SYS_ORGINFO_EHR t where t.FD_ORGCDE not in (select t1.FD_ORGCDE from TB_DJ_GROUP_ORG t1 ) ;
COMMIT;
end initialization_group_data;
/
