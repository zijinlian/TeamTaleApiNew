CREATE PROCEDURE      PRCO_EMPOPERAION_COUNT(P_DATE IN VARCHAR2
                                                   
                                                   )
/***********************************************************************************************/
  /*Functions: 统计员工的每天的操作数据信息 例如 每天的发日志的信息等等                                                      */
  /*P_DATE     输入参数：日期                                                        */
  /*********************************************************************************************/
 AS
  RUN_DATE VARCHAR2(10); --临时变量:存放批处理10位日期
  orgcde   varchar2(20); -- 机构号

  cursor list is
    select DEPT_ID as orgcde
      from TB_OA_EXAM_DEPT
    union all
    select ehr.FD_PARENT_ORGCDE as orgcde
      from tb_oa_exam_org org
     inner join tb_sys_orginfo_ehr ehr
        on org.TB_ORGCDE = ehr.FD_ORGCDE; -- 获取所有的条线机构号

BEGIN

  RUN_DATE := to_char(to_date(P_DATE, 'yyyy-mm-dd') - 0, 'yyyy-mm-dd');

  /*删除前一天数据*/
  delete from TB_OPERATION_STATISTICS t where t.fd_date = RUN_DATE;
  COMMIT;

  /*插入前一天登录信息数据*/

  for b in list loop
    begin
      orgcde := b.orgcde;
      insert into TB_OPERATION_STATISTICS
        select RUN_DATE,
               PM.FD_EMPID 员工号,
               nvl(App.APPCOUNT, 0), --app登陆天数,
               nvl(PC.pccount, 0), --pc登陆天数,
               nvl(LOGC.logcount, 0), --日志总数,
               --  nvl(LOGZ.zan, 0) 日志点赞总数,
               nvl(LOGP.plzan, 0), --日志评论总数,
               nvl(CROWP.shoudaoplun, 0), --众筹评论总数,
               --nvl(CROWZ.zhongchouzan, 0) 众筹点赞总数,
               nvl(CROWCAI.cainaizongshu, 0), --众筹被采纳总数,
               nvl(SUGSEND.sugcount, 0), --发出建议总数,
               nvl(SUGPUN.sugrelcount, 0), --建议评论总数,
               nvl(SUGZAN.sugzancount, 0), --建议点赞总数,
               nvl(SUGCAI.sugcainacount, 0), --建议被采纳总数,
               nvl(XINP.repcount, 0), --新闻总评论数,
               nvl(XINZ.xinzancount, 0), --新闻总点赞数,
               nvl(ICC.icccount, 0), --内控合规答题总数,
               nvl(bankcirle.cirtotal, 0), --中行圈, --发布中行圈总数
               nvl(cirleHot.cirHot, 0), --热门圈, --热门圈总数
               nvl(circlePub.cirPub, 0), --公共圈, --公共圈总数
               nvl(circleope.circletotal, 0) --中行圈评论点赞总数 --中行圈评论点赞总数        
          from tb_pepmgm_empinfo PM
          LEFT JOIN (select fd_empid, count(*) APPCOUNT
                       from (select t.fd_date, t.fd_empid -- app
                               from tb_sys_oper_log t
                              where length(t.fd_empid) = 7
                                and t.fd_date >= RUN_DATE
                                and t.fd_date <= RUN_DATE
                                and t.fd_url like '%219.141.226.184%'
                              group by t.fd_date, t.fd_empid) A
                      group by A.fd_empid) App
            ON PM.FD_EMPID = App.fd_empid
          LEFT JOIN (select fd_empid, count(*) pccount
                       from (select t.fd_date, t.fd_empid -- pc
                               from tb_sys_oper_log t
                              where length(t.fd_empid) = 7
                                and t.fd_date >= RUN_DATE
                                and t.fd_date <= RUN_DATE
                                and t.fd_url like '%21.36.2.225:8090%'
                              group by t.fd_date, t.fd_empid) A
                      group by A.fd_empid) PC
            ON PM.FD_EMPID = PC.fd_empid
        
          LEFT JOIN (select bl.fd_bl_createid, count(*) logcount -- 日志总数
                       from tb_bl_blog bl
                      where bl.fd_create_time >= RUN_DATE || ' 00:00'
                        and bl.fd_create_time <= RUN_DATE || ' 23:59'
                      group by bl.fd_bl_createid) LOGC
            ON PM.FD_EMPID = LOGC.fd_bl_createid
        
        /* LEFT JOIN (select bl.fd_bl_createid empid, count(*) zan --日志点赞总数
                   from tb_bl_blog bl
                  inner join TB_BL_SUPPORT t
                     on bl.fd_bl_id = t.FD_REPLY_ID
                  where bl.fd_create_time >= '2017-01-01 00:00'
                    and bl.fd_create_time <= '2017-03-31 23:59'
                  group by bl.fd_bl_createid) LOGZ
        ON PM.FD_EMPID = LOGZ.empid*/
        
          LEFT JOIN (select bl.FD_EMP_ID empid, count(*) plzan -- 日志评论总数
                       from tb_bl_reply bl
                      where bl.FD_REP_TIME >= RUN_DATE || ' 00:00'
                        and bl.FD_REP_TIME <= RUN_DATE || ' 23:59'
                      group by bl.FD_EMP_ID) LOGP
            ON PM.FD_EMPID = LOGP.empid
        
          LEFT JOIN (select t.FD_EMPID empid, count(*) shoudaoplun -- 重酬评论总数
                       from TB_CF_DISCUSSION t
                      where t.FD_ANSWERTIME >= RUN_DATE || ' 00:00'
                        and t.FD_ANSWERTIME <= RUN_DATE || ' 23:59'
                      group by t.FD_EMPID) CROWP
            ON PM.FD_EMPID = CROWP.empid
        
          LEFT JOIN (select lt.fd_empid, count(*) zhongchouzan -- 重酬点赞总数
                       from tb_cf_like lt
                      group by lt.fd_empid) CROWZ
            ON PM.FD_EMPID = CROWZ.fd_empid
        
          LEFT JOIN (select t.FD_EMPID empid, count(*) cainaizongshu -- 重酬被采纳总数
                       from TB_CF_DISCUSSION t
                      where t.FD_ANSWERTIME >= RUN_DATE || ' 00:00'
                        and t.FD_ANSWERTIME <= RUN_DATE || ' 23:59'
                        and t.FD_ACCEPT_STATE = 1
                      group by t.FD_EMPID) CROWCAI
            ON PM.FD_EMPID = CROWCAI.empid
        
          LEFT JOIN (select t.FD_EMPID empid, count(*) sugcount --发出建议总数
                       from TB_SUG_INFO t
                      where t.fd_leader_status = 1
                        and t.FD_LEADER_TMIE >= RUN_DATE || ' 00:00:00'
                        and t.FD_LEADER_TMIE <= RUN_DATE || ' 23:59:59'
                      group by t.FD_EMPID) SUGSEND
            ON PM.FD_EMPID = SUGSEND.empid
        
          LEFT JOIN (select l.fd_emp_id, count(*) sugrelcount ----建议评论总数
                       from TB_SUG_REPL l
                      where l.FD_OPERTYPE = 1
                        and l.fd_time >= RUN_DATE || ' 00:00'
                        and l.fd_time <= RUN_DATE || ' 23:59'
                      group by l.fd_emp_id) SUGPUN
            ON PM.FD_EMPID = SUGPUN.fd_emp_id
        
          LEFT JOIN (select l.fd_emp_id, count(*) sugzancount ----建议点赞总数
                       from TB_SUG_REPL l
                      where l.FD_OPERTYPE = 0
                        and l.fd_time >= RUN_DATE || ' 00:00'
                        and l.fd_time <= RUN_DATE || ' 23:59'
                      group by l.fd_emp_id) SUGZAN
            ON PM.FD_EMPID = SUGZAN.fd_emp_id
        
          LEFT JOIN (select appro.fd_empid, count(*) sugcainacount ----建议被采纳总数
                       from tb_sug_approve appro
                      where appro.FD_APPRO_STU = 0
                        and appro.FD_APPRO_TIME >= RUN_DATE || ' 00:00:00'
                        and appro.FD_APPRO_TIME <= RUN_DATE || ' 23:59:59'
                      group by appro.fd_empid) SUGCAI
            ON PM.FD_EMPID = SUGCAI.fd_empid
        
          LEFT JOIN (select fd_reply_empid, count(*) repcount ---新闻总评论数
                       from TB_PUB_NEWS_REPLY t
                      where t.fd_reply_time >= RUN_DATE || ' 00:00:00'
                        and t.fd_reply_time <= RUN_DATE || ' 23:59:59'
                      group by t.fd_reply_empid) XINP
            ON PM.FD_EMPID = XINP.fd_reply_empid
        
          LEFT JOIN (select dianzan.FD_DZIAN_EMPID, count(*) xinzancount ---新闻总点赞数
                       from tb_pub_news_dianzan dianzan
                      where dianzan.FD_DZIAN_TIME >= RUN_DATE || ' 00:00:00'
                        and dianzan.FD_DZIAN_TIME <= RUN_DATE || ' 23:59:59'
                      group by dianzan.FD_DZIAN_EMPID) XINZ
            ON PM.FD_EMPID = XINZ.FD_DZIAN_EMPID
        
          LEFT JOIN (select C.fd_staff_id, count(*) icccount
                       from (select t.FD_STAFF_STATUS_DATE, t.fd_staff_id
                               from TB_ICC_STAFF_STATUS t
                              where t.fd_staff_status_date >= RUN_DATE
                                and t.fd_staff_status_date <= RUN_DATE
                              group by t.FD_STAFF_STATUS_DATE, t.fd_staff_id) C
                      group by C.fd_staff_id) ICC
            ON PM.FD_EMPID = ICC.fd_staff_id
        
        --中行圈总数
          left join (select emp_id, count(1) as cirtotal
                       from (select cir.emp_id, info.fd_dept_org
                               from tb_bank_circle cir
                               left join tb_pepmgm_empinfo info
                                 on cir.emp_id = info.fd_empid
                              where to_date(subStr(cir.create_time, 0, 10),
                                            'yyyy-mm-dd') >=
                                    to_date(RUN_DATE, 'yyyy-mm-dd')
                                and to_date(subStr(cir.create_time, 0, 10),
                                            'yyyy-mm-dd') <=
                                    to_date(RUN_DATE, 'yyyy-mm-dd'))
                      group by emp_id) bankcirle
            on PM.FD_EMPID = bankcirle.emp_id
        --中行圈热门总数
          left join (select emp_id, count(1) as cirHot
                       from (select cir.emp_id, info.fd_dept_org
                               from tb_bank_circle cir
                               left join tb_pepmgm_empinfo info
                                 on cir.emp_id = info.fd_empid
                              where IS_HOT = 1
                                and to_date(subStr(cir.create_time, 0, 10),
                                            'yyyy-mm-dd') >=
                                    to_date(RUN_DATE, 'yyyy-mm-dd')
                                and to_date(subStr(cir.create_time, 0, 10),
                                            'yyyy-mm-dd') <=
                                    to_date(RUN_DATE, 'yyyy-mm-dd'))
                      group by emp_id) cirleHot
            on PM.FD_EMPID = cirleHot.emp_id
        --中行圈公共总数
          left join (select emp_id, count(1) as cirPub
                       from (select cir.emp_id, info.fd_dept_org
                               from tb_bank_circle cir
                               left join tb_pepmgm_empinfo info
                                 on cir.emp_id = info.fd_empid
                              where IS_PUBLIC = 1
                                and to_date(subStr(cir.create_time, 0, 10),
                                            'yyyy-mm-dd') >=
                                    to_date(RUN_DATE, 'yyyy-mm-dd')
                                and to_date(subStr(cir.create_time, 0, 10),
                                            'yyyy-mm-dd') <=
                                    to_date(RUN_DATE, 'yyyy-mm-dd'))
                      group by emp_id) circlePub
            on PM.FD_EMPID = circlePub.emp_id
        --中行圈的评论点赞总数
          left join (select pm.fd_empid empid, count(*) circletotal
                       from (select *
                               from (select rel.emp_id      as empid,
                                            rel.create_time as opetime
                                       from tb_bank_circle_comment rel
                                     union all
                                     select parse.emp_id      as empid,
                                            parse.create_time as opetime
                                       from TB_BANK_CIRCLE_PARISE parse) g
                              where to_date(subStr(g.opetime, 0, 10),
                                            'yyyy-mm-dd') >=
                                    to_date(RUN_DATE, 'yyyy-mm-dd')
                                and to_date(subStr(g.opetime, 0, 10),
                                            'yyyy-mm-dd') <=
                                    to_date(RUN_DATE, 'yyyy-mm-dd')) news
                      inner join tb_pepmgm_empinfo pm
                         on news.empid = pm.fd_empid
                      where pm.fd_dept_org is not null
                      group by pm.fd_empid) circleope
            on PM.FD_EMPID = circleope.empid
        
          left join tb_sys_orginfo_ehr org
            on pm.fd_orgcde = org.fd_orgcde
         where PM.fd_dept_org = orgcde;
    
      commit;
    end;
  end loop;

END;
/
