CREATE PROCEDURE PROC_CRWFD_SWRWD(P_IN_DATA     IN VARCHAR2,
                                             P_OUT_SUCCEED OUT INTEGER) IS
  /*======================================================================================
     -- 程序名:
     --      PROC_BATCH_FACTOR_RP  FACTOR存储过程调度
     -- 功能描述:
     --      FACTOR所有存储过程总调度;
     --
     --
     -- 源表:
     -- 目标表:

     -- 参数:
     -- P_IN_DATA_DATE:数据日期
     -- P_OUT_SUCCEED:返回状态
     -- 作者:李蛟
     -- 版本:V1.0
     -- 创建时间:2016年11月8日20:56:22
     -- 版权:软件
     -- 加载策略:
  ----------------------------------------------------------------------------------------
     -- 修改历史
     -- 版本:
     -- 修改日期:
     -- 修改人:
     -- 修改原因:
     -- 修改内容:
  ======================================================================================*/
  V_ERRORCODE  ETL_LOG.ERRORCODE%TYPE DEFAULT 0; --数值型  异常代码
  V_ERRORTEXT  ETL_LOG.ERRORTEXT%TYPE DEFAULT NULL; --字符型  异常描述
  V_OWNER      ETL_LOG.OWNER%TYPE DEFAULT 'FACTOR_CRWFD'; --字符型  存储过程调用用户
  V_PROC_NAME  ETL_LOG.PROC_NAME%TYPE DEFAULT NULL; --字符型  存储过程名称
  V_STATR_DTTM DATE; ---日志开始时间
  V_END_DTTM   DATE; ---日志结束时间
  VS_DATE      VARCHAR2(8); ----标记跑批日期
  CUR_NAM      VARCHAR2(5000); --当前执行表名
  pragma autonomous_transaction;
  /*调用FACTOR存储过程生成报表数据，遍历存储过程名称*/
  CURSOR PRO_NAME IS
    SELECT FD_KEYWORD AS PRO_NAME
      FROM TB_PUB_PROHIBIT_WORD T
     ORDER BY TO_NUMBER(ID);
BEGIN
  V_STATR_DTTM := SYSTIMESTAMP;
  V_PROC_NAME  := 'PROC_CRWFD_SWRWD';
  VS_DATE      := P_IN_DATA;
  ------------------------------------------------------------------------
  /*FACTOR报表数据跑批开始*/
  FOR V_PRO_NAME IN PRO_NAME LOOP
    CUR_NAM := V_PRO_NAME.PRO_NAME;
    --DBMS_OUTPUT.PUT_LINE(CUR_NAM);
    UPDATE TB_CF_DISCUSSION
       SET FD_CONTENT = REPLACE(FD_CONTENT, CUR_NAM, '*');

  END LOOP;
  ------------------------------------------------------------------------------
  -------------------------------------------
  P_OUT_SUCCEED := 1; --设置成功状态为1 成功状态
  COMMIT;--非特殊处理只能在最后一次提交
  V_END_DTTM    := SYSTIMESTAMP;
 /* PROC_ETL_LOG(P_IN_DATA,
               V_OWNER,
               V_PROC_NAME,
               V_STATR_DTTM,
               V_END_DTTM,
               V_ERRORCODE,
               V_ERRORTEXT);
  <<ERROR>>
  NULL;*/
  /*异常处理 */
EXCEPTION

  WHEN OTHERS THEN
    --如果出现异常
    V_ERRORCODE := SQLCODE; --设置异常代码
    V_ERRORTEXT := SUBSTR(SQLERRM, 1, 200); --设置异常描述
    ROLLBACK; --数据回滚
    P_OUT_SUCCEED := -1; --设置异常状态为-1
    -- 插入日志表，记录错误
    /*PROC_ETL_LOG(VS_DATE,
                 V_OWNER,
                 V_PROC_NAME,
                 V_STATR_DTTM,
                 SYSTIMESTAMP,
                 V_ERRORCODE,
                 V_ERRORTEXT);*/
END PROC_CRWFD_SWRWD;
/
