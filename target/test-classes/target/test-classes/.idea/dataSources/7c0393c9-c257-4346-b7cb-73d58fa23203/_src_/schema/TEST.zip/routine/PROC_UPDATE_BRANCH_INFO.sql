CREATE procedure PROC_UPDATE_BRANCH_INFO(ctime         in varchar2,
                                                    P_OUT_SUCCEED OUT INTEGER) is
  CURSOR PLIST IS
    select t.j_agency_number,
           t.j_agency_name,
           t.Y_YGZRS,
           t.Y_GYRS,
           t.Y_YXFWRS,
           t.Y_GYRSZB,
           t.Y_YXFWRYRSZB,
           decode(t.Y_FWXZ, '混合', '3', '自有', '1', '租赁', '2', '0') Y_FWXZ,
           t.S_FWRENT,
           t.Y_FWMJ,
           trim(t.Y_KYSJ) Y_KYSJ,
           decode(t.j_operating_status,
                  '正常',
                  '3',
                  '新筹建',
                  '2',
                  '拟撤销',
                  '1',
                  '歇业',
                  '4',
                  '0') j_operating_status,
           decode(t.Y_JGXZ,
                  '一级分行',
                  '1',
                  '直属、二级、地州行',
                  '2',
                  '城区中心支行',
                  '3',
                  '县中心支行',
                  '4',
                  '经营性网点',
                  '5',
                  '0') Y_JGXZ,
           t.Y_LSGX,
           t.Y_SXJGS,
           t.Y_SZQH,
           t.Y_YYDZ
      from TB_FINANCE_CALCULATEINCOME t
     where t.j_date =
           (select max(p.j_date) from TB_FINANCE_CALCULATEINCOME p);

  j_agency_number    varchar2(1000) := ''; --状态,
  orgname            varchar2(1000) := '';
  Y_YGZRS            varchar2(1000) := ''; --员工总人数,
  Y_GYRS             varchar2(1000) := ''; --柜员人数,
  Y_YXFWRS           varchar2(1000) := ''; --营销服务人员人数,
  Y_GYRSZB           varchar2(1000) := ''; --柜员人数占比,
  Y_YXFWRYRSZB       varchar2(1000) := ''; --营销服务人员人数占比,
  Y_FWXZ             varchar2(1000) := ''; --房屋性质,
  S_FWRENT           varchar2(1000) := ''; --房屋租金,
  Y_FWMJ             varchar2(1000) := ''; --房屋面积,
  Y_KYSJ             varchar2(1000) := ''; --开业时间,
  j_operating_status varchar2(1000) := ''; --营业状态,
  Y_JGXZ             varchar2(1000) := ''; --机构性质,
  Y_LSGX             varchar2(1000) := ''; --隶属关系,
  Y_SXJGS            varchar2(1000) := ''; --所辖机构数,
  Y_SZQH             varchar2(1000) := ''; --行政区划,
  Y_YYDZ             varchar2(1000) := ''; --营业地址

  netcount number := 0; --网点的数据

begin
  for b in plist loop
    begin
      j_agency_number    := b.j_agency_number;
      orgname            := b.j_agency_name;
      Y_YGZRS            := b.Y_YGZRS;
      Y_GYRS             := b.Y_GYRS;
      Y_YXFWRS           := b.Y_YXFWRS;
      Y_GYRSZB           := b.Y_GYRSZB;
      Y_YXFWRYRSZB       := b.Y_YXFWRYRSZB;
      Y_FWXZ             := b.Y_FWXZ;
      S_FWRENT           := b.S_FWRENT;
      Y_FWMJ             := b.Y_FWMJ;
      Y_KYSJ             := b.Y_KYSJ;
      j_operating_status := b.j_operating_status;
      Y_JGXZ             := b.Y_JGXZ;
      Y_LSGX             := b.Y_LSGX;
      Y_SXJGS            := b.Y_SXJGS;
      Y_SZQH             := b.Y_SZQH;
      Y_YYDZ             := b.Y_YYDZ;
    
      select count(*)
        into netcount
        from TB_BRANCH_DEVELOPINFO p
       where p.fd_orgcde = j_agency_number;
      if (netcount = 0) then
        begin
          insert into TB_BRANCH_DEVELOPINFO
            (FD_ORGCDE,
             FD_ORGNME,
             FD_EMPNUM,
             FD_CLERKNUM,
             FD_SALESNUM,
             FD_CLERK_PROP,
             FD_SALESMAN_PROP,
             FD_HOUSE_TYP,
             FD_HOUSE_NZJ,
             FD_OPENDATE,
             FD_ORG_STATUS,
             FD_ORG_NATURE,
             FD_SUBORGS,
             FD_ORG_ZONE,
             FD_BUSINESS_LOCATION)
          values
            (j_agency_number,
             orgname,
             Y_YGZRS,
             Y_GYRS,
             Y_YXFWRS,
             Y_GYRSZB,
             Y_YXFWRYRSZB,
             Y_FWXZ,
             S_FWRENT,
             Y_KYSJ,
             j_operating_status,
             Y_JGXZ,
             Y_SXJGS,
             Y_SZQH,
             Y_YYDZ);
        
        end;
      end if;
    
      if (netcount = 1) then
        begin
          update TB_BRANCH_DEVELOPINFO tb
             set tb.FD_EMPNUM        = Y_YGZRS,
                 tb.FD_CLERKNUM      = Y_GYRS,
                 tb.FD_SALESNUM      = Y_YXFWRS,
                 tb.FD_CLERK_PROP    = Y_GYRSZB,
                 tb.FD_SALESMAN_PROP = Y_YXFWRYRSZB,
                 tb.FD_HOUSE_TYP     = Y_FWXZ,
                 tb.FD_HOUSE_NZJ     = S_FWRENT,
                 tb.FD_OPENDATE      = Y_KYSJ,
                 tb.FD_ORG_STATUS    = j_operating_status,
                 tb.FD_ORG_NATURE    = Y_JGXZ,
                 --    tb.FD_PARENT_ORG        = Y_LSGX,
                 tb.FD_SUBORGS           = Y_SXJGS,
                 tb.FD_ORG_ZONE          = Y_SZQH,
                 tb.FD_BUSINESS_LOCATION = Y_YYDZ
           where tb.fd_orgcde = j_agency_number;
          commit;
        end;
      end if;
    end;
  end loop;

end PROC_UPDATE_BRANCH_INFO;
/
