CREATE PROCEDURE PRCO_LOGIN_COUNT(            P_DATE IN VARCHAR2

                                                        )
/***********************************************************************************************/
  /*Functions: 登录信息统计                                                      */
  /*P_DATE     输入参数：日期                                                        */                                               
  /*********************************************************************************************/
 AS
   RUN_DATE        VARCHAR2(10); --临时变量:存放批处理10位日期

BEGIN

   RUN_DATE        :=to_char(to_date(P_DATE,'yyyy-mm-dd')-1,'yyyy-mm-dd');

   /*删除前一天数据*/

   delete from tb_logininfo_count t where t.fddate = RUN_DATE;
   COMMIT;

   /*插入前一天登录信息数据*/

   INSERT INTO tb_logininfo_count 

   select C.pid fdorg,
       C.pname fdorgnm,
       nvl(EE.scont, 0) sumcount,
       nvl(D.app, 0) appsumcount,
       nvl(D.pc, 0) pcsumcount,
       nvl(E.sumcount, 0) fdempcount,
       RUN_DATE
   from (select dp.dept_id pid, dp.dept_nme pname, dp.dept_order porder
          from tb_oa_exam_dept dp
        union
        select eh.fd_parent_orgcde pid,
               org.tb_orgnme pname,
               (org.tb_order + 100) porder
          from tb_oa_exam_org org
         inner join tb_sys_orginfo_ehr eh
            on org.tb_orgcde = eh.fd_orgcde) C

  left join

 (select ehr.fd_orgcde,
         nvL(count(*), 0) scont,
         nvL(sum(decode(A.plevel, '0', 1, 0)), 0) app,
         nvl(sum(decode(A.plevel, '1', 1, 0)), 0) pc
    from (select t.fd_empid, '1' plevel
            from tb_sys_oper_log t
           where length(t.fd_empid) = 7
             and t.fd_date = RUN_DATE

             and t.fd_url like '%21.36.2.225:8090%'
          union
          select t.fd_empid, '0' plevel
            from tb_sys_oper_log t
           where length(t.fd_empid) = 7
             and t.fd_date = RUN_DATE
             and t.fd_url like '%219.141.226.184%')

         A
   inner join tb_pepmgm_empinfo pm
      on A.fd_empid = pm.fd_empid
   inner join tb_sys_orginfo_ehr ehr
      on pm.fd_dept_org = ehr.fd_orgcde
   group by ehr.fd_orgcde) D
    on C.pid = D.fd_orgcde

  left join (

             select ehr.fd_orgcde, nvL(count(*), 0) scont
               from (select t.fd_empid
                        from tb_sys_oper_log t
                       where length(t.fd_empid) = 7
                         and t.fd_date = RUN_DATE

                         and t.fd_url like '%21.36.2.225:8090%'
                      union
                      select t.fd_empid
                        from tb_sys_oper_log t
                       where length(t.fd_empid) = 7
                         and t.fd_date = RUN_DATE

                         and t.fd_url like '%219.141.226.184%'

                      ) A
              inner join tb_pepmgm_empinfo pm
                 on A.fd_empid = pm.fd_empid
              inner join tb_sys_orginfo_ehr ehr
                 on pm.fd_dept_org = ehr.fd_orgcde
              group by ehr.fd_orgcde

             ) EE

    on C.pid = EE.fd_orgcde

  left join (Select fd_dept_org org, count(*) sumcount
               from tb_pepmgm_empinfo pm
              group by pm.fd_dept_org) E
    on C.pid = E.org  
    
  ORDER BY C.porder ;

   COMMIT;

END;
/
