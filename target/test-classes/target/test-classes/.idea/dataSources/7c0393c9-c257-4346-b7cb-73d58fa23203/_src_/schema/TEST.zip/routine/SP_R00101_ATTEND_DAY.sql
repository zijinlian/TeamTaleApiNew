CREATE PROCEDURE SP_R00101_ATTEND_DAY(IS_DATE    IN VARCHAR2, --输入变量，传入跑批日期
                                 OI_RETCODE OUT INTEGER --输出变量，用来标识存储过程执行过程中是否出现异常
                                 ) IS
    /*-- AUTHOR  : 李蛟
    -- CREATED : 2016/11/18 15:03:28
    -- PURPOSE : 考勤-员工每日考勤表  */
    /*-----------------------------------------------------------------
       -- 程序名
       --      SP_R00101_ATTEND_DAY
       -- 用途
       --
       --修改记录：

    -----------------------------------------------------------------*/
  BEGIN
  /**  PKG_R001_RCG_SCORE.VS_STATR_TM := SYSTIMESTAMP;**/
    SELECT T.USERNAME
      INTO PKG_R001_RCG_SCORE.VS_OWNER
      FROM SYS.USER_USERS T;
    /** PKG_R001_RCG_SCORE.VS_PROCEDURE_NAME := 'SP_R00101_ATTEND_DAY';*/

    -------------------------------------------------------------------------
    -------清除目标表数据---------
    --EXECUTE IMMEDIATE 'TRUNCATE TABLE TB_RP_SLTN_APTMT_RCXBZ';
    DELETE FROM TB_OA_ATTEND_DAY T
     WHERE T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
    COMMIT;
    DELETE FROM TB_OA_ATTEND_HOURS T
     WHERE T.FD_DATE =
           TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD');
    COMMIT;
    INSERT INTO TB_OA_ATTEND_DAY
      (FD_DATE --考勤日期
      ,
       FD_EMPID --员工工号
      ,
       FD_EMPNME --姓名
      ,
       FD_DAY21 --上月21号 1正常-1异常
      ,
       FD_DAY22 --上月22号 1正常-1异常
      ,
       FD_DAY23 --上月23号 1正常-1异常
      ,
       FD_DAY24 --上月24号 1正常-1异常
      ,
       FD_DAY25 --上月25号 1正常-1异常
      ,
       FD_DAY26 --上月26号 1正常-1异常
      ,
       FD_DAY27 --上月27号 1正常-1异常
      ,
       FD_DAY28 --上月28号 1正常-1异常
      ,
       FD_DAY29 --上月29号 1正常-1异常
      ,
       FD_DAY30 --上月30号 1正常-1异常
      ,
       FD_DAY31 --上月31号 1正常-1异常
      ,
       FD_DAY1 --本月1号 1正常-1异常
      ,
       FD_DAY2 --本月2号 1正常-1异常
      ,
       FD_DAY3 --本月3号 1正常-1异常
      ,
       FD_DAY4 --本月4号 1正常-1异常
      ,
       FD_DAY5 --本月5号 1正常-1异常
      ,
       FD_DAY6 --本月6号 1正常-1异常
      ,
       FD_DAY7 --本月7号 1正常-1异常
      ,
       FD_DAY8 --本月8号 1正常-1异常
      ,
       FD_DAY9 --本月9号 1正常-1异常
      ,
       FD_DAY10 --本月10号 1正常-1异常
      ,
       FD_DAY11 --本月11号 1正常-1异常
      ,
       FD_DAY12 --本月12号 1正常-1异常
      ,
       FD_DAY13 --本月13号 1正常-1异常
      ,
       FD_DAY14 --本月14号 1正常-1异常
      ,
       FD_DAY15 --本月15号 1正常-1异常
      ,
       FD_DAY16 --本月16号 1正常-1异常
      ,
       FD_DAY17 --本月17号 1正常-1异常
      ,
       FD_DAY18 --本月18号 1正常-1异常
      ,
       FD_DAY19 --本月19号 1正常-1异常
      ,
       FD_DAY20 --本月20号 1正常-1异常

       )

      SELECT TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD'), --每月月底考勤日期
             T.FD_EMPID, --员工工号
             T.FD_EMPNME,
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '21',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '22',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '23',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '24',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '25',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '26',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '27',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '28',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '29',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '30',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '31',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '01',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '02',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '03',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '04',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '05',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '06',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '07',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '08',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '09',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '10',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '11',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '12',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '13',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '14',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '15',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '16',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '17',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '18',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '19',
                        T.FD_FLAG,
                        NULL)),
             SUM(DECODE(FD_DATE,
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '20',
                        T.FD_FLAG,
                        NULL))

        FROM TB_PEPMGM_ATTDINFO_TJ T
       WHERE T.FD_DATE >=
             TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '21'
         AND T.FD_DATE <=
             TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '20'
       GROUP BY T.FD_EMPID, T.FD_EMPNME;

    --分段式提交-------------
    COMMIT;
    INSERT INTO TB_OA_ATTEND_HOURS
      (FD_DATE --考勤日期
      ,
       FD_EMPID --员工工号
      ,
       FD_EMPNME --姓名
      ,
       FD_DAY1 --公出
      ,
       FD_DAY2 --年假
      ,
       FD_DAY3 --事假
      ,
       FD_DAY4 --病假
      ,
       FD_DAY5 --婚假
      ,
       FD_DAY6 --产假
      ,
       FD_DAY7 --计划生育假
      ,
       FD_DAY8 --丧假
      ,
       FD_DAY9 --探亲假
      ,
       FD_DAY10 --公益假
      ,
       FD_DAY11 --工伤假
      ,
       FD_DAY12 --加班
       )

      SELECT TO_CHAR(TO_DATE(IS_DATE, 'yyyy-mm-dd'), 'YYYY-MM-DD'), --每月月底考勤日期
             T.FD_EMPID, --员工编号
             T.FD_EMPNME, --员工编号
             SUM(DECODE(T.FD_LEAVETYP, '010', T.A, NULL)), --公出
             SUM(DECODE(T.FD_LEAVETYP, '020', T.A, NULL)), --年假
             SUM(DECODE(T.FD_LEAVETYP, '030', T.A, NULL)), --事假
             SUM(DECODE(T.FD_LEAVETYP, '040', T.A, NULL)), --病假
             SUM(DECODE(T.FD_LEAVETYP, '050', T.A, NULL)), --婚假
             SUM(DECODE(T.FD_LEAVETYP, '060', T.A, NULL)), --产假
             SUM(DECODE(T.FD_LEAVETYP, '070', T.A, NULL)), --计划生育假
             SUM(DECODE(T.FD_LEAVETYP, '080', T.A, NULL)), --丧假
             SUM(DECODE(T.FD_LEAVETYP, '090', T.A, NULL)), --探亲假
             SUM(DECODE(T.FD_LEAVETYP, '100', T.A, NULL)), --公益假
             SUM(DECODE(T.FD_LEAVETYP, '110', T.A, NULL)), --工伤假
             SUM(DECODE(T.FD_LEAVETYP, '999', T.A, NULL)) --加班

        FROM （SELECT T.FD_EMPID, --员工编号
             T1.FD_EMPNME, --员工编号
             T.FD_LEAVETYP, -- 请假类型
             T.A -- 请假时间
        FROM ((SELECT T.FD_SERIALNUM, --请假编号
                      T.FD_EMPID, --员工编号
                      T.FD_LEAVETYP, -- 请假类型
                      nvl(SUM(T.FD_HOURS), 0) - nvl(SUM(T1.A), 0) AS A --请假时间
                 FROM TB_OA_LEAVEINFO_SPLIT T
                 LEFT JOIN (SELECT T.FD_UUID, --请假编号
                                  T.FD_EMPID, --员工编号
                                  SUM(T.FD_HOURS) AS A --销假时间
                             FROM TB_OA_LEAVEINFO_CLEAR_SPLIT T
                            WHERE FD_CUR_STATUS = '2'
                              AND TO_CHAR(TO_DATE(T.FD_BGNTIME,
                                                  'YYYY-MM-DD HH24:MI:SS'),
                                          'YYYY-MM-DD') >=
                                  TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1),
                                          'yyyy-mm-') || '21'
                              AND TO_CHAR(TO_DATE(T.FD_ENDTIME,
                                                  'YYYY-MM-DD HH24:MI:SS'),
                                          'YYYY-MM-DD') <=
                                  TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'),
                                          'yyyy-MM-') || '20'
                            GROUP BY T.FD_UUID, T.FD_EMPID) T1
                   ON T1.FD_UUID = T.FD_SERIALNUM
                WHERE T.FD_CUR_STATUS = '2'
                  AND TO_CHAR(TO_DATE(T.FD_BGNTIME, 'YYYY-MM-DD HH24:MI:SS'),
                              'YYYY-MM-DD') >=
                      TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '21'
                  AND TO_CHAR(TO_DATE(T.FD_ENDTIME, 'YYYY-MM-DD HH24:MI:SS'),
                              'YYYY-MM-DD') <=
                      TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '20'
                GROUP BY T.FD_EMPID, T.FD_SERIALNUM, T.FD_LEAVETYP) T left join
              TB_PEPMGM_EMPINFO T1 on T.FD_EMPID = T1.FD_EMPID)
      UNION ALL (SELECT FD_EMPID, --员工id              ---此部分是请假时间
                        FD_EMPNME, --员工名称
                        '999' AS FD_LEAVETYP, --请假类型
                        SUM(FD_WORKHOURS)
                   FROM tb_oa_overtimeinfo_SPLIT T
                  where TO_CHAR(TO_DATE(T.FD_BGNTIME,
                                        'YYYY-MM-DD HH24:MI:SS'),
                                'YYYY-MM-DD') >=
                        TO_CHAR(ADD_MONTHS(TRUNC(SYSDATE), -1), 'yyyy-mm-') || '21'
                    AND TO_CHAR(TO_DATE(T.FD_ENDTIME,
                                        'YYYY-MM-DD HH24:MI:SS'),
                                'YYYY-MM-DD') <=
                        TO_CHAR(TO_DATE(IS_DATE, 'yyyyMMdd'), 'yyyy-MM-') || '20'
                    and T.FD_CUR_STATUS = '2' --审批通过
                  GROUP BY FD_EMPID, FD_EMPNME)) T
       GROUP BY T.FD_EMPID, T.FD_EMPNME;

    -------------------------------------------------------------------------
    --日志记录
    OI_RETCODE := 1; --设置正常状态为1 成功状态
    COMMIT; --非特殊处理只能在最后一次提交
    PKG_R001_RCG_SCORE.VS_END_TM := SYSTIMESTAMP;
    PROC_ETL_LOG(IS_DATE,
                 PKG_R001_RCG_SCORE.VS_OWNER,
                 PKG_R001_RCG_SCORE.VS_PROCEDURE_NAME,
                 PKG_R001_RCG_SCORE.VS_STATR_TM,
                 PKG_R001_RCG_SCORE.VS_END_TM,
                 PKG_R001_RCG_SCORE.VI_ERRORCODE,
                 PKG_R001_RCG_SCORE.VS_ERRORTEXT);
    --异常处理
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK; --数据回滚
      DBMS_OUTPUT.PUT_LINE('sqlcode：' || SQLCODE);
      DBMS_OUTPUT.PUT_LINE('sqlerrm：' || SQLERRM);
      PKG_R001_RCG_SCORE.VI_ERRORCODE := SQLCODE; --设置异常代码
      PKG_R001_RCG_SCORE.VS_ERRORTEXT := SUBSTR(SQLERRM, 1, 200); --设置异常描述
      OI_RETCODE                      := -1; --设置异常状态为-1
      --插入日志表，记录错误
      PROC_ETL_LOG(IS_DATE,
                   PKG_R001_RCG_SCORE.VS_OWNER,
                   PKG_R001_RCG_SCORE.VS_PROCEDURE_NAME,
                   PKG_R001_RCG_SCORE.VS_STATR_TM,
                   SYSTIMESTAMP,
                   PKG_R001_RCG_SCORE.VI_ERRORCODE,
                   PKG_R001_RCG_SCORE.VS_ERRORTEXT);
      PKG_R001_RCG_SCORE.VI_ERRORCODE := NULL;
      PKG_R001_RCG_SCORE.VS_ERRORTEXT := NULL;
  END SP_R00101_ATTEND_DAY;
/
