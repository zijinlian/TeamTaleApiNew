CREATE procedure pro_test_job
is
begin
  insert into test_job values(seq_test_job_id.nextval,sysdate);
end pro_test_job;
/
