CREATE PACKAGE        "PKG_R001_RCG_ATTEND" IS

  -- Author  : 李蛟
  -- Created : 2016/11/03 15:03:28
  -- Purpose : 业绩认可程度
  VI_ERRORCODE      ETL_LOG.ERRORCODE%TYPE DEFAULT - 1; --数值型  异常代码
  VS_ERRORTEXT      ETL_LOG.ERRORTEXT%TYPE DEFAULT NULL; --字符型  异常描述
  VS_OWNER          ETL_LOG.OWNER%TYPE DEFAULT 'FACTOR'; --字符型  存储过程调用用户
  VS_PROCEDURE_NAME ETL_LOG.PROC_NAME%TYPE DEFAULT NULL; --字符型  存储过程名称
  VS_STATR_TM       DATE; ---日志开始时间
  VS_END_TM         DATE; ---日志结束时间
  V_NUM_MAXLSID     NUMBER DEFAULT 0; --表主键编号
 
   --考勤-员工每日考勤对照表
  PROCEDURE SP_R00101_CHK_EMP_LUT(IS_DATE    IN VARCHAR2,
                                       OI_RETCODE OUT INTEGER);
 --考勤-员工每日考勤实际表
  PROCEDURE SP_R00101_CHK_EMP_DLUT(IS_DATE    IN VARCHAR2,
                                       OI_RETCODE OUT INTEGER);
 --考勤-员工每日考勤表比对结果
  PROCEDURE SP_R00101_EMP_CHK_FLAG(IS_DATE    IN VARCHAR2,
                                       OI_RETCODE OUT INTEGER);
 --考勤-员工每月考勤表
  PROCEDURE SP_R00101_ATTEND_DAY(IS_DATE    IN VARCHAR2,
                                       OI_RETCODE OUT INTEGER);


END PKG_R001_RCG_ATTEND;
/
