CREATE VIEW V_TEMPLOGININFO AS SELECT
    p.fd_empid                                 userid,
    p.fd_empnme                                username,
    p.fd_unitcde                               orgid,
    p.fd_unitnme                               orgname
FROM TB_PEPMGM_EMPINFO p
/
