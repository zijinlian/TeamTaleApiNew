CREATE PROCEDURE P_ATTDINFO_DAYS1(FD_LAST_DATE in varchar2)
/**************************************************************/
  /*Function:考勤日报表生成                                  */
  /*InputParam:                                       */
  /*OutputParam:                                                */
  /*Create-Date:Aug. 2th,2017                                   */
  /*Author:Pansky-cx                                            */
  /**************************************************************/
is
  --变量声明
  v_isworkday varchar2(200);
  v_isholiday varchar2(200);
  v_sql varchar2(2000);
  v_empSql varchar2(2000);
  v_overtime_sql varchar2(2000);
  CURSOR C_LEAVE(FD_DATE in varchar2) is
  select s.fd_empid,s.fd_hours,s.fd_leavetyp,t.leavename
  from  tb_oa_leaveinfo_split s 
  inner join tb_oa_leave_type t on
  s.fd_leavetyp=t.id
  where s.fd_bgntime like FD_DATE; 
  --where s.fd_bgntime like '''%'||FD_DATE||'%''';
 --where s.fd_bgntime like '%2016-12-26%';
 C_ROW C_LEAVE%ROWTYPE; 
 
 CURSOR C_CLEAR(FD_DATE in varchar2) is
  select s.fd_empid,p.fd_hours,s.fd_leavetyp
  from  tb_oa_leaveinfo_split s 
  inner join tb_oa_leaveinfo_clear_split p 
  on s.fd_empid=p.fd_empid
 where s.fd_bgntime like FD_DATE
 and p.fd_bgntime like FD_DATE;
 C_CLEARROW C_CLEAR%ROWTYPE;


BEGIN


v_sql:='select '''||FD_LAST_DATE||''' as FD_DATE,t.fd_empid as FD_EMPID,
         t.fd_empnme as FD_EMPNME,
         (1-ceil(s.fd_hours/8)) as FD_NORMAL_DAYS
    from tb_pepmgm_empinfo t
   inner join tb_oa_leaveinfo_split s on t.fd_empid = s.fd_empid where s.fd_bgntime like ''%'||FD_LAST_DATE||'%''';
dbms_output.put_line(v_sql);

v_empSql:='select '''||FD_LAST_DATE||''' as FD_DATE,t.fd_empid,t.fd_empnme,1 as FD_NORMAL_DAYS
  from tb_pepmgm_empinfo t
  where t.fd_empid not in(select 
  t.fd_empid as FD_EMPID
  from tb_pepmgm_empinfo t
 inner join tb_oa_leaveinfo_split s on t.fd_empid = s.fd_empid
 where s.fd_bgntime like ''%'||FD_LAST_DATE||'%'')
  and length(t.fd_empid)=7';
  dbms_output.put_line(v_empSql);
  
v_overtime_sql:='select '''||FD_LAST_DATE||''' as FD_DATE,t.fd_empid as FD_EMPID,
         t.fd_empnme as FD_EMPNME,
         ceil(s.fd_hours/8) as FD_OVERTIME_DAYS
    from tb_pepmgm_empinfo t
   inner join tb_oa_overtimeinfo_split s on t.fd_empid = s.fd_empid where s.fd_bgntime like ''%'||FD_LAST_DATE||'%''';
dbms_output.put_line(v_overtime_sql);

--EXECUTE IMMEDIATE 'truncate table TB_ATTDINFO_DAY_TJ';

delete from TB_ATTDINFO_DAY_TJ t where t.fd_date=FD_LAST_DATE;
commit;

--查出请假的记录数据加到考勤表
EXECUTE IMMEDIATE 'insert into TB_ATTDINFO_DAY_TJ
(FD_DATE, FD_EMPID, FD_EMPNME, FD_NORMAL_DAYS)'||v_sql;
commit;

select t.isworkday,t.isholiday into v_isworkday,v_isholiday from TB_OA_HOLIDAYS t where t.fd_date=FD_LAST_DATE;

/**
只有工作日继续向下执行
**/
if v_isworkday='N' then
   dbms_output.put_line(v_isworkday);
   dbms_output.put_line(v_isholiday);
     insert into TB_ATTDINFO_DAY_TJ
    (FD_DATE, FD_EMPID, FD_EMPNME, FD_NORMAL_DAYS)
    select p.fd_date,p.fd_empid,p.fd_empnme,'1' as FD_NORMAL_DAYS from  tb_pepmgm_attdinfo_tj p 
   where p.fd_mflag='1' and p.fd_date=FD_LAST_DATE;
      if v_isholiday='Y' then
          dbms_output.put_line(v_isholiday);
          EXECUTE IMMEDIATE 'insert into TB_ATTDINFO_DAY_TJ
          (FD_DATE, FD_EMPID, FD_EMPNME,FD_OVERTIME_DAYS)'||v_overtime_sql;
           commit;
      end if;
   return;
end if;


/**
插入正常考勤(天)数据
**/
   --查出请假的记录数据加到考勤表
/*   EXECUTE IMMEDIATE 'insert into TB_ATTDINFO_DAY_TJ
  (FD_DATE, FD_EMPID, FD_EMPNME, FD_NORMAL_DAYS)'||v_sql;
  commit;*/
    --查出没有请假的记录数据加到考勤表
   EXECUTE IMMEDIATE 'insert into TB_ATTDINFO_DAY_TJ
  (FD_DATE, FD_EMPID, FD_EMPNME, FD_NORMAL_DAYS)'||v_empSql;
  commit;
  --更新请假记录数据
   FOR C_ROW IN C_LEAVE('%'||FD_LAST_DATE||'%') LOOP  
    DBMS_OUTPUT.PUT_LINE(C_ROW.leavename || '--' );
    if C_ROW.fd_leavetyp='010' then
       DBMS_OUTPUT.PUT_LINE(C_ROW.fd_leavetyp || '--' );
       update tb_attdinfo_day_tj t set t.fd_bussine_leave=1-t.fd_normal_days where t.fd_empid=C_ROW.fd_empid and t.fd_date=FD_LAST_DATE;
    elsif C_ROW.fd_leavetyp='020' then
          DBMS_OUTPUT.PUT_LINE(C_ROW.fd_leavetyp || '--' );
          update tb_attdinfo_day_tj t set t.FD_ANNUAL_LEAVE=1-t.fd_normal_days where t.fd_empid=C_ROW.fd_empid and t.fd_date=FD_LAST_DATE;
    elsif C_ROW.fd_leavetyp='030' then
          DBMS_OUTPUT.PUT_LINE(C_ROW.fd_leavetyp || '--' );
          update tb_attdinfo_day_tj t set t.FD_AFFAIR_LEAVE=1-t.fd_normal_days where t.fd_empid=C_ROW.fd_empid and t.fd_date=FD_LAST_DATE;
    elsif C_ROW.fd_leavetyp='040' then
          update tb_attdinfo_day_tj t set t.FD_SICK_LEAVE=1-t.fd_normal_days where t.fd_empid=C_ROW.fd_empid and t.fd_date=FD_LAST_DATE;
    elsif C_ROW.fd_leavetyp='050' then
          update tb_attdinfo_day_tj t set t.FD_MARRIED_LEAVE=1-t.fd_normal_days where t.fd_empid=C_ROW.fd_empid and t.fd_date=FD_LAST_DATE;
    elsif C_ROW.fd_leavetyp='060' then
          update tb_attdinfo_day_tj t set t.FD_MATER_LEAVE=1-t.fd_normal_days where t.fd_empid=C_ROW.fd_empid and t.fd_date=FD_LAST_DATE;
    elsif C_ROW.fd_leavetyp='070' then
          update tb_attdinfo_day_tj t set t.FD_PLAN_LEAVE=1-t.fd_normal_days where t.fd_empid=C_ROW.fd_empid and t.fd_date=FD_LAST_DATE;
    elsif C_ROW.fd_leavetyp='080' then
          update tb_attdinfo_day_tj t set t.FD_FUNERNAL_LEAVE=1-t.fd_normal_days where t.fd_empid=C_ROW.fd_empid and t.fd_date=FD_LAST_DATE;
    elsif C_ROW.fd_leavetyp='090' then
          update tb_attdinfo_day_tj t set t.FD_HOME_LEAVE=1-t.fd_normal_days where t.fd_empid=C_ROW.fd_empid and t.fd_date=FD_LAST_DATE;
     elsif C_ROW.fd_leavetyp='100' then
          update tb_attdinfo_day_tj t set t.FD_WELFARE_LEAVE=1-t.fd_normal_days where t.fd_empid=C_ROW.fd_empid and t.fd_date=FD_LAST_DATE;
     elsif C_ROW.fd_leavetyp='110' then
          update tb_attdinfo_day_tj t set t.FD_INJURY_LEAVE=1-t.fd_normal_days where t.fd_empid=C_ROW.fd_empid and t.fd_date=FD_LAST_DATE;
    end if;
  END LOOP;
  commit;  
  --更新销假记录
   FOR C_CLEARROW IN C_CLEAR('%'||FD_LAST_DATE||'%') LOOP  
     DBMS_OUTPUT.PUT_LINE(C_CLEARROW.fd_leavetyp || '--eee'||ceil(C_CLEARROW.fd_hours/8) );
     if C_CLEARROW.fd_leavetyp='010' then
         update tb_attdinfo_day_tj t set t.fd_normal_days=t.fd_normal_days+ceil(C_CLEARROW.fd_hours/8),t.fd_bussine_leave=t.fd_bussine_leave-ceil(C_CLEARROW.fd_hours/8) where t.fd_empid=C_CLEARROW.fd_empid and t.fd_date=FD_LAST_DATE;
     elsif C_CLEARROW.fd_leavetyp='020' then
         update tb_attdinfo_day_tj t set t.fd_normal_days=t.fd_normal_days+ceil(C_CLEARROW.fd_hours/8),t.FD_ANNUAL_LEAVE=t.FD_ANNUAL_LEAVE-ceil(C_CLEARROW.fd_hours/8) where t.fd_empid=C_CLEARROW.fd_empid and t.fd_date=FD_LAST_DATE;
     elsif C_CLEARROW.fd_leavetyp='030' then
         update tb_attdinfo_day_tj t set t.fd_normal_days=t.fd_normal_days+ceil(C_CLEARROW.fd_hours/8),t.FD_AFFAIR_LEAVE=t.FD_AFFAIR_LEAVE-ceil(C_CLEARROW.fd_hours/8) where t.fd_empid=C_CLEARROW.fd_empid and t.fd_date=FD_LAST_DATE;
     elsif C_CLEARROW.fd_leavetyp='040' then
         update tb_attdinfo_day_tj t set t.fd_normal_days=t.fd_normal_days+ceil(C_CLEARROW.fd_hours/8),t.FD_SICK_LEAVE=t.FD_SICK_LEAVE-ceil(C_CLEARROW.fd_hours/8) where t.fd_empid=C_CLEARROW.fd_empid and t.fd_date=FD_LAST_DATE;
     elsif C_CLEARROW.fd_leavetyp='050' then
         update tb_attdinfo_day_tj t set t.fd_normal_days=t.fd_normal_days+ceil(C_CLEARROW.fd_hours/8),t.FD_MARRIED_LEAVE=t.FD_MARRIED_LEAVE-ceil(C_CLEARROW.fd_hours/8) where t.fd_empid=C_CLEARROW.fd_empid and t.fd_date=FD_LAST_DATE;
     elsif C_CLEARROW.fd_leavetyp='060' then
          update tb_attdinfo_day_tj t set t.fd_normal_days=t.fd_normal_days+ceil(C_CLEARROW.fd_hours/8),t.FD_MATER_LEAVE=t.FD_MATER_LEAVE-ceil(C_CLEARROW.fd_hours/8) where t.fd_empid=C_CLEARROW.fd_empid and t.fd_date=FD_LAST_DATE; 
     elsif C_CLEARROW.fd_leavetyp='070' then
          update tb_attdinfo_day_tj t set t.fd_normal_days=t.fd_normal_days+ceil(C_CLEARROW.fd_hours/8),t.FD_PLAN_LEAVE=t.FD_PLAN_LEAVE-ceil(C_CLEARROW.fd_hours/8) where t.fd_empid=C_CLEARROW.fd_empid and t.fd_date=FD_LAST_DATE;
     elsif C_CLEARROW.fd_leavetyp='080' then
          update tb_attdinfo_day_tj t set t.fd_normal_days=t.fd_normal_days+ceil(C_CLEARROW.fd_hours/8),t.FD_FUNERNAL_LEAVE=t.FD_FUNERNAL_LEAVE-ceil(C_CLEARROW.fd_hours/8) where t.fd_empid=C_CLEARROW.fd_empid and t.fd_date=FD_LAST_DATE;
     elsif C_CLEARROW.fd_leavetyp='090' then
          update tb_attdinfo_day_tj t set t.fd_normal_days=t.fd_normal_days+ceil(C_CLEARROW.fd_hours/8),t.FD_HOME_LEAVE=t.FD_HOME_LEAVE-ceil(C_CLEARROW.fd_hours/8) where t.fd_empid=C_CLEARROW.fd_empid and t.fd_date=FD_LAST_DATE;
     elsif C_CLEARROW.fd_leavetyp='100' then
          update tb_attdinfo_day_tj t set t.fd_normal_days=t.fd_normal_days+ceil(C_CLEARROW.fd_hours/8),t.FD_WELFARE_LEAVE=t.FD_WELFARE_LEAVE-ceil(C_CLEARROW.fd_hours/8) where t.fd_empid=C_CLEARROW.fd_empid and t.fd_date=FD_LAST_DATE;
     elsif C_CLEARROW.fd_leavetyp='110' then
          update tb_attdinfo_day_tj t set t.fd_normal_days=t.fd_normal_days+ceil(C_CLEARROW.fd_hours/8),t.FD_INJURY_LEAVE=t.FD_INJURY_LEAVE-ceil(C_CLEARROW.fd_hours/8) where t.fd_empid=C_CLEARROW.fd_empid and t.fd_date=FD_LAST_DATE;
     end if;
   END LOOP;
   commit;
  --更新迟到早退旷工记录
    --旷工
  update tb_attdinfo_day_tj d set 
  --d.FD_ABSENT_DAYS='1',d.fd_normal_days='0'
  d.FD_ABSENT_DAYS=case when fd_normal_days = 1 then 1 else null end  
  --,d.fd_normal_days=case when fd_normal_days = 1 then 0 else 1 end
  where exists(
  select 1 from  tb_pepmgm_attdinfo_tj p 
  where d.fd_empid=p.fd_empid and d.fd_date=p.fd_date and p.fd_mflag='4' and p.fd_date=FD_LAST_DATE);
   commit;
   --迟到
  update tb_attdinfo_day_tj d set d.FD_LATE_TIMES='1',d.fd_normal_days='0'
  where exists(
  select 1 from  tb_pepmgm_attdinfo_tj p 
  where d.fd_empid=p.fd_empid and d.fd_date=p.fd_date and p.fd_mflag='2' and p.fd_date=FD_LAST_DATE);
   commit;
  --早退
  update tb_attdinfo_day_tj d set d.FD_EARLY_TIMES='1',d.fd_normal_days='0'
  where exists(
  select 1 from  tb_pepmgm_attdinfo_tj p 
  where d.fd_empid=p.fd_empid and d.fd_date=p.fd_date and p.fd_mflag='3' and p.fd_date=FD_LAST_DATE);
   commit;
   
  --更新加班记录

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    ROLLBACK;
end P_ATTDINFO_DAYS1;
/
