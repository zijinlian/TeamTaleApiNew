CREATE PROCEDURE P_TMP_EHR_UPDATE
/**************************************************************/
  /*Function:机构信息更新                                    */
  /*InputParam:                                       */
  /*OutputParam:                                                */
  /*Create-Date:Aug. 17th,2016                                   */
  /*Author:Pansky-cx                                            */
  /**************************************************************/
IS
  --变量声明
  
BEGIN

EXECUTE IMMEDIATE 'truncate table tmp_tb_sys_orginfo_ehr';

/**
插入下传平台数据
**/
insert into tmp_tb_sys_orginfo_ehr(FD_ORGCDE,FD_PARENT_ORGCDE,FD_ORGNME,FD_ENGNME,FD_ACTUALADDRESS,FD_POSTCDE,FD_DATATYPE,FD_ORGFLAG)
select t.jgh as FD_ORGCDE,t.sjjgh as FD_PARENT_ORGCDE,t.jgmc as FD_ORGNME,
t.jgywmc as FD_ENGNME,t.jgdz as FD_ACTUALADDRESS,
t.jgyb as FD_POSTCDE,
decode(t.jglx,'1','全辖汇总','2','全辖汇总','3','全辖汇总','4','全辖汇总') as FD_DATATYPE,
decode(t.jgbz,'0','机构（网点）','1','虚拟机构','9','部门','12','部门内设团队','14','机构（网点）内设职位组','17','部门内设职位组','19','部门所辖中心','21','其他人员','24','营业部') as FD_ORGFLAG
from xc_tb_ehr_tb_org_orgunit t;
commit;

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
    ROLLBACK;
end P_TMP_EHR_UPDATE;
/
