CREATE VIEW V_ROLEINFO AS SELECT
    p.fd_roleid                                NODEID,
    p.fd_rolenme                               TITLE
FROM TB_SYS_ROLEINFO p
/
