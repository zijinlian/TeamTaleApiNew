CREATE VIEW V_TB_SYS_ORGINFO_EHR AS select t.jgh as FD_ORGCDE,t.sjjgh as FD_PARENT_ORGCDE,t.jgmc as FD_ORGNME,
t.jgywmc as FD_ENGNME,t.jgdz as FD_ACTUALADDRESS,
t.jgyb as FD_POSTCDE,
decode(t.jglx,'1','全辖汇总','2','全辖汇总','3','全辖汇总','4','全辖汇总') as FD_DATATYPE,
decode(t.jgbz,'0','机构（网点）','1','虚拟机构','9','部门','12','部门内设团队','14','机构（网点）内设职位组','17','部门内设职位组','19','部门所辖中心','21','其他人员','24','营业部') as FD_ORGFLAG
from xc_tb_ehr_tb_org_orgunit t
/
