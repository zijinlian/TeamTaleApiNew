package com.work.entity;

public class TBankCircleComment {
	private String id;

	private String circleId;

	private String empId;

	private String content;

	private String pEmpId;

	private String createTime;
	
	private String name;
	
	private String icon;
	
	private String pName;
	
	private String pIcon;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCircleId() {
		return circleId;
	}

	public void setCircleId(String circleId) {
		this.circleId = circleId;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getpEmpId() {
		return pEmpId;
	}

	public void setpEmpId(String pEmpId) {
		this.pEmpId = pEmpId;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public String getpIcon() {
		return pIcon;
	}

	public void setpIcon(String pIcon) {
		this.pIcon = pIcon;
	}
	
}