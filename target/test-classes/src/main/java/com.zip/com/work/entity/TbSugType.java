package com.work.entity;

public class TbSugType {
    private String fdTypeId;

    private String fdTypeNme;

    private String fdEmpId;

    private String fdEmpNme;

    private String fdCreateTime;

    public String getFdTypeId() {
        return fdTypeId;
    }

    public void setFdTypeId(String fdTypeId) {
        this.fdTypeId = fdTypeId;
    }

    public String getFdTypeNme() {
        return fdTypeNme;
    }

    public void setFdTypeNme(String fdTypeNme) {
        this.fdTypeNme = fdTypeNme;
    }

    public String getFdEmpId() {
        return fdEmpId;
    }

    public void setFdEmpId(String fdEmpId) {
        this.fdEmpId = fdEmpId;
    }

    public String getFdEmpNme() {
        return fdEmpNme;
    }

    public void setFdEmpNme(String fdEmpNme) {
        this.fdEmpNme = fdEmpNme;
    }

    public String getFdCreateTime() {
        return fdCreateTime;
    }

    public void setFdCreateTime(String fdCreateTime) {
        this.fdCreateTime = fdCreateTime;
    }
}