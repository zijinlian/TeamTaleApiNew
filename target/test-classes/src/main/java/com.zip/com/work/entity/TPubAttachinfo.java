package com.work.entity;

import java.math.BigDecimal;

public class TPubAttachinfo {
    private String fdAttachid;

	private String fdAttachtyp;

	private String fdSourcenme;

	private String fdNewnme;

	private String fdStorepath;

	private String fdUploaderid;

	private String fdUploadernme;

	private String fdUploadtime;

	private BigDecimal fdValidflag;

	private String fdComments;

	private String fdLoaded;

	public String getFdAttachid() {
		return fdAttachid;
	}

	public void setFdAttachid(String fdAttachid) {
		this.fdAttachid = fdAttachid;
	}

	public String getFdAttachtyp() {
		return fdAttachtyp;
	}

	public void setFdAttachtyp(String fdAttachtyp) {
		this.fdAttachtyp = fdAttachtyp;
	}

	public String getFdSourcenme() {
		return fdSourcenme;
	}

	public void setFdSourcenme(String fdSourcenme) {
		this.fdSourcenme = fdSourcenme;
	}

	public String getFdNewnme() {
		return fdNewnme;
	}

	public void setFdNewnme(String fdNewnme) {
		this.fdNewnme = fdNewnme;
	}

	public String getFdStorepath() {
		return fdStorepath;
	}

	public void setFdStorepath(String fdStorepath) {
		this.fdStorepath = fdStorepath;
	}

	public String getFdUploaderid() {
		return fdUploaderid;
	}

	public void setFdUploaderid(String fdUploaderid) {
		this.fdUploaderid = fdUploaderid;
	}

	public String getFdUploadernme() {
		return fdUploadernme;
	}

	public void setFdUploadernme(String fdUploadernme) {
		this.fdUploadernme = fdUploadernme;
	}

	public String getFdUploadtime() {
		return fdUploadtime;
	}

	public void setFdUploadtime(String fdUploadtime) {
		this.fdUploadtime = fdUploadtime;
	}

	public BigDecimal getFdValidflag() {
		return fdValidflag;
	}

	public void setFdValidflag(BigDecimal fdValidflag) {
		this.fdValidflag = fdValidflag;
	}

	public String getFdComments() {
		return fdComments;
	}

	public void setFdComments(String fdComments) {
		this.fdComments = fdComments;
	}

	public String getFdLoaded() {
		return fdLoaded;
	}

	public void setFdLoaded(String fdLoaded) {
		this.fdLoaded = fdLoaded;
	}
}