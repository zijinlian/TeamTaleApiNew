package com.work.bean;

public class DeptCircleBean extends BaseRequestBean{

	
	
}
