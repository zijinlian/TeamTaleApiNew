package com.work.entity;

public class TIccStaffPaper extends TIccStaffPaperKey {
    private String fdStaffAnswer;

    private String fdStaffRightAnswer;

    private String fdStafffScore;

    public String getFdStaffAnswer() {
        return fdStaffAnswer;
    }

    public void setFdStaffAnswer(String fdStaffAnswer) {
        this.fdStaffAnswer = fdStaffAnswer;
    }

    public String getFdStaffRightAnswer() {
        return fdStaffRightAnswer;
    }

    public void setFdStaffRightAnswer(String fdStaffRightAnswer) {
        this.fdStaffRightAnswer = fdStaffRightAnswer;
    }

    public String getFdStafffScore() {
        return fdStafffScore;
    }

    public void setFdStafffScore(String fdStafffScore) {
        this.fdStafffScore = fdStafffScore;
    }
}