package com.work.entity;

public class TTaskSupervise {
    private String taskId;

    private String parentId;

    private String fdTaskName;

    private String fdLeaderId;

    private String fdLeaderName;

    private String fdAssistOrgname;

    private String fdStartDate;

    private String fdEndDate;

    private String fdTaskLevel;

    private String fdTaskRemark;

    private String fdEmpidInput;

    private String fdEmpnmeInpput;

    private String fdTaskStatus;

    private String fdTaskType;

    private String fdRouteRemark;

    private String fdHingeRemark;

    private String fdToolRemark;

    private String fdEmpDept;

    private String fdResponsible;

    private String fdResponsiblename;
    
    private String fdPublishTime;
    
    private String fdObjectId;//牵头部门
    
    private String fdTaskDept;//牵头部门名称

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getFdTaskName() {
        return fdTaskName;
    }

    public void setFdTaskName(String fdTaskName) {
        this.fdTaskName = fdTaskName;
    }

    public String getFdLeaderId() {
        return fdLeaderId;
    }

    public void setFdLeaderId(String fdLeaderId) {
        this.fdLeaderId = fdLeaderId;
    }

    public String getFdLeaderName() {
        return fdLeaderName;
    }

    public void setFdLeaderName(String fdLeaderName) {
        this.fdLeaderName = fdLeaderName;
    }

    public String getFdAssistOrgname() {
        return fdAssistOrgname;
    }

    public void setFdAssistOrgname(String fdAssistOrgname) {
        this.fdAssistOrgname = fdAssistOrgname;
    }

    public String getFdStartDate() {
        return fdStartDate;
    }

    public void setFdStartDate(String fdStartDate) {
        this.fdStartDate = fdStartDate;
    }

    public String getFdEndDate() {
        return fdEndDate;
    }

    public void setFdEndDate(String fdEndDate) {
        this.fdEndDate = fdEndDate;
    }

    public String getFdTaskLevel() {
        return fdTaskLevel;
    }

    public void setFdTaskLevel(String fdTaskLevel) {
        this.fdTaskLevel = fdTaskLevel;
    }

    public String getFdTaskRemark() {
        return fdTaskRemark;
    }

    public void setFdTaskRemark(String fdTaskRemark) {
        this.fdTaskRemark = fdTaskRemark;
    }

    public String getFdEmpidInput() {
        return fdEmpidInput;
    }

    public void setFdEmpidInput(String fdEmpidInput) {
        this.fdEmpidInput = fdEmpidInput;
    }

    public String getFdEmpnmeInpput() {
        return fdEmpnmeInpput;
    }

    public void setFdEmpnmeInpput(String fdEmpnmeInpput) {
        this.fdEmpnmeInpput = fdEmpnmeInpput;
    }

    public String getFdTaskStatus() {
        return fdTaskStatus;
    }

    public void setFdTaskStatus(String fdTaskStatus) {
        this.fdTaskStatus = fdTaskStatus;
    }

    public String getFdTaskType() {
        return fdTaskType;
    }

    public void setFdTaskType(String fdTaskType) {
        this.fdTaskType = fdTaskType;
    }

    public String getFdRouteRemark() {
        return fdRouteRemark;
    }

    public void setFdRouteRemark(String fdRouteRemark) {
        this.fdRouteRemark = fdRouteRemark;
    }

    public String getFdHingeRemark() {
        return fdHingeRemark;
    }

    public void setFdHingeRemark(String fdHingeRemark) {
        this.fdHingeRemark = fdHingeRemark;
    }

    public String getFdToolRemark() {
        return fdToolRemark;
    }

    public void setFdToolRemark(String fdToolRemark) {
        this.fdToolRemark = fdToolRemark;
    }

    public String getFdEmpDept() {
        return fdEmpDept;
    }

    public void setFdEmpDept(String fdEmpDept) {
        this.fdEmpDept = fdEmpDept;
    }

    public String getFdResponsible() {
        return fdResponsible;
    }

    public void setFdResponsible(String fdResponsible) {
        this.fdResponsible = fdResponsible;
    }

    public String getFdResponsiblename() {
        return fdResponsiblename;
    }

    public void setFdResponsiblename(String fdResponsiblename) {
        this.fdResponsiblename = fdResponsiblename;
    }

	public String getFdPublishTime() {
		return fdPublishTime;
	}

	public void setFdPublishTime(String fdPublishTime) {
		this.fdPublishTime = fdPublishTime;
	}

	public String getFdObjectId() {
		return fdObjectId;
	}

	public void setFdObjectId(String fdObjectId) {
		this.fdObjectId = fdObjectId;
	}

	public String getFdTaskDept() {
		return fdTaskDept;
	}

	public void setFdTaskDept(String fdTaskDept) {
		this.fdTaskDept = fdTaskDept;
	}
    
	
}