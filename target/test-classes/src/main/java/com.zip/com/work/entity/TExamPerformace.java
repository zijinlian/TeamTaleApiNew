package com.work.entity;


public class TExamPerformace {
	
	private String fdEmpId;
	
	private String fdEmpName;
	
	private String fdOrgCde;
	
	private String fdOrgName;
	
	private String fdExamId;
	
	private String fdExamNme;
	
	private String fdOrder;
	
	public String getFdExamNme() {
		return fdExamNme;
	}

	public void setFdExamNme(String fdExamNme) {
		this.fdExamNme = fdExamNme;
	}

	public String getFdEmpId() {
		return fdEmpId;
	}

	public void setFdEmpId(String fdEmpId) {
		this.fdEmpId = fdEmpId;
	}

	public String getFdEmpName() {
		return fdEmpName;
	}

	public void setFdEmpName(String fdEmpName) {
		this.fdEmpName = fdEmpName;
	}

	public String getFdOrgCde() {
		return fdOrgCde;
	}

	public void setFdOrgCde(String fdOrgCde) {
		this.fdOrgCde = fdOrgCde;
	}

	public String getFdOrgName() {
		return fdOrgName;
	}

	public void setFdOrgName(String fdOrgName) {
		this.fdOrgName = fdOrgName;
	}

	public String getFdExamId() {
		return fdExamId;
	}

	public void setFdExamId(String fdExamId) {
		this.fdExamId = fdExamId;
	}

	public String getFdOrder() {
		return fdOrder;
	}

	public void setFdOrder(String fdOrder) {
		this.fdOrder = fdOrder;
	}
	
	
	
}
