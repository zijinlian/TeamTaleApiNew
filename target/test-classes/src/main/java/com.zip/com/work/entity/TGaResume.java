package com.work.entity;

public class TGaResume {
    private String id;

    private String empid;

    private String empname;

    private String groupnamenow;

    private String jobnamenow;

    private String empstatus;

    private String enddate;

    private String startdate;

    private String groupname;

    private String jobname;

    private String inputtype;

    private String reference;

    private String globalorder;

    private String inputdate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmpid() {
        return empid;
    }

    public void setEmpid(String empid) {
        this.empid = empid;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getGroupnamenow() {
        return groupnamenow;
    }

    public void setGroupnamenow(String groupnamenow) {
        this.groupnamenow = groupnamenow;
    }

    public String getJobnamenow() {
        return jobnamenow;
    }

    public void setJobnamenow(String jobnamenow) {
        this.jobnamenow = jobnamenow;
    }

    public String getEmpstatus() {
        return empstatus;
    }

    public void setEmpstatus(String empstatus) {
        this.empstatus = empstatus;
    }

    public String getEnddate() {
        return enddate;
    }

    public void setEnddate(String enddate) {
        this.enddate = enddate;
    }

    public String getStartdate() {
        return startdate;
    }

    public void setStartdate(String startdate) {
        this.startdate = startdate;
    }

    public String getGroupname() {
        return groupname;
    }

    public void setGroupname(String groupname) {
        this.groupname = groupname;
    }

    public String getJobname() {
        return jobname;
    }

    public void setJobname(String jobname) {
        this.jobname = jobname;
    }

    public String getInputtype() {
        return inputtype;
    }

    public void setInputtype(String inputtype) {
        this.inputtype = inputtype;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getGlobalorder() {
        return globalorder;
    }

    public void setGlobalorder(String globalorder) {
        this.globalorder = globalorder;
    }

    public String getInputdate() {
        return inputdate;
    }

    public void setInputdate(String inputdate) {
        this.inputdate = inputdate;
    }
}