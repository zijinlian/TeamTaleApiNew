package com.work.entity;

public class TTraiTeacher {
    private String teacherid;

    private String teachername;

    private String isexternal;

    private String commnet;

    private String teacherempid;

    private String operatorid;

    private String operatorname;

    private String operatortime;

    private String deptcode;
    
    private String fdHeadicon;
    
    public String getFdHeadicon() {
		return fdHeadicon;
	}

	public void setFdHeadicon(String fdHeadicon) {
		this.fdHeadicon = fdHeadicon;
	}

	public String getTeacherid() {
        return teacherid;
    }

    public void setTeacherid(String teacherid) {
        this.teacherid = teacherid;
    }

    public String getTeachername() {
        return teachername;
    }

    public void setTeachername(String teachername) {
        this.teachername = teachername;
    }

    public String getIsexternal() {
        return isexternal;
    }

    public void setIsexternal(String isexternal) {
        this.isexternal = isexternal;
    }

    public String getCommnet() {
        return commnet;
    }

    public void setCommnet(String commnet) {
        this.commnet = commnet;
    }

    public String getTeacherempid() {
        return teacherempid;
    }

    public void setTeacherempid(String teacherempid) {
        this.teacherempid = teacherempid;
    }

    public String getOperatorid() {
        return operatorid;
    }

    public void setOperatorid(String operatorid) {
        this.operatorid = operatorid;
    }

    public String getOperatorname() {
        return operatorname;
    }

    public void setOperatorname(String operatorname) {
        this.operatorname = operatorname;
    }

    public String getOperatortime() {
        return operatortime;
    }

    public void setOperatortime(String operatortime) {
        this.operatortime = operatortime;
    }

    public String getDeptcode() {
        return deptcode;
    }

    public void setDeptcode(String deptcode) {
        this.deptcode = deptcode;
    }
}