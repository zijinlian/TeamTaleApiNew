package com.work.bean;


public class BaseRequestBean extends PageBean{

	private String userid;
	
	public String getUserid() {
		return  userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}
}
