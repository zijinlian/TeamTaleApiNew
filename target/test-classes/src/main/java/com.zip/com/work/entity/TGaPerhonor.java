package com.work.entity;

public class TGaPerhonor {
    private String id;

    private String honorlevel;

    private String honorname;

    private String empid;

    private String empname;

    private String inputdate;

    private String honordate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHonorlevel() {
        return honorlevel;
    }

    public void setHonorlevel(String honorlevel) {
        this.honorlevel = honorlevel;
    }

    public String getHonorname() {
        return honorname;
    }

    public void setHonorname(String honorname) {
        this.honorname = honorname;
    }

    public String getEmpid() {
        return empid;
    }

    public void setEmpid(String empid) {
        this.empid = empid;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getInputdate() {
        return inputdate;
    }

    public void setInputdate(String inputdate) {
        this.inputdate = inputdate;
    }

    public String getHonordate() {
        return honordate;
    }

    public void setHonordate(String honordate) {
        this.honordate = honordate;
    }
}