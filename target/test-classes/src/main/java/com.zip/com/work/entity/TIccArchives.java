package com.work.entity;

public class TIccArchives {
    private String fdArchivesId;

    private String fdArchivesA;

    private String fdArchivesB;

    private String fdArchivesC;

    private String fdArchivesD;

    private String fdArchivesE;

    private String fdArchivesF;

    private String fdArchivesG;

    private String fdArchivesH;

    private String fdArchivesI;

    private String fdArchivesJ;

    private String fdArchivesK;

    private String fdArchivesL;

    private String fdArchivesM;

    private String fdArchivesN;

    private String fdArchivesO;

    private String fdArchivesP;

    private String fdArchivesQ;

    private String fdArchivesR;

    private String fdArchivesS;

    private String fdArchivesT;

    private String fdArchivesU;

    private String fdArchivesV;

    private String fdArchivesW;

    private String fdArchivesX;

    private String fdArchivesY;

    private String fdArchivesZ;

    private String fdArchivesAa;

    private String fdArchivesAb;

    private String fdArchivesAc;

    private String fdArchivesAd;

    private String fdArchivesAe;

    private String fdArchivesAf;

    private String fdArchivesAg;

    private String fdArchivesAh;

    private String fdArchivesAi;

    private String fdArchivesAj;

    private String fdArchivesAk;

    private String fdArchivesAl;

    private String fdArchivesAm;

    private String fdArchivesAn;

    private String fdArchivesAo;

    private String fdArchivesAp;

    private String fdArchivesAq;

    private String fdArchivesDate;

    private String fdArchivesAr;

    private String fdArchivesAs;

    private String fdArchivesAt;

    private String fdArchivesAu;

    private String fdArchivesAv;

    private String fdArchivesAw;

    private String fdArchivesAx;

    private String fdArchivesAy;

    private String fdArchivesAz;

    private String fdArchivesBa;

    private String fdArchivesBb;

    private String fdArchivesBc;

    private String fdArchivesBd;

    public String getFdArchivesId() {
        return fdArchivesId;
    }

    public void setFdArchivesId(String fdArchivesId) {
        this.fdArchivesId = fdArchivesId;
    }

    public String getFdArchivesA() {
        return fdArchivesA;
    }

    public void setFdArchivesA(String fdArchivesA) {
        this.fdArchivesA = fdArchivesA;
    }

    public String getFdArchivesB() {
        return fdArchivesB;
    }

    public void setFdArchivesB(String fdArchivesB) {
        this.fdArchivesB = fdArchivesB;
    }

    public String getFdArchivesC() {
        return fdArchivesC;
    }

    public void setFdArchivesC(String fdArchivesC) {
        this.fdArchivesC = fdArchivesC;
    }

    public String getFdArchivesD() {
        return fdArchivesD;
    }

    public void setFdArchivesD(String fdArchivesD) {
        this.fdArchivesD = fdArchivesD;
    }

    public String getFdArchivesE() {
        return fdArchivesE;
    }

    public void setFdArchivesE(String fdArchivesE) {
        this.fdArchivesE = fdArchivesE;
    }

    public String getFdArchivesF() {
        return fdArchivesF;
    }

    public void setFdArchivesF(String fdArchivesF) {
        this.fdArchivesF = fdArchivesF;
    }

    public String getFdArchivesG() {
        return fdArchivesG;
    }

    public void setFdArchivesG(String fdArchivesG) {
        this.fdArchivesG = fdArchivesG;
    }

    public String getFdArchivesH() {
        return fdArchivesH;
    }

    public void setFdArchivesH(String fdArchivesH) {
        this.fdArchivesH = fdArchivesH;
    }

    public String getFdArchivesI() {
        return fdArchivesI;
    }

    public void setFdArchivesI(String fdArchivesI) {
        this.fdArchivesI = fdArchivesI;
    }

    public String getFdArchivesJ() {
        return fdArchivesJ;
    }

    public void setFdArchivesJ(String fdArchivesJ) {
        this.fdArchivesJ = fdArchivesJ;
    }

    public String getFdArchivesK() {
        return fdArchivesK;
    }

    public void setFdArchivesK(String fdArchivesK) {
        this.fdArchivesK = fdArchivesK;
    }

    public String getFdArchivesL() {
        return fdArchivesL;
    }

    public void setFdArchivesL(String fdArchivesL) {
        this.fdArchivesL = fdArchivesL;
    }

    public String getFdArchivesM() {
        return fdArchivesM;
    }

    public void setFdArchivesM(String fdArchivesM) {
        this.fdArchivesM = fdArchivesM;
    }

    public String getFdArchivesN() {
        return fdArchivesN;
    }

    public void setFdArchivesN(String fdArchivesN) {
        this.fdArchivesN = fdArchivesN;
    }

    public String getFdArchivesO() {
        return fdArchivesO;
    }

    public void setFdArchivesO(String fdArchivesO) {
        this.fdArchivesO = fdArchivesO;
    }

    public String getFdArchivesP() {
        return fdArchivesP;
    }

    public void setFdArchivesP(String fdArchivesP) {
        this.fdArchivesP = fdArchivesP;
    }

    public String getFdArchivesQ() {
        return fdArchivesQ;
    }

    public void setFdArchivesQ(String fdArchivesQ) {
        this.fdArchivesQ = fdArchivesQ;
    }

    public String getFdArchivesR() {
        return fdArchivesR;
    }

    public void setFdArchivesR(String fdArchivesR) {
        this.fdArchivesR = fdArchivesR;
    }

    public String getFdArchivesS() {
        return fdArchivesS;
    }

    public void setFdArchivesS(String fdArchivesS) {
        this.fdArchivesS = fdArchivesS;
    }

    public String getFdArchivesT() {
        return fdArchivesT;
    }

    public void setFdArchivesT(String fdArchivesT) {
        this.fdArchivesT = fdArchivesT;
    }

    public String getFdArchivesU() {
        return fdArchivesU;
    }

    public void setFdArchivesU(String fdArchivesU) {
        this.fdArchivesU = fdArchivesU;
    }

    public String getFdArchivesV() {
        return fdArchivesV;
    }

    public void setFdArchivesV(String fdArchivesV) {
        this.fdArchivesV = fdArchivesV;
    }

    public String getFdArchivesW() {
        return fdArchivesW;
    }

    public void setFdArchivesW(String fdArchivesW) {
        this.fdArchivesW = fdArchivesW;
    }

    public String getFdArchivesX() {
        return fdArchivesX;
    }

    public void setFdArchivesX(String fdArchivesX) {
        this.fdArchivesX = fdArchivesX;
    }

    public String getFdArchivesY() {
        return fdArchivesY;
    }

    public void setFdArchivesY(String fdArchivesY) {
        this.fdArchivesY = fdArchivesY;
    }

    public String getFdArchivesZ() {
        return fdArchivesZ;
    }

    public void setFdArchivesZ(String fdArchivesZ) {
        this.fdArchivesZ = fdArchivesZ;
    }

    public String getFdArchivesAa() {
        return fdArchivesAa;
    }

    public void setFdArchivesAa(String fdArchivesAa) {
        this.fdArchivesAa = fdArchivesAa;
    }

    public String getFdArchivesAb() {
        return fdArchivesAb;
    }

    public void setFdArchivesAb(String fdArchivesAb) {
        this.fdArchivesAb = fdArchivesAb;
    }

    public String getFdArchivesAc() {
        return fdArchivesAc;
    }

    public void setFdArchivesAc(String fdArchivesAc) {
        this.fdArchivesAc = fdArchivesAc;
    }

    public String getFdArchivesAd() {
        return fdArchivesAd;
    }

    public void setFdArchivesAd(String fdArchivesAd) {
        this.fdArchivesAd = fdArchivesAd;
    }

    public String getFdArchivesAe() {
        return fdArchivesAe;
    }

    public void setFdArchivesAe(String fdArchivesAe) {
        this.fdArchivesAe = fdArchivesAe;
    }

    public String getFdArchivesAf() {
        return fdArchivesAf;
    }

    public void setFdArchivesAf(String fdArchivesAf) {
        this.fdArchivesAf = fdArchivesAf;
    }

    public String getFdArchivesAg() {
        return fdArchivesAg;
    }

    public void setFdArchivesAg(String fdArchivesAg) {
        this.fdArchivesAg = fdArchivesAg;
    }

    public String getFdArchivesAh() {
        return fdArchivesAh;
    }

    public void setFdArchivesAh(String fdArchivesAh) {
        this.fdArchivesAh = fdArchivesAh;
    }

    public String getFdArchivesAi() {
        return fdArchivesAi;
    }

    public void setFdArchivesAi(String fdArchivesAi) {
        this.fdArchivesAi = fdArchivesAi;
    }

    public String getFdArchivesAj() {
        return fdArchivesAj;
    }

    public void setFdArchivesAj(String fdArchivesAj) {
        this.fdArchivesAj = fdArchivesAj;
    }

    public String getFdArchivesAk() {
        return fdArchivesAk;
    }

    public void setFdArchivesAk(String fdArchivesAk) {
        this.fdArchivesAk = fdArchivesAk;
    }

    public String getFdArchivesAl() {
        return fdArchivesAl;
    }

    public void setFdArchivesAl(String fdArchivesAl) {
        this.fdArchivesAl = fdArchivesAl;
    }

    public String getFdArchivesAm() {
        return fdArchivesAm;
    }

    public void setFdArchivesAm(String fdArchivesAm) {
        this.fdArchivesAm = fdArchivesAm;
    }

    public String getFdArchivesAn() {
        return fdArchivesAn;
    }

    public void setFdArchivesAn(String fdArchivesAn) {
        this.fdArchivesAn = fdArchivesAn;
    }

    public String getFdArchivesAo() {
        return fdArchivesAo;
    }

    public void setFdArchivesAo(String fdArchivesAo) {
        this.fdArchivesAo = fdArchivesAo;
    }

    public String getFdArchivesAp() {
        return fdArchivesAp;
    }

    public void setFdArchivesAp(String fdArchivesAp) {
        this.fdArchivesAp = fdArchivesAp;
    }

    public String getFdArchivesAq() {
        return fdArchivesAq;
    }

    public void setFdArchivesAq(String fdArchivesAq) {
        this.fdArchivesAq = fdArchivesAq;
    }

    public String getFdArchivesDate() {
        return fdArchivesDate;
    }

    public void setFdArchivesDate(String fdArchivesDate) {
        this.fdArchivesDate = fdArchivesDate;
    }

    public String getFdArchivesAr() {
        return fdArchivesAr;
    }

    public void setFdArchivesAr(String fdArchivesAr) {
        this.fdArchivesAr = fdArchivesAr;
    }

    public String getFdArchivesAs() {
        return fdArchivesAs;
    }

    public void setFdArchivesAs(String fdArchivesAs) {
        this.fdArchivesAs = fdArchivesAs;
    }

    public String getFdArchivesAt() {
        return fdArchivesAt;
    }

    public void setFdArchivesAt(String fdArchivesAt) {
        this.fdArchivesAt = fdArchivesAt;
    }

    public String getFdArchivesAu() {
        return fdArchivesAu;
    }

    public void setFdArchivesAu(String fdArchivesAu) {
        this.fdArchivesAu = fdArchivesAu;
    }

    public String getFdArchivesAv() {
        return fdArchivesAv;
    }

    public void setFdArchivesAv(String fdArchivesAv) {
        this.fdArchivesAv = fdArchivesAv;
    }

    public String getFdArchivesAw() {
        return fdArchivesAw;
    }

    public void setFdArchivesAw(String fdArchivesAw) {
        this.fdArchivesAw = fdArchivesAw;
    }

    public String getFdArchivesAx() {
        return fdArchivesAx;
    }

    public void setFdArchivesAx(String fdArchivesAx) {
        this.fdArchivesAx = fdArchivesAx;
    }

    public String getFdArchivesAy() {
        return fdArchivesAy;
    }

    public void setFdArchivesAy(String fdArchivesAy) {
        this.fdArchivesAy = fdArchivesAy;
    }

    public String getFdArchivesAz() {
        return fdArchivesAz;
    }

    public void setFdArchivesAz(String fdArchivesAz) {
        this.fdArchivesAz = fdArchivesAz;
    }

    public String getFdArchivesBa() {
        return fdArchivesBa;
    }

    public void setFdArchivesBa(String fdArchivesBa) {
        this.fdArchivesBa = fdArchivesBa;
    }

    public String getFdArchivesBb() {
        return fdArchivesBb;
    }

    public void setFdArchivesBb(String fdArchivesBb) {
        this.fdArchivesBb = fdArchivesBb;
    }

    public String getFdArchivesBc() {
        return fdArchivesBc;
    }

    public void setFdArchivesBc(String fdArchivesBc) {
        this.fdArchivesBc = fdArchivesBc;
    }

    public String getFdArchivesBd() {
        return fdArchivesBd;
    }

    public void setFdArchivesBd(String fdArchivesBd) {
        this.fdArchivesBd = fdArchivesBd;
    }
}