package com.work.entity;

public class TbBlBltype {
    private String fdTypeId;

    private String fdTypeNme;

    private String fdCreateTime;

    private String fdCreater;

    private String fdTypeOrder;

    public String getFdTypeId() {
        return fdTypeId;
    }

    public void setFdTypeId(String fdTypeId) {
        this.fdTypeId = fdTypeId;
    }

    public String getFdTypeNme() {
        return fdTypeNme;
    }

    public void setFdTypeNme(String fdTypeNme) {
        this.fdTypeNme = fdTypeNme;
    }

    public String getFdCreateTime() {
        return fdCreateTime;
    }

    public void setFdCreateTime(String fdCreateTime) {
        this.fdCreateTime = fdCreateTime;
    }

    public String getFdCreater() {
        return fdCreater;
    }

    public void setFdCreater(String fdCreater) {
        this.fdCreater = fdCreater;
    }

    public String getFdTypeOrder() {
        return fdTypeOrder;
    }

    public void setFdTypeOrder(String fdTypeOrder) {
        this.fdTypeOrder = fdTypeOrder;
    }
}