package com.work.entity;

public class TmpPepmgmEmpInfo {
    private String fdEmpid;

    private String fdEmpnme;

    private String fdGender;

    private String fdEmpBirth;

    private String fdStartWorkdate;

    private String fdHiredate;

    private String fdRhqgl;

    private String fdJrdqjgsj;

    private String fdJrdqyjjghzhsj;

    private String fdOrgSysnum;

    private String fdOrgcde;

    private String fdOrgnme;

    private String fdUnitcde;

    private String fdUnitSysnum;

    private String fdUnitnme;

    private String fdOrgEngnme;

    private String fdFactunitnme;

    private String fdUnitEngnme;

    private String fdFactunitSysnum;

    private String fdFactunitcde;

    private String fdFactunitEngnme;

    private String fdCredNum;

    private String fdCountry;

    private String fdRace;

    private String fdNation;

    private String fdEntryMode;

    private String fdEmptyp;

    private String fdLaborUnittyp;

    private String fdLaborUnitnme;

    private String fdGljsqssj;

    private String fdOrigin;

    private String fdBirthPlace;

    private String fdRegAddr;

    private String fdMaritalStatus;

    private String fdPoliticalStatus;

    private String fdPoliticalDate;

    private String fdServiceSituation;

    private String fdFinacStartdate;

    private String fdLeaveWay;

    private String fdLeaveDate;

    private String fdLeaveReason;

    private String fdLeaveForward;

    private String fdJobid;

    private String fdJobcde;

    private String fdJobnme;

    private String fdJobStartdate;

    private String fdEmpstat;

    private String fdEmpage;

    private String fdMajor;

    private String fdHighEdu;

    private String fdHighDegree;

    private String fdYgsf;

    private String fdZwcjbj;

    private String fdWtryzt;

    private String fdQjxssx;

    public String getFdEmpid() {
        return fdEmpid;
    }

    public void setFdEmpid(String fdEmpid) {
        this.fdEmpid = fdEmpid;
    }

    public String getFdEmpnme() {
        return fdEmpnme;
    }

    public void setFdEmpnme(String fdEmpnme) {
        this.fdEmpnme = fdEmpnme;
    }

    public String getFdGender() {
        return fdGender;
    }

    public void setFdGender(String fdGender) {
        this.fdGender = fdGender;
    }

    public String getFdEmpBirth() {
        return fdEmpBirth;
    }

    public void setFdEmpBirth(String fdEmpBirth) {
        this.fdEmpBirth = fdEmpBirth;
    }

    public String getFdStartWorkdate() {
        return fdStartWorkdate;
    }

    public void setFdStartWorkdate(String fdStartWorkdate) {
        this.fdStartWorkdate = fdStartWorkdate;
    }

    public String getFdHiredate() {
        return fdHiredate;
    }

    public void setFdHiredate(String fdHiredate) {
        this.fdHiredate = fdHiredate;
    }

    public String getFdRhqgl() {
        return fdRhqgl;
    }

    public void setFdRhqgl(String fdRhqgl) {
        this.fdRhqgl = fdRhqgl;
    }

    public String getFdJrdqjgsj() {
        return fdJrdqjgsj;
    }

    public void setFdJrdqjgsj(String fdJrdqjgsj) {
        this.fdJrdqjgsj = fdJrdqjgsj;
    }

    public String getFdJrdqyjjghzhsj() {
        return fdJrdqyjjghzhsj;
    }

    public void setFdJrdqyjjghzhsj(String fdJrdqyjjghzhsj) {
        this.fdJrdqyjjghzhsj = fdJrdqyjjghzhsj;
    }

    public String getFdOrgSysnum() {
        return fdOrgSysnum;
    }

    public void setFdOrgSysnum(String fdOrgSysnum) {
        this.fdOrgSysnum = fdOrgSysnum;
    }

    public String getFdOrgcde() {
        return fdOrgcde;
    }

    public void setFdOrgcde(String fdOrgcde) {
        this.fdOrgcde = fdOrgcde;
    }

    public String getFdOrgnme() {
        return fdOrgnme;
    }

    public void setFdOrgnme(String fdOrgnme) {
        this.fdOrgnme = fdOrgnme;
    }

    public String getFdUnitcde() {
        return fdUnitcde;
    }

    public void setFdUnitcde(String fdUnitcde) {
        this.fdUnitcde = fdUnitcde;
    }

    public String getFdUnitSysnum() {
        return fdUnitSysnum;
    }

    public void setFdUnitSysnum(String fdUnitSysnum) {
        this.fdUnitSysnum = fdUnitSysnum;
    }

    public String getFdUnitnme() {
        return fdUnitnme;
    }

    public void setFdUnitnme(String fdUnitnme) {
        this.fdUnitnme = fdUnitnme;
    }

    public String getFdOrgEngnme() {
        return fdOrgEngnme;
    }

    public void setFdOrgEngnme(String fdOrgEngnme) {
        this.fdOrgEngnme = fdOrgEngnme;
    }

    public String getFdFactunitnme() {
        return fdFactunitnme;
    }

    public void setFdFactunitnme(String fdFactunitnme) {
        this.fdFactunitnme = fdFactunitnme;
    }

    public String getFdUnitEngnme() {
        return fdUnitEngnme;
    }

    public void setFdUnitEngnme(String fdUnitEngnme) {
        this.fdUnitEngnme = fdUnitEngnme;
    }

    public String getFdFactunitSysnum() {
        return fdFactunitSysnum;
    }

    public void setFdFactunitSysnum(String fdFactunitSysnum) {
        this.fdFactunitSysnum = fdFactunitSysnum;
    }

    public String getFdFactunitcde() {
        return fdFactunitcde;
    }

    public void setFdFactunitcde(String fdFactunitcde) {
        this.fdFactunitcde = fdFactunitcde;
    }

    public String getFdFactunitEngnme() {
        return fdFactunitEngnme;
    }

    public void setFdFactunitEngnme(String fdFactunitEngnme) {
        this.fdFactunitEngnme = fdFactunitEngnme;
    }

    public String getFdCredNum() {
        return fdCredNum;
    }

    public void setFdCredNum(String fdCredNum) {
        this.fdCredNum = fdCredNum;
    }

    public String getFdCountry() {
        return fdCountry;
    }

    public void setFdCountry(String fdCountry) {
        this.fdCountry = fdCountry;
    }

    public String getFdRace() {
        return fdRace;
    }

    public void setFdRace(String fdRace) {
        this.fdRace = fdRace;
    }

    public String getFdNation() {
        return fdNation;
    }

    public void setFdNation(String fdNation) {
        this.fdNation = fdNation;
    }

    public String getFdEntryMode() {
        return fdEntryMode;
    }

    public void setFdEntryMode(String fdEntryMode) {
        this.fdEntryMode = fdEntryMode;
    }

    public String getFdEmptyp() {
        return fdEmptyp;
    }

    public void setFdEmptyp(String fdEmptyp) {
        this.fdEmptyp = fdEmptyp;
    }

    public String getFdLaborUnittyp() {
        return fdLaborUnittyp;
    }

    public void setFdLaborUnittyp(String fdLaborUnittyp) {
        this.fdLaborUnittyp = fdLaborUnittyp;
    }

    public String getFdLaborUnitnme() {
        return fdLaborUnitnme;
    }

    public void setFdLaborUnitnme(String fdLaborUnitnme) {
        this.fdLaborUnitnme = fdLaborUnitnme;
    }

    public String getFdGljsqssj() {
        return fdGljsqssj;
    }

    public void setFdGljsqssj(String fdGljsqssj) {
        this.fdGljsqssj = fdGljsqssj;
    }

    public String getFdOrigin() {
        return fdOrigin;
    }

    public void setFdOrigin(String fdOrigin) {
        this.fdOrigin = fdOrigin;
    }

    public String getFdBirthPlace() {
        return fdBirthPlace;
    }

    public void setFdBirthPlace(String fdBirthPlace) {
        this.fdBirthPlace = fdBirthPlace;
    }

    public String getFdRegAddr() {
        return fdRegAddr;
    }

    public void setFdRegAddr(String fdRegAddr) {
        this.fdRegAddr = fdRegAddr;
    }

    public String getFdMaritalStatus() {
        return fdMaritalStatus;
    }

    public void setFdMaritalStatus(String fdMaritalStatus) {
        this.fdMaritalStatus = fdMaritalStatus;
    }

    public String getFdPoliticalStatus() {
        return fdPoliticalStatus;
    }

    public void setFdPoliticalStatus(String fdPoliticalStatus) {
        this.fdPoliticalStatus = fdPoliticalStatus;
    }

    public String getFdPoliticalDate() {
        return fdPoliticalDate;
    }

    public void setFdPoliticalDate(String fdPoliticalDate) {
        this.fdPoliticalDate = fdPoliticalDate;
    }

    public String getFdServiceSituation() {
        return fdServiceSituation;
    }

    public void setFdServiceSituation(String fdServiceSituation) {
        this.fdServiceSituation = fdServiceSituation;
    }

    public String getFdFinacStartdate() {
        return fdFinacStartdate;
    }

    public void setFdFinacStartdate(String fdFinacStartdate) {
        this.fdFinacStartdate = fdFinacStartdate;
    }

    public String getFdLeaveWay() {
        return fdLeaveWay;
    }

    public void setFdLeaveWay(String fdLeaveWay) {
        this.fdLeaveWay = fdLeaveWay;
    }

    public String getFdLeaveDate() {
        return fdLeaveDate;
    }

    public void setFdLeaveDate(String fdLeaveDate) {
        this.fdLeaveDate = fdLeaveDate;
    }

    public String getFdLeaveReason() {
        return fdLeaveReason;
    }

    public void setFdLeaveReason(String fdLeaveReason) {
        this.fdLeaveReason = fdLeaveReason;
    }

    public String getFdLeaveForward() {
        return fdLeaveForward;
    }

    public void setFdLeaveForward(String fdLeaveForward) {
        this.fdLeaveForward = fdLeaveForward;
    }

    public String getFdJobid() {
        return fdJobid;
    }

    public void setFdJobid(String fdJobid) {
        this.fdJobid = fdJobid;
    }

    public String getFdJobcde() {
        return fdJobcde;
    }

    public void setFdJobcde(String fdJobcde) {
        this.fdJobcde = fdJobcde;
    }

    public String getFdJobnme() {
        return fdJobnme;
    }

    public void setFdJobnme(String fdJobnme) {
        this.fdJobnme = fdJobnme;
    }

    public String getFdJobStartdate() {
        return fdJobStartdate;
    }

    public void setFdJobStartdate(String fdJobStartdate) {
        this.fdJobStartdate = fdJobStartdate;
    }

    public String getFdEmpstat() {
        return fdEmpstat;
    }

    public void setFdEmpstat(String fdEmpstat) {
        this.fdEmpstat = fdEmpstat;
    }

    public String getFdEmpage() {
        return fdEmpage;
    }

    public void setFdEmpage(String fdEmpage) {
        this.fdEmpage = fdEmpage;
    }

    public String getFdMajor() {
        return fdMajor;
    }

    public void setFdMajor(String fdMajor) {
        this.fdMajor = fdMajor;
    }

    public String getFdHighEdu() {
        return fdHighEdu;
    }

    public void setFdHighEdu(String fdHighEdu) {
        this.fdHighEdu = fdHighEdu;
    }

    public String getFdHighDegree() {
        return fdHighDegree;
    }

    public void setFdHighDegree(String fdHighDegree) {
        this.fdHighDegree = fdHighDegree;
    }

    public String getFdYgsf() {
        return fdYgsf;
    }

    public void setFdYgsf(String fdYgsf) {
        this.fdYgsf = fdYgsf;
    }

    public String getFdZwcjbj() {
        return fdZwcjbj;
    }

    public void setFdZwcjbj(String fdZwcjbj) {
        this.fdZwcjbj = fdZwcjbj;
    }

    public String getFdWtryzt() {
        return fdWtryzt;
    }

    public void setFdWtryzt(String fdWtryzt) {
        this.fdWtryzt = fdWtryzt;
    }

    public String getFdQjxssx() {
        return fdQjxssx;
    }

    public void setFdQjxssx(String fdQjxssx) {
        this.fdQjxssx = fdQjxssx;
    }
}