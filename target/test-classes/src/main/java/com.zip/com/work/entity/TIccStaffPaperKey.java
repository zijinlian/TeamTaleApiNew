package com.work.entity;

public class TIccStaffPaperKey {
    private String fdStaffId;

    private String fdPaperId;

    private String fdProblemId;

    private String fdStaffPaperDate;

    public String getFdStaffId() {
        return fdStaffId;
    }

    public void setFdStaffId(String fdStaffId) {
        this.fdStaffId = fdStaffId;
    }

    public String getFdPaperId() {
        return fdPaperId;
    }

    public void setFdPaperId(String fdPaperId) {
        this.fdPaperId = fdPaperId;
    }

    public String getFdProblemId() {
        return fdProblemId;
    }

    public void setFdProblemId(String fdProblemId) {
        this.fdProblemId = fdProblemId;
    }

    public String getFdStaffPaperDate() {
        return fdStaffPaperDate;
    }

    public void setFdStaffPaperDate(String fdStaffPaperDate) {
        this.fdStaffPaperDate = fdStaffPaperDate;
    }
}