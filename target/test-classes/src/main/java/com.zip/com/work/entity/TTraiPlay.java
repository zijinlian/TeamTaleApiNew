package com.work.entity;

public class TTraiPlay {
    private String courseid;

    private String chapternum;

    private String coursetitle;

    private String startime;

    private String endtime;

    private String coruseaddress;

    private String status;

    private String id;

    private String teacherid;

    private String teachername;

    public String getCourseid() {
        return courseid;
    }

    public void setCourseid(String courseid) {
        this.courseid = courseid;
    }

    public String getChapternum() {
        return chapternum;
    }

    public void setChapternum(String chapternum) {
        this.chapternum = chapternum;
    }

    public String getCoursetitle() {
        return coursetitle;
    }

    public void setCoursetitle(String coursetitle) {
        this.coursetitle = coursetitle;
    }

    public String getStartime() {
        return startime;
    }

    public void setStartime(String startime) {
        this.startime = startime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public String getCoruseaddress() {
        return coruseaddress;
    }

    public void setCoruseaddress(String coruseaddress) {
        this.coruseaddress = coruseaddress;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTeacherid() {
        return teacherid;
    }

    public void setTeacherid(String teacherid) {
        this.teacherid = teacherid;
    }

    public String getTeachername() {
        return teachername;
    }

    public void setTeachername(String teachername) {
        this.teachername = teachername;
    }
}