package com.work.entity;

public class TLike {
    private String fdLikeId;

    private String fdDissId;

    private String fdEmpid;

    public String getFdLikeId() {
        return fdLikeId;
    }

    public void setFdLikeId(String fdLikeId) {
        this.fdLikeId = fdLikeId;
    }

    public String getFdDissId() {
        return fdDissId;
    }

    public void setFdDissId(String fdDissId) {
        this.fdDissId = fdDissId;
    }

    public String getFdEmpid() {
        return fdEmpid;
    }

    public void setFdEmpid(String fdEmpid) {
        this.fdEmpid = fdEmpid;
    }
}