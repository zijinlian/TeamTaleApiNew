package com.work.entity;

import java.math.BigDecimal;

public class TSysUserinfo {
	
    private String fdUsername;

	private String fdPassword;

	private BigDecimal fdUsertype;

	private String fdExpiredate;

	private String fdRectchgdate;

	private BigDecimal fdFailedcnt;

	private String fdOnlinestat;

	private String fdName;

	private String fdGender;

	private String fdHeadicon;

	private String fdBirthdate;

	private String fdAutograph;

	private String fdIdcardno;

	private String fdMobphe;

	private String fdCompany;

	private String fdBizphe;

	private String fdBizaddr;

	private String fdEmail;

	private String fdHmphe;

	private String fdHmaddr;

	private String fdHxusername;

	private String fdHxpassword;

	public String getFdUsername() {
		return fdUsername;
	}

	public void setFdUsername(String fdUsername) {
		this.fdUsername = fdUsername;
	}

	public String getFdPassword() {
		return fdPassword;
	}

	public void setFdPassword(String fdPassword) {
		this.fdPassword = fdPassword;
	}

	public BigDecimal getFdUsertype() {
		return fdUsertype;
	}

	public void setFdUsertype(BigDecimal fdUsertype) {
		this.fdUsertype = fdUsertype;
	}

	public String getFdExpiredate() {
		return fdExpiredate;
	}

	public void setFdExpiredate(String fdExpiredate) {
		this.fdExpiredate = fdExpiredate;
	}

	public String getFdRectchgdate() {
		return fdRectchgdate;
	}

	public void setFdRectchgdate(String fdRectchgdate) {
		this.fdRectchgdate = fdRectchgdate;
	}

	public BigDecimal getFdFailedcnt() {
		return fdFailedcnt;
	}

	public void setFdFailedcnt(BigDecimal fdFailedcnt) {
		this.fdFailedcnt = fdFailedcnt;
	}

	public String getFdOnlinestat() {
		return fdOnlinestat;
	}

	public void setFdOnlinestat(String fdOnlinestat) {
		this.fdOnlinestat = fdOnlinestat;
	}

	public String getFdName() {
		return fdName;
	}

	public void setFdName(String fdName) {
		this.fdName = fdName;
	}

	public String getFdGender() {
		return fdGender;
	}

	public void setFdGender(String fdGender) {
		this.fdGender = fdGender;
	}

	public String getFdHeadicon() {
		return fdHeadicon;
	}

	public void setFdHeadicon(String fdHeadicon) {
		this.fdHeadicon = fdHeadicon;
	}

	public String getFdBirthdate() {
		return fdBirthdate;
	}

	public void setFdBirthdate(String fdBirthdate) {
		this.fdBirthdate = fdBirthdate;
	}

	public String getFdAutograph() {
		return fdAutograph;
	}

	public void setFdAutograph(String fdAutograph) {
		this.fdAutograph = fdAutograph;
	}

	public String getFdIdcardno() {
		return fdIdcardno;
	}

	public void setFdIdcardno(String fdIdcardno) {
		this.fdIdcardno = fdIdcardno;
	}

	public String getFdMobphe() {
		return fdMobphe;
	}

	public void setFdMobphe(String fdMobphe) {
		this.fdMobphe = fdMobphe;
	}

	public String getFdCompany() {
		return fdCompany;
	}

	public void setFdCompany(String fdCompany) {
		this.fdCompany = fdCompany;
	}

	public String getFdBizphe() {
		return fdBizphe;
	}

	public void setFdBizphe(String fdBizphe) {
		this.fdBizphe = fdBizphe;
	}

	public String getFdBizaddr() {
		return fdBizaddr;
	}

	public void setFdBizaddr(String fdBizaddr) {
		this.fdBizaddr = fdBizaddr;
	}

	public String getFdEmail() {
		return fdEmail;
	}

	public void setFdEmail(String fdEmail) {
		this.fdEmail = fdEmail;
	}

	public String getFdHmphe() {
		return fdHmphe;
	}

	public void setFdHmphe(String fdHmphe) {
		this.fdHmphe = fdHmphe;
	}

	public String getFdHmaddr() {
		return fdHmaddr;
	}

	public void setFdHmaddr(String fdHmaddr) {
		this.fdHmaddr = fdHmaddr;
	}

	public String getFdHxusername() {
		return fdHxusername;
	}

	public void setFdHxusername(String fdHxusername) {
		this.fdHxusername = fdHxusername;
	}

	public String getFdHxpassword() {
		return fdHxpassword;
	}

	public void setFdHxpassword(String fdHxpassword) {
		this.fdHxpassword = fdHxpassword;
	}

}