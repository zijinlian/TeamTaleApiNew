package com.work.entity;

public class TChickStaff {
    private String fdChickStaffId;

    private String fdStaffId;

    private String fdBodiesId;

    private String fdBodiesName;

    public String getFdChickStaffId() {
        return fdChickStaffId;
    }

    public void setFdChickStaffId(String fdChickStaffId) {
        this.fdChickStaffId = fdChickStaffId;
    }

    public String getFdStaffId() {
        return fdStaffId;
    }

    public void setFdStaffId(String fdStaffId) {
        this.fdStaffId = fdStaffId;
    }

    public String getFdBodiesId() {
        return fdBodiesId;
    }

    public void setFdBodiesId(String fdBodiesId) {
        this.fdBodiesId = fdBodiesId;
    }

    public String getFdBodiesName() {
        return fdBodiesName;
    }

    public void setFdBodiesName(String fdBodiesName) {
        this.fdBodiesName = fdBodiesName;
    }
}