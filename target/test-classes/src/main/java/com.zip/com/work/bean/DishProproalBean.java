package com.work.bean;

public class DishProproalBean {
	
    private String id;

    private String empid;

    private String empname;

    private String proposaltype;

    private String fdcoment;

    private String createtime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmpid() {
        return empid;
    }

    public void setEmpid(String empid) {
        this.empid = empid;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getProposaltype() {
        return proposaltype;
    }

    public void setProposaltype(String proposaltype) {
        this.proposaltype = proposaltype;
    }

    public String getFdcoment() {
        return fdcoment;
    }

    public void setFdcoment(String fdcoment) {
        this.fdcoment = fdcoment;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }
}