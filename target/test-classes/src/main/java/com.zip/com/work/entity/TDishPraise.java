package com.work.entity;

public class TDishPraise {
    private String id;

    private String empid;

    private String empname;

    private String dishid;

    private String praisedate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmpid() {
        return empid;
    }

    public void setEmpid(String empid) {
        this.empid = empid;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getDishid() {
        return dishid;
    }

    public void setDishid(String dishid) {
        this.dishid = dishid;
    }

    public String getPraisedate() {
        return praisedate;
    }

    public void setPraisedate(String praisedate) {
        this.praisedate = praisedate;
    }
}