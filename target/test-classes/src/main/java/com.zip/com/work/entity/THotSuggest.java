package com.work.entity;

/**
 * Created by System_User on 2016/12/31.
 */
public class THotSuggest {

    private String fd_appro_emp;
    private String fd_appro_org;
    private String fd_appro_stu;
    private String fd_appro_mark;
    private String fd_empid;

    public String getRepycount() {
        return repycount;
    }

    public void setRepycount(String repycount) {
        this.repycount = repycount;
    }

    public String getDisscount() {
        return disscount;
    }

    public void setDisscount(String disscount) {
        this.disscount = disscount;
    }

    private String repycount;
    private String disscount;
    private String fd_appro_time;
    private String fd_uuid;

    public String getFd_uuid() {
        return fd_uuid;
    }

    public void setFd_uuid(String fd_uuid) {
        this.fd_uuid = fd_uuid;
    }

    public String getFd_appro_time() {
        return fd_appro_time;
    }

    public void setFd_appro_time(String fd_appro_time) {
        this.fd_appro_time = fd_appro_time;
    }



    public String getFd_appro_emp() {
        return fd_appro_emp;
    }

    public void setFd_appro_emp(String fd_appro_emp) {
        this.fd_appro_emp = fd_appro_emp;
    }

    public String getFd_appro_org() {
        return fd_appro_org;
    }

    public void setFd_appro_org(String fd_appro_org) {
        this.fd_appro_org = fd_appro_org;
    }

    public String getFd_appro_stu() {
        return fd_appro_stu;
    }

    public void setFd_appro_stu(String fd_appro_stu) {
        this.fd_appro_stu = fd_appro_stu;
    }

    public String getFd_appro_mark() {
        return fd_appro_mark;
    }

    public void setFd_appro_mark(String fd_appro_mark) {
        this.fd_appro_mark = fd_appro_mark;
    }

    public String getFd_empid() {
        return fd_empid;
    }

    public void setFd_empid(String fd_empid) {
        this.fd_empid = fd_empid;
    }





}
