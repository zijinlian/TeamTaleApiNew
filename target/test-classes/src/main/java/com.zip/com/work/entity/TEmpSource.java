package com.work.entity;

import java.math.BigDecimal;

public class TEmpSource {
    private String empid;

    private BigDecimal tbGaResume;

    private BigDecimal tbGaPerhonor;

    private BigDecimal tbGaPerformance;

    private BigDecimal tbGaWorkcheck;

    private BigDecimal tbGaSkill;

    private BigDecimal tbGupDiploma;

    private BigDecimal tbTeacherCount;

    private BigDecimal tbStudyCount;

    private String updatedate;

    private BigDecimal tbGaGrouphonor;

    private String empname;

    public String getEmpid() {
        return empid;
    }

    public void setEmpid(String empid) {
        this.empid = empid;
    }

    public BigDecimal getTbGaResume() {
        return tbGaResume;
    }

    public void setTbGaResume(BigDecimal tbGaResume) {
        this.tbGaResume = tbGaResume;
    }

    public BigDecimal getTbGaPerhonor() {
        return tbGaPerhonor;
    }

    public void setTbGaPerhonor(BigDecimal tbGaPerhonor) {
        this.tbGaPerhonor = tbGaPerhonor;
    }

    public BigDecimal getTbGaPerformance() {
        return tbGaPerformance;
    }

    public void setTbGaPerformance(BigDecimal tbGaPerformance) {
        this.tbGaPerformance = tbGaPerformance;
    }

    public BigDecimal getTbGaWorkcheck() {
        return tbGaWorkcheck;
    }

    public void setTbGaWorkcheck(BigDecimal tbGaWorkcheck) {
        this.tbGaWorkcheck = tbGaWorkcheck;
    }

    public BigDecimal getTbGaSkill() {
        return tbGaSkill;
    }

    public void setTbGaSkill(BigDecimal tbGaSkill) {
        this.tbGaSkill = tbGaSkill;
    }

    public BigDecimal getTbGupDiploma() {
        return tbGupDiploma;
    }

    public void setTbGupDiploma(BigDecimal tbGupDiploma) {
        this.tbGupDiploma = tbGupDiploma;
    }

    public BigDecimal getTbTeacherCount() {
        return tbTeacherCount;
    }

    public void setTbTeacherCount(BigDecimal tbTeacherCount) {
        this.tbTeacherCount = tbTeacherCount;
    }

    public BigDecimal getTbStudyCount() {
        return tbStudyCount;
    }

    public void setTbStudyCount(BigDecimal tbStudyCount) {
        this.tbStudyCount = tbStudyCount;
    }

    public String getUpdatedate() {
        return updatedate;
    }

    public void setUpdatedate(String updatedate) {
        this.updatedate = updatedate;
    }

    public BigDecimal getTbGaGrouphonor() {
        return tbGaGrouphonor;
    }

    public void setTbGaGrouphonor(BigDecimal tbGaGrouphonor) {
        this.tbGaGrouphonor = tbGaGrouphonor;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }
}