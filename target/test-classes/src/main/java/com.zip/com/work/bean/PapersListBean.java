package com.work.bean;

public class PapersListBean extends BaseRequestBean{

}
