package com.work.entity;

public class TIccMath {
    private String fdMathsId;

    private String fdMathsName;

    private String fdMathsMark;

    private String fdMathsPeople;

    private String fdMathsDate;

    private String fdMathsStatus;

    public String getFdMathsId() {
        return fdMathsId;
    }

    public void setFdMathsId(String fdMathsId) {
        this.fdMathsId = fdMathsId;
    }

    public String getFdMathsName() {
        return fdMathsName;
    }

    public void setFdMathsName(String fdMathsName) {
        this.fdMathsName = fdMathsName;
    }

    public String getFdMathsMark() {
        return fdMathsMark;
    }

    public void setFdMathsMark(String fdMathsMark) {
        this.fdMathsMark = fdMathsMark;
    }

    public String getFdMathsPeople() {
        return fdMathsPeople;
    }

    public void setFdMathsPeople(String fdMathsPeople) {
        this.fdMathsPeople = fdMathsPeople;
    }

    public String getFdMathsDate() {
        return fdMathsDate;
    }

    public void setFdMathsDate(String fdMathsDate) {
        this.fdMathsDate = fdMathsDate;
    }

    public String getFdMathsStatus() {
        return fdMathsStatus;
    }

    public void setFdMathsStatus(String fdMathsStatus) {
        this.fdMathsStatus = fdMathsStatus;
    }
}