package com.work.entity;

public class TCrowRank {
	private String fdCount;
	private String fdEmpid;
	private String fdEmpname;
	private String fdUninme;
	private String fdIcohead;
	public String getFdCount() {
		return fdCount;
	}
	public void setFdCount(String fdCount) {
		this.fdCount = fdCount;
	}
	public String getFdEmpid() {
		return fdEmpid;
	}
	public void setFdEmpid(String fdEmpid) {
		this.fdEmpid = fdEmpid;
	}
	public String getFdEmpname() {
		return fdEmpname;
	}
	public void setFdEmpname(String fdEmpname) {
		this.fdEmpname = fdEmpname;
	}
	public String getFdUninme() {
		return fdUninme;
	}
	public void setFdUninme(String fdUninme) {
		this.fdUninme = fdUninme;
	}
	public String getFdIcohead() {
		return fdIcohead;
	}
	public void setFdIcohead(String fdIcohead) {
		this.fdIcohead = fdIcohead;
	}
}
