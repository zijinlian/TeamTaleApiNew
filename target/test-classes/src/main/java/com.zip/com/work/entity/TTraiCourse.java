package com.work.entity;

public class TTraiCourse {
    private String id;

    private String coursename;

    private String courcecategory;

    private String courceintrod;

    private String coursepic;

    private String teacherintrod;

    private String publisher;

    private String unitcoce;

    private String createtime;

    private String passtime;

    private String coursestatus;

    private String approvestatus;

    private String teachername;

    private String comments;

    private String approveid;

    private String approvename;

    private String teacherid;

    private String coursetype;

    private String deptcode;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCoursename() {
        return coursename;
    }

    public void setCoursename(String coursename) {
        this.coursename = coursename;
    }

    public String getCourcecategory() {
        return courcecategory;
    }

    public void setCourcecategory(String courcecategory) {
        this.courcecategory = courcecategory;
    }

    public String getCourceintrod() {
        return courceintrod;
    }

    public void setCourceintrod(String courceintrod) {
        this.courceintrod = courceintrod;
    }

    public String getCoursepic() {
        return coursepic;
    }

    public void setCoursepic(String coursepic) {
        this.coursepic = coursepic;
    }

    public String getTeacherintrod() {
        return teacherintrod;
    }

    public void setTeacherintrod(String teacherintrod) {
        this.teacherintrod = teacherintrod;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getUnitcoce() {
        return unitcoce;
    }

    public void setUnitcoce(String unitcoce) {
        this.unitcoce = unitcoce;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getPasstime() {
        return passtime;
    }

    public void setPasstime(String passtime) {
        this.passtime = passtime;
    }

    public String getCoursestatus() {
        return coursestatus;
    }

    public void setCoursestatus(String coursestatus) {
        this.coursestatus = coursestatus;
    }

    public String getApprovestatus() {
        return approvestatus;
    }

    public void setApprovestatus(String approvestatus) {
        this.approvestatus = approvestatus;
    }

    public String getTeachername() {
        return teachername;
    }

    public void setTeachername(String teachername) {
        this.teachername = teachername;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getApproveid() {
        return approveid;
    }

    public void setApproveid(String approveid) {
        this.approveid = approveid;
    }

    public String getApprovename() {
        return approvename;
    }

    public void setApprovename(String approvename) {
        this.approvename = approvename;
    }

    public String getTeacherid() {
        return teacherid;
    }

    public void setTeacherid(String teacherid) {
        this.teacherid = teacherid;
    }

    public String getCoursetype() {
        return coursetype;
    }

    public void setCoursetype(String coursetype) {
        this.coursetype = coursetype;
    }

    public String getDeptcode() {
        return deptcode;
    }

    public void setDeptcode(String deptcode) {
        this.deptcode = deptcode;
    }
}