package com.work.entity;


public class TExamMiddleleader {
	
	private String empId;
	
	private String empName;
	
	private String fdJob;
	
	private String fdBranch;
	
	private String fdBranchName;

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getFdJob() {
		return fdJob;
	}

	public void setFdJob(String fdJob) {
		this.fdJob = fdJob;
	}

	public String getFdBranch() {
		return fdBranch;
	}

	public void setFdBranch(String fdBranch) {
		this.fdBranch = fdBranch;
	}

	public String getFdBranchName() {
		return fdBranchName;
	}

	public void setFdBranchName(String fdBranchName) {
		this.fdBranchName = fdBranchName;
	}
	
	
	
		
}
