package com.work.entity;

public class TCheckItems {
    private String fdItemsId;

    private String fdItemsContent;

    private String fdItemsResults;

    private String tbListId;

    public String getFdItemsId() {
        return fdItemsId;
    }

    public void setFdItemsId(String fdItemsId) {
        this.fdItemsId = fdItemsId;
    }

    public String getFdItemsContent() {
        return fdItemsContent;
    }

    public void setFdItemsContent(String fdItemsContent) {
        this.fdItemsContent = fdItemsContent;
    }

    public String getFdItemsResults() {
        return fdItemsResults;
    }

    public void setFdItemsResults(String fdItemsResults) {
        this.fdItemsResults = fdItemsResults;
    }

    public String getTbListId() {
        return tbListId;
    }

    public void setTbListId(String tbListId) {
        this.tbListId = tbListId;
    }
}