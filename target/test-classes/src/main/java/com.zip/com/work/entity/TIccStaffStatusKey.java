package com.work.entity;

public class TIccStaffStatusKey {
    private String fdStaffId;

    private String fdPaperId;

    private String fdStaffStatusDate;

    public String getFdStaffId() {
        return fdStaffId;
    }

    public void setFdStaffId(String fdStaffId) {
        this.fdStaffId = fdStaffId;
    }

    public String getFdPaperId() {
        return fdPaperId;
    }

    public void setFdPaperId(String fdPaperId) {
        this.fdPaperId = fdPaperId;
    }

    public String getFdStaffStatusDate() {
        return fdStaffStatusDate;
    }

    public void setFdStaffStatusDate(String fdStaffStatusDate) {
        this.fdStaffStatusDate = fdStaffStatusDate;
    }
}