package com.work.entity;

public class TPubAttachrelKey {
    private String fdAttachrelid;

	private String fdAttachid;

	private String fdAttachtyp;

	public String getFdAttachrelid() {
		return fdAttachrelid;
	}

	public void setFdAttachrelid(String fdAttachrelid) {
		this.fdAttachrelid = fdAttachrelid;
	}

	public String getFdAttachid() {
		return fdAttachid;
	}

	public void setFdAttachid(String fdAttachid) {
		this.fdAttachid = fdAttachid;
	}

	public String getFdAttachtyp() {
		return fdAttachtyp;
	}

	public void setFdAttachtyp(String fdAttachtyp) {
		this.fdAttachtyp = fdAttachtyp;
	}
}