package com.work.entity;

public class TCheckFinalItems {
    private String fdFinalItemsId;

    private String fdFinalItemsContent;

    private String fdFinalItemsResults;

    private String fdFinalItemsCause;

    private String fdFinalListId;

    public String getFdFinalItemsId() {
        return fdFinalItemsId;
    }

    public void setFdFinalItemsId(String fdFinalItemsId) {
        this.fdFinalItemsId = fdFinalItemsId;
    }

    public String getFdFinalItemsContent() {
        return fdFinalItemsContent;
    }

    public void setFdFinalItemsContent(String fdFinalItemsContent) {
        this.fdFinalItemsContent = fdFinalItemsContent;
    }

    public String getFdFinalItemsResults() {
        return fdFinalItemsResults;
    }

    public void setFdFinalItemsResults(String fdFinalItemsResults) {
        this.fdFinalItemsResults = fdFinalItemsResults;
    }

    public String getFdFinalItemsCause() {
        return fdFinalItemsCause;
    }

    public void setFdFinalItemsCause(String fdFinalItemsCause) {
        this.fdFinalItemsCause = fdFinalItemsCause;
    }

    public String getFdFinalListId() {
        return fdFinalListId;
    }

    public void setFdFinalListId(String fdFinalListId) {
        this.fdFinalListId = fdFinalListId;
    }
}