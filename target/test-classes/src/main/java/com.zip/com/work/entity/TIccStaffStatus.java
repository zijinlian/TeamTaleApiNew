package com.work.entity;

public class TIccStaffStatus extends TIccStaffStatusKey {
    private String fdStaffScore;

    public String getFdStaffScore() {
        return fdStaffScore;
    }

    public void setFdStaffScore(String fdStaffScore) {
        this.fdStaffScore = fdStaffScore;
    }
}