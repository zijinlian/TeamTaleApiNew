package com.work.entity;

public class TGupDiploma {
    private String id;

    private String empid;

    private String empname;

    private String diplomatype;

    private String diplomaname;

    private String diplomasource;

    private String inputdate;

    private String enddate;

    private String diplomascore;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmpid() {
        return empid;
    }

    public void setEmpid(String empid) {
        this.empid = empid;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getDiplomatype() {
        return diplomatype;
    }

    public void setDiplomatype(String diplomatype) {
        this.diplomatype = diplomatype;
    }

    public String getDiplomaname() {
        return diplomaname;
    }

    public void setDiplomaname(String diplomaname) {
        this.diplomaname = diplomaname;
    }

    public String getDiplomasource() {
        return diplomasource;
    }

    public void setDiplomasource(String diplomasource) {
        this.diplomasource = diplomasource;
    }

    public String getInputdate() {
        return inputdate;
    }

    public void setInputdate(String inputdate) {
        this.inputdate = inputdate;
    }

    public String getEnddate() {
        return enddate;
    }

    public void setEnddate(String enddate) {
        this.enddate = enddate;
    }

    public String getDiplomascore() {
        return diplomascore;
    }

    public void setDiplomascore(String diplomascore) {
        this.diplomascore = diplomascore;
    }
}