package com.work.entity;

public class TbSugApprove {
    private String fdUuid;

    private String fdApproOrg;

    private String fdApproEmp;

    private String fdApproTime;

    private String fdApproStu;

    private String fdSugEmpScore;

    private String fdApproEmpnme;

    private String fdApproDepnme;

    private String fdEmpid;

    public String getFdUuid() {
        return fdUuid;
    }

    public void setFdUuid(String fdUuid) {
        this.fdUuid = fdUuid;
    }

    public String getFdApproOrg() {
        return fdApproOrg;
    }

    public void setFdApproOrg(String fdApproOrg) {
        this.fdApproOrg = fdApproOrg;
    }

    public String getFdApproEmp() {
        return fdApproEmp;
    }

    public void setFdApproEmp(String fdApproEmp) {
        this.fdApproEmp = fdApproEmp;
    }

    public String getFdApproTime() {
        return fdApproTime;
    }

    public void setFdApproTime(String fdApproTime) {
        this.fdApproTime = fdApproTime;
    }

    public String getFdApproStu() {
        return fdApproStu;
    }

    public void setFdApproStu(String fdApproStu) {
        this.fdApproStu = fdApproStu;
    }

    public String getFdSugEmpScore() {
        return fdSugEmpScore;
    }

    public void setFdSugEmpScore(String fdSugEmpScore) {
        this.fdSugEmpScore = fdSugEmpScore;
    }

    public String getFdApproEmpnme() {
        return fdApproEmpnme;
    }

    public void setFdApproEmpnme(String fdApproEmpnme) {
        this.fdApproEmpnme = fdApproEmpnme;
    }

    public String getFdApproDepnme() {
        return fdApproDepnme;
    }

    public void setFdApproDepnme(String fdApproDepnme) {
        this.fdApproDepnme = fdApproDepnme;
    }

    public String getFdEmpid() {
        return fdEmpid;
    }

    public void setFdEmpid(String fdEmpid) {
        this.fdEmpid = fdEmpid;
    }
}