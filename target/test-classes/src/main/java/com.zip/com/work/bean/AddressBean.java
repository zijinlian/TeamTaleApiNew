package com.work.bean;

public class AddressBean extends PageBean{
	
	private String empName;

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
}
