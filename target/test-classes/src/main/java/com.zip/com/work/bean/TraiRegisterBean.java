package com.work.bean;

public class TraiRegisterBean  extends  PageBean{
    private String registerid;

    private String employeeid;

    private String employeename;

    private String id;

    private String registerstatus;

    private String approverid;

    private String approvername;

    private String approvecoment;

    private String approvetime;

    private String emporgcode;

    private String registertype;

    private String approvetype;

    private String deptcode;

    private String evaluatestatus;

    public String getIsaccommodation() {
        return isaccommodation;
    }

    public void setIsaccommodation(String isaccommodation) {
        this.isaccommodation = isaccommodation;
    }

    private String isaccommodation;

    public String getRegisterid() {
        return registerid;
    }

    public void setRegisterid(String registerid) {
        this.registerid = registerid;
    }

    public String getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }

    public String getEmployeename() {
        return employeename;
    }

    public void setEmployeename(String employeename) {
        this.employeename = employeename;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRegisterstatus() {
        return registerstatus;
    }

    public void setRegisterstatus(String registerstatus) {
        this.registerstatus = registerstatus;
    }

    public String getApproverid() {
        return approverid;
    }

    public void setApproverid(String approverid) {
        this.approverid = approverid;
    }

    public String getApprovername() {
        return approvername;
    }

    public void setApprovername(String approvername) {
        this.approvername = approvername;
    }

    public String getApprovecoment() {
        return approvecoment;
    }

    public void setApprovecoment(String approvecoment) {
        this.approvecoment = approvecoment;
    }

    public String getApprovetime() {
        return approvetime;
    }

    public void setApprovetime(String approvetime) {
        this.approvetime = approvetime;
    }

    public String getEmporgcode() {
        return emporgcode;
    }

    public void setEmporgcode(String emporgcode) {
        this.emporgcode = emporgcode;
    }

    public String getRegistertype() {
        return registertype;
    }

    public void setRegistertype(String registertype) {
        this.registertype = registertype;
    }

    public String getApprovetype() {
        return approvetype;
    }

    public void setApprovetype(String approvetype) {
        this.approvetype = approvetype;
    }

    public String getDeptcode() {
        return deptcode;
    }

    public void setDeptcode(String deptcode) {
        this.deptcode = deptcode;
    }

    public String getEvaluatestatus() {
        return evaluatestatus;
    }

    public void setEvaluatestatus(String evaluatestatus) {
        this.evaluatestatus = evaluatestatus;
    }
}