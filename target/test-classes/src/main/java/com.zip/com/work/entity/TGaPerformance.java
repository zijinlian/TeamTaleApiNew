package com.work.entity;

public class TGaPerformance {
    private String id;

    private String empid;

    private String empname;

    private String permancelevel;

    private String year;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmpid() {
        return empid;
    }

    public void setEmpid(String empid) {
        this.empid = empid;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getPermancelevel() {
        return permancelevel;
    }

    public void setPermancelevel(String permancelevel) {
        this.permancelevel = permancelevel;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
}