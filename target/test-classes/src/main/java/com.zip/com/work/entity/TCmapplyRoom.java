package com.work.entity;

public class TCmapplyRoom {
    private String applyId;

    private String roomid;

    private String fdId;

//    private String roomtypeid;
//
//    private String roomimageid;
//
//    public void setRoomtypeid(String roomtypeid)
//    {
//        this.roomtypeid = roomtypeid;
//    }
//    public String getRoomtypeid()
//    {
//        return this.roomtypeid;
//    }
//    public void setRoomimageid(String roomimageid)
//    {
//        this.roomimageid = roomimageid;
//    }
//    public String getRoomimageid()
//    {
//        return this.roomimageid;
//    }

    public String getApplyId() {
        return applyId;
    }

    public void setApplyId(String applyId) {
        this.applyId = applyId;
    }

    public String getRoomid() {
        return roomid;
    }

    public void setRoomid(String roomid) {
        this.roomid = roomid;
    }

    public String getFdId() {
        return fdId;
    }

    public void setFdId(String fdId) {
        this.fdId = fdId;
    }
}