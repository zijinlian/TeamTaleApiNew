package com.work.entity;

/**
 * Created by System_User on 2016/12/31.
 */
public class TGroupInfo {

    private String party_id;
    private String party_type;
    private String party_num;
    private String party_list_remark;

    public String getParty_id() {
        return party_id;
    }

    public void setParty_id(String party_id) {
        this.party_id = party_id;
    }

    public String getParty_type() {
        return party_type;
    }

    public void setParty_type(String party_type) {
        this.party_type = party_type;
    }

    public String getParty_num() {
        return party_num;
    }

    public void setParty_num(String party_num) {
        this.party_num = party_num;
    }

    public String getParty_list_remark() {
        return party_list_remark;
    }

    public void setParty_list_remark(String party_list_remark) {
        this.party_list_remark = party_list_remark;
    }


}
