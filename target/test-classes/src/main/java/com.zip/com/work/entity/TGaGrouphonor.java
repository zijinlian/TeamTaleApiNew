package com.work.entity;

public class TGaGrouphonor {
    private String id;

    private String honorlevel;

    private String honnortype;

    private String honorname;

    private String empid;

    private String empname;

    private String honordate;

    private String inputdate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHonorlevel() {
        return honorlevel;
    }

    public void setHonorlevel(String honorlevel) {
        this.honorlevel = honorlevel;
    }

    public String getHonnortype() {
        return honnortype;
    }

    public void setHonnortype(String honnortype) {
        this.honnortype = honnortype;
    }

    public String getHonorname() {
        return honorname;
    }

    public void setHonorname(String honorname) {
        this.honorname = honorname;
    }

    public String getEmpid() {
        return empid;
    }

    public void setEmpid(String empid) {
        this.empid = empid;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getHonordate() {
        return honordate;
    }

    public void setHonordate(String honordate) {
        this.honordate = honordate;
    }

    public String getInputdate() {
        return inputdate;
    }

    public void setInputdate(String inputdate) {
        this.inputdate = inputdate;
    }
}