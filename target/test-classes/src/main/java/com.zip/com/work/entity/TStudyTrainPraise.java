package com.work.entity;

public class TStudyTrainPraise {
    private Object praiseId;

    private Object empId;

    private Object createTime;

    private Object studyId;

    public Object getPraiseId() {
        return praiseId;
    }

    public void setPraiseId(Object praiseId) {
        this.praiseId = praiseId;
    }

    public Object getEmpId() {
        return empId;
    }

    public void setEmpId(Object empId) {
        this.empId = empId;
    }

    public Object getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Object createTime) {
        this.createTime = createTime;
    }

    public Object getStudyId() {
        return studyId;
    }

    public void setStudyId(Object studyId) {
        this.studyId = studyId;
    }
}