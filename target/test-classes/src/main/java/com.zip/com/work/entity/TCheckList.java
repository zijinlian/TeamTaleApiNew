package com.work.entity;

public class TCheckList {
    private String tbListId;

    private String fdListSubject;

    private String fdListDate;

    private String fdListAdminId;

    private String fdListStatus;

    public String getTbListId() {
        return tbListId;
    }

    public void setTbListId(String tbListId) {
        this.tbListId = tbListId;
    }

    public String getFdListSubject() {
        return fdListSubject;
    }

    public void setFdListSubject(String fdListSubject) {
        this.fdListSubject = fdListSubject;
    }

    public String getFdListDate() {
        return fdListDate;
    }

    public void setFdListDate(String fdListDate) {
        this.fdListDate = fdListDate;
    }

    public String getFdListAdminId() {
        return fdListAdminId;
    }

    public void setFdListAdminId(String fdListAdminId) {
        this.fdListAdminId = fdListAdminId;
    }

    public String getFdListStatus() {
        return fdListStatus;
    }

    public void setFdListStatus(String fdListStatus) {
        this.fdListStatus = fdListStatus;
    }
}