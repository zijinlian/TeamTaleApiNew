package com.work.bean;

public class OaApplyInfoFeebackBean extends PageBean {
    private String fdActiveid;

	private String fdUsername;

	private String fdFeeTime;

	private String fdScore;

	private String fdFeeContent;

	public String getFdActiveid() {
		return fdActiveid;
	}

	public void setFdActiveid(String fdActiveid) {
		this.fdActiveid = fdActiveid;
	}

	public String getFdUsername() {
		return fdUsername;
	}

	public void setFdUsername(String fdUsername) {
		this.fdUsername = fdUsername;
	}

	public String getFdFeeTime() {
		return fdFeeTime;
	}

	public void setFdFeeTime(String fdFeeTime) {
		this.fdFeeTime = fdFeeTime;
	}

	public String getFdScore() {
		return fdScore;
	}

	public void setFdScore(String fdScore) {
		this.fdScore = fdScore;
	}

	public String getFdFeeContent() {
		return fdFeeContent;
	}

	public void setFdFeeContent(String fdFeeContent) {
		this.fdFeeContent = fdFeeContent;
	}
}