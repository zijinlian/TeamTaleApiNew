package com.work.entity;

import java.math.BigDecimal;

/**
 * Created by System_User on 2016/12/30.
 */
public class TSuggest {

    private String fd_title="";
    private String fd_content="";
    private String fd_empid="";
    private String fd_orgcde="";
    private String fd_pub_time="";
    private String fd_sug_typid="";
    private String fd_appro_org="";
    private String fd_leader_emp="";
    private String fd_leader_tmie="";
    private BigDecimal fd_leader_status;
    private String fd_leader_mark="";
    private String fd_emp_nme="";
    private String fd_emp_uninme="";
    private String fd_typenme="";
    private String fd_appro_orgnme="";
    private String fd_leader_empnme="";
    private String fd_reply_status="";
    private String fd_comment_status="";
    private String fd_app_mark="";
    private String fd_like="";
    private String fd_diss="";

    public String getFd_title() {
        return fd_title;
    }

    public void setFd_title(String fd_title) {
        this.fd_title = fd_title;
    }

    public String getFd_content() {
        return fd_content;
    }

    public void setFd_content(String fd_content) {
        this.fd_content = fd_content;
    }

    public String getFd_empid() {
        return fd_empid;
    }

    public void setFd_empid(String fd_empid) {
        this.fd_empid = fd_empid;
    }

    public String getFd_orgcde() {
        return fd_orgcde;
    }

    public void setFd_orgcde(String fd_orgcde) {
        this.fd_orgcde = fd_orgcde;
    }

    public String getFd_pub_time() {
        return fd_pub_time;
    }

    public void setFd_pub_time(String fd_pub_time) {
        this.fd_pub_time = fd_pub_time;
    }

    public String getFd_sug_typid() {
        return fd_sug_typid;
    }

    public void setFd_sug_typid(String fd_sug_typid) {
        this.fd_sug_typid = fd_sug_typid;
    }

    public String getFd_appro_org() {
        return fd_appro_org;
    }

    public void setFd_appro_org(String fd_appro_org) {
        this.fd_appro_org = fd_appro_org;
    }

    public String getFd_leader_emp() {
        return fd_leader_emp;
    }

    public void setFd_leader_emp(String fd_leader_emp) {
        this.fd_leader_emp = fd_leader_emp;
    }

    public String getFd_leader_tmie() {
        return fd_leader_tmie;
    }

    public void setFd_leader_tmie(String fd_leader_tmie) {
        this.fd_leader_tmie = fd_leader_tmie;
    }

    public BigDecimal getFd_leader_status() {
        return fd_leader_status;
    }

    public void setFd_leader_status(BigDecimal fd_leader_status) {
        this.fd_leader_status = fd_leader_status;
    }

    public String getFd_leader_mark() {
        return fd_leader_mark;
    }

    public void setFd_leader_mark(String fd_leader_mark) {
        this.fd_leader_mark = fd_leader_mark;
    }

    public String getFd_emp_nme() {
        return fd_emp_nme;
    }

    public void setFd_emp_nme(String fd_emp_nme) {
        this.fd_emp_nme = fd_emp_nme;
    }

    public String getFd_emp_uninme() {
        return fd_emp_uninme;
    }

    public void setFd_emp_uninme(String fd_emp_uninme) {
        this.fd_emp_uninme = fd_emp_uninme;
    }

    public String getFd_typenme() {
        return fd_typenme;
    }

    public void setFd_typenme(String fd_typenme) {
        this.fd_typenme = fd_typenme;
    }

    public String getFd_appro_orgnme() {
        return fd_appro_orgnme;
    }

    public void setFd_appro_orgnme(String fd_appro_orgnme) {
        this.fd_appro_orgnme = fd_appro_orgnme;
    }

    public String getFd_leader_empnme() {
        return fd_leader_empnme;
    }

    public void setFd_leader_empnme(String fd_leader_empnme) {
        this.fd_leader_empnme = fd_leader_empnme;
    }

    public String getFd_reply_status() {
        return fd_reply_status;
    }

    public void setFd_reply_status(String fd_reply_status) {
        this.fd_reply_status = fd_reply_status;
    }

    public String getFd_comment_status() {
        return fd_comment_status;
    }

    public void setFd_comment_status(String fd_comment_status) {
        this.fd_comment_status = fd_comment_status;
    }

    public String getFd_app_mark() {
        return fd_app_mark;
    }

    public void setFd_app_mark(String fd_app_mark) {
        this.fd_app_mark = fd_app_mark;
    }

    public String getFd_like() {
        return fd_like;
    }

    public void setFd_like(String fd_like) {
        this.fd_like = fd_like;
    }

    public String getFd_diss() {
        return fd_diss;
    }

    public void setFd_diss(String fd_diss) {
        this.fd_diss = fd_diss;
    }

}
