package com.work.entity;

public class TExamBemeasured {
	
	private String fdEmpId;
	
	private String fdEmpName;
	
	private String fdGender;
	
	private String fdBirthday;
	
	private String fdJobName;
	
	private String fdHiredate;
	
	private String fdOldJobName;
	
	private String fdBranchOrgcode;

	public String getFdEmpId() {
		return fdEmpId;
	}

	public void setFdEmpId(String fdEmpId) {
		this.fdEmpId = fdEmpId;
	}

	public String getFdEmpName() {
		return fdEmpName;
	}

	public void setFdEmpName(String fdEmpName) {
		this.fdEmpName = fdEmpName;
	}

	public String getFdGender() {
		return fdGender;
	}

	public void setFdGender(String fdGender) {
		this.fdGender = fdGender;
	}

	public String getFdBirthday() {
		return fdBirthday;
	}

	public void setFdBirthday(String fdBirthday) {
		this.fdBirthday = fdBirthday;
	}

	public String getFdJobName() {
		return fdJobName;
	}

	public void setFdJobName(String fdJobName) {
		this.fdJobName = fdJobName;
	}

	public String getFdHiredate() {
		return fdHiredate;
	}

	public void setFdHiredate(String fdHiredate) {
		this.fdHiredate = fdHiredate;
	}

	public String getFdOldJobName() {
		return fdOldJobName;
	}

	public void setFdOldJobName(String fdOldJobName) {
		this.fdOldJobName = fdOldJobName;
	}

	public String getFdBranchOrgcode() {
		return fdBranchOrgcode;
	}

	public void setFdBranchOrgcode(String fdBranchOrgcode) {
		this.fdBranchOrgcode = fdBranchOrgcode;
	}
	
	
}
