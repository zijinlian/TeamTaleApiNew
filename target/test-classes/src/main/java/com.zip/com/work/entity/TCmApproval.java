package com.work.entity;

public class TCmApproval {
    private String id;

    private String applyid;

    private String approvalcommnet;

    private String fdHandlerid;

    private String fdHandlernme;

    private String fdHandletime;

    private String fdStatus;

//    private String roomtypeid;
//
//    private String roomimageid;
//
//    public void setRoomtypeid(String roomtypeid)
//    {
//        this.roomtypeid = roomtypeid;
//    }
//    public String getRoomtypeid()
//    {
//        return this.roomtypeid;
//    }
//    public void setRoomimageid(String roomimageid)
//    {
//        this.roomimageid = roomimageid;
//    }
//    public String getRoomimageid()
//    {
//        return this.roomimageid;
//    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getApplyid() {
        return applyid;
    }

    public void setApplyid(String applyid) {
        this.applyid = applyid;
    }

    public String getApprovalcommnet() {
        return approvalcommnet;
    }

    public void setApprovalcommnet(String approvalcommnet) {
        this.approvalcommnet = approvalcommnet;
    }

    public String getFdHandlerid() {
        return fdHandlerid;
    }

    public void setFdHandlerid(String fdHandlerid) {
        this.fdHandlerid = fdHandlerid;
    }

    public String getFdHandlernme() {
        return fdHandlernme;
    }

    public void setFdHandlernme(String fdHandlernme) {
        this.fdHandlernme = fdHandlernme;
    }

    public String getFdHandletime() {
        return fdHandletime;
    }

    public void setFdHandletime(String fdHandletime) {
        this.fdHandletime = fdHandletime;
    }

    public String getFdStatus() {
        return fdStatus;
    }

    public void setFdStatus(String fdStatus) {
        this.fdStatus = fdStatus;
    }
}