package com.work.bean;

public class CmApprovalBean {
    private String id;

    private String applyid;

    private String approvalcommnet;

    private String fdHandlerid;

    private String fdHandlernme;

    private String fdHandletime;

    private String fdStatus;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getApplyid() {
        return applyid;
    }

    public void setApplyid(String applyid) {
        this.applyid = applyid;
    }

    public String getApprovalcommnet() {
        return approvalcommnet;
    }

    public void setApprovalcommnet(String approvalcommnet) {
        this.approvalcommnet = approvalcommnet;
    }

    public String getFdHandlerid() {
        return fdHandlerid;
    }

    public void setFdHandlerid(String fdHandlerid) {
        this.fdHandlerid = fdHandlerid;
    }

    public String getFdHandlernme() {
        return fdHandlernme;
    }

    public void setFdHandlernme(String fdHandlernme) {
        this.fdHandlernme = fdHandlernme;
    }

    public String getFdHandletime() {
        return fdHandletime;
    }

    public void setFdHandletime(String fdHandletime) {
        this.fdHandletime = fdHandletime;
    }

    public String getFdStatus() {
        return fdStatus;
    }

    public void setFdStatus(String fdStatus) {
        this.fdStatus = fdStatus;
    }
}