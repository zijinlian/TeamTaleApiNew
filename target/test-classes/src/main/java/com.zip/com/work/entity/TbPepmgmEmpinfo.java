package com.work.entity;

public class TbPepmgmEmpinfo {
    private String fdEmpid;

    private String fdEmpnme;

    private String fdGender;

    private String fdOrgnme;

    private String fdUnitnme;

    private String fdJobnme;

    private String fdStandardJobnme;

    private String fdJobStartdate;

    private String fdJobid;

    private String fdUnitcde;

    private String fdOrgcde;

    private String fdStandjobSysnum;

    private String fdEmpstat;

    private String fdEmptyp;

    private String fdJobline;

    private String fdOrgIdentify;

    private String fdOrgflag;

    private String fdOrglevel;

    private String fdHiredate;

    private String fdJointradeDate;

    private String fdStartWorkdate;

    private String fdNation;

    private String fdEntryMode;

    private String fdPoliticalStatus;

    private String fdHighEdu;

    private String fdHighDegree;

    private String fdParentunitSystemno;

    private String fdParentOrg;

    private String fdFactUnit;

    private String fdJobcode;

    private String fdNativePlace;

    private String fdBirthPlace;

    private String fdDomicilePlace;

    private String fdLeaderid;

    private String fdLeadernme;

    private String fdDeptOrg;

    private String fdCredNum;
    
    private String fdHmphe;
    
    private String fdBizphe;
    
    private String fdHeadicon;
    
    public String getFdBizphe() {
		return fdBizphe;
	}

	public void setFdBizphe(String fdBizphe) {
		this.fdBizphe = fdBizphe;
	}

	public String getFdHmphe() {
		return fdHmphe;
	}

	public void setFdHmphe(String fdHmphe) {
		this.fdHmphe = fdHmphe;
	}

	public String getFdHeadicon() {
		return fdHeadicon;
	}

	public void setFdHeadicon(String fdHeadicon) {
		this.fdHeadicon = fdHeadicon;
	}

	public String getFdEmpid() {
        return fdEmpid;
    }

    public void setFdEmpid(String fdEmpid) {
        this.fdEmpid = fdEmpid;
    }

    public String getFdEmpnme() {
        return fdEmpnme;
    }

    public void setFdEmpnme(String fdEmpnme) {
        this.fdEmpnme = fdEmpnme;
    }

    public String getFdGender() {
        return fdGender;
    }

    public void setFdGender(String fdGender) {
        this.fdGender = fdGender;
    }

    public String getFdOrgnme() {
        return fdOrgnme;
    }

    public void setFdOrgnme(String fdOrgnme) {
        this.fdOrgnme = fdOrgnme;
    }

    public String getFdUnitnme() {
        return fdUnitnme;
    }

    public void setFdUnitnme(String fdUnitnme) {
        this.fdUnitnme = fdUnitnme;
    }

    public String getFdJobnme() {
        return fdJobnme;
    }

    public void setFdJobnme(String fdJobnme) {
        this.fdJobnme = fdJobnme;
    }

    public String getFdStandardJobnme() {
        return fdStandardJobnme;
    }

    public void setFdStandardJobnme(String fdStandardJobnme) {
        this.fdStandardJobnme = fdStandardJobnme;
    }

    public String getFdJobStartdate() {
        return fdJobStartdate;
    }

    public void setFdJobStartdate(String fdJobStartdate) {
        this.fdJobStartdate = fdJobStartdate;
    }

    public String getFdJobid() {
        return fdJobid;
    }

    public void setFdJobid(String fdJobid) {
        this.fdJobid = fdJobid;
    }

    public String getFdUnitcde() {
        return fdUnitcde;
    }

    public void setFdUnitcde(String fdUnitcde) {
        this.fdUnitcde = fdUnitcde;
    }

    public String getFdOrgcde() {
        return fdOrgcde;
    }

    public void setFdOrgcde(String fdOrgcde) {
        this.fdOrgcde = fdOrgcde;
    }

    public String getFdStandjobSysnum() {
        return fdStandjobSysnum;
    }

    public void setFdStandjobSysnum(String fdStandjobSysnum) {
        this.fdStandjobSysnum = fdStandjobSysnum;
    }

    public String getFdEmpstat() {
        return fdEmpstat;
    }

    public void setFdEmpstat(String fdEmpstat) {
        this.fdEmpstat = fdEmpstat;
    }

    public String getFdEmptyp() {
        return fdEmptyp;
    }

    public void setFdEmptyp(String fdEmptyp) {
        this.fdEmptyp = fdEmptyp;
    }

    public String getFdJobline() {
        return fdJobline;
    }

    public void setFdJobline(String fdJobline) {
        this.fdJobline = fdJobline;
    }

    public String getFdOrgIdentify() {
        return fdOrgIdentify;
    }

    public void setFdOrgIdentify(String fdOrgIdentify) {
        this.fdOrgIdentify = fdOrgIdentify;
    }

    public String getFdOrgflag() {
        return fdOrgflag;
    }

    public void setFdOrgflag(String fdOrgflag) {
        this.fdOrgflag = fdOrgflag;
    }

    public String getFdOrglevel() {
        return fdOrglevel;
    }

    public void setFdOrglevel(String fdOrglevel) {
        this.fdOrglevel = fdOrglevel;
    }

    public String getFdHiredate() {
        return fdHiredate;
    }

    public void setFdHiredate(String fdHiredate) {
        this.fdHiredate = fdHiredate;
    }

    public String getFdJointradeDate() {
        return fdJointradeDate;
    }

    public void setFdJointradeDate(String fdJointradeDate) {
        this.fdJointradeDate = fdJointradeDate;
    }

    public String getFdStartWorkdate() {
        return fdStartWorkdate;
    }

    public void setFdStartWorkdate(String fdStartWorkdate) {
        this.fdStartWorkdate = fdStartWorkdate;
    }

    public String getFdNation() {
        return fdNation;
    }

    public void setFdNation(String fdNation) {
        this.fdNation = fdNation;
    }

    public String getFdEntryMode() {
        return fdEntryMode;
    }

    public void setFdEntryMode(String fdEntryMode) {
        this.fdEntryMode = fdEntryMode;
    }

    public String getFdPoliticalStatus() {
        return fdPoliticalStatus;
    }

    public void setFdPoliticalStatus(String fdPoliticalStatus) {
        this.fdPoliticalStatus = fdPoliticalStatus;
    }

    public String getFdHighEdu() {
        return fdHighEdu;
    }

    public void setFdHighEdu(String fdHighEdu) {
        this.fdHighEdu = fdHighEdu;
    }

    public String getFdHighDegree() {
        return fdHighDegree;
    }

    public void setFdHighDegree(String fdHighDegree) {
        this.fdHighDegree = fdHighDegree;
    }

    public String getFdParentunitSystemno() {
        return fdParentunitSystemno;
    }

    public void setFdParentunitSystemno(String fdParentunitSystemno) {
        this.fdParentunitSystemno = fdParentunitSystemno;
    }

    public String getFdParentOrg() {
        return fdParentOrg;
    }

    public void setFdParentOrg(String fdParentOrg) {
        this.fdParentOrg = fdParentOrg;
    }

    public String getFdFactUnit() {
        return fdFactUnit;
    }

    public void setFdFactUnit(String fdFactUnit) {
        this.fdFactUnit = fdFactUnit;
    }

    public String getFdJobcode() {
        return fdJobcode;
    }

    public void setFdJobcode(String fdJobcode) {
        this.fdJobcode = fdJobcode;
    }

    public String getFdNativePlace() {
        return fdNativePlace;
    }

    public void setFdNativePlace(String fdNativePlace) {
        this.fdNativePlace = fdNativePlace;
    }

    public String getFdBirthPlace() {
        return fdBirthPlace;
    }

    public void setFdBirthPlace(String fdBirthPlace) {
        this.fdBirthPlace = fdBirthPlace;
    }

    public String getFdDomicilePlace() {
        return fdDomicilePlace;
    }

    public void setFdDomicilePlace(String fdDomicilePlace) {
        this.fdDomicilePlace = fdDomicilePlace;
    }

    public String getFdLeaderid() {
        return fdLeaderid;
    }

    public void setFdLeaderid(String fdLeaderid) {
        this.fdLeaderid = fdLeaderid;
    }

    public String getFdLeadernme() {
        return fdLeadernme;
    }

    public void setFdLeadernme(String fdLeadernme) {
        this.fdLeadernme = fdLeadernme;
    }

    public String getFdDeptOrg() {
        return fdDeptOrg;
    }

    public void setFdDeptOrg(String fdDeptOrg) {
        this.fdDeptOrg = fdDeptOrg;
    }

    public String getFdCredNum() {
        return fdCredNum;
    }

    public void setFdCredNum(String fdCredNum) {
        this.fdCredNum = fdCredNum;
    }
}